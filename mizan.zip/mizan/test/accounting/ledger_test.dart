import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/errors/app_exception.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';

import '../helpers.dart';

Matcher throwsLedger(String code) => throwsA(isA<LedgerException>().having((e) => e.code, 'code', code));

void main() {
  late TestEnv env;
  setUp(() async => env = await TestEnv.create());
  tearDown(() => env.dispose());

  group('açılış bakiyesi', () {
    test('varlık, kart ve cari yönleri doğru', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '1.000,00');
      final kart = await env.account(AccountKind.krediKarti, 'Kart', opening: '250,00');
      final borcluyuz = await env.account(AccountKind.cari, 'Tedarikçi', opening: '300', normal: false);
      expect(await env.balance(kasa), env.tl('1000'));
      expect(await env.balance(kart), env.tl('250'), reason: 'kart borcu pozitif');
      expect(await env.balance(borcluyuz), env.tl('-300'), reason: 'biz borçluyuz = negatif cari');
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });

    test('aynı form anahtarı ikinci hesap ve ikinci açılış üretmez', () async {
      final key = newId();
      Future<LedgerAccount> create() => env.accounts.createAccount(
            businessId: env.businessId,
            kind: AccountKind.kasa,
            name: 'Kasa',
            currency: Currency.tryLira,
            formKey: key,
            openingBalance: env.tl('500'),
          );
      final a = await create();
      final b = await create();
      expect(a.id, b.id);
      expect(await env.balance(a), env.tl('500'));
      final list = await env.accounts.userAccounts(env.businessId);
      expect(list.length, 1);
    });
  });

  group('gelir / gider', () {
    test('gelir kasayı artırır, gider azaltır', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final satis = await env.category('gelir', 'Satış');
      final kira = await env.category('gider', 'Kira');
      await env.post(EntryType.gelir,
          PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('49,90')));
      await env.post(EntryType.gider,
          PostingRules.expense(paidFrom: kasa, expenseAccount: kira, amount: env.tl('30,05')));
      expect(await env.balance(kasa), env.tl('119,85'));
      expect(await env.balance(satis), env.tl('49,90'));
      expect(await env.balance(kira), env.tl('30,05'));
    });
  });

  group('transfer', () {
    test('toplam varlığı değiştirmez ve atomiktir', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '1.000');
      final banka = await env.account(AccountKind.banka, 'Banka', opening: '2.000');
      final before = (await env.balance(kasa)) + (await env.balance(banka));
      await env.post(EntryType.transfer, PostingRules.transfer(from: kasa, to: banka, amount: env.tl('400,01')));
      expect(await env.balance(kasa), env.tl('599,99'));
      expect(await env.balance(banka), env.tl('2.400,01'));
      expect((await env.balance(kasa)) + (await env.balance(banka)), before);
    });

    test('farklı para birimi ve aynı hesap reddedilir', () async {
      final tl = await env.account(AccountKind.kasa, 'TL Kasa');
      final usd = await env.account(AccountKind.kasa, 'USD Kasa', currency: Currency.usd);
      expect(() => PostingRules.transfer(from: tl, to: usd, amount: env.tl('1')), throwsLedger('LEDGER_INVALID'));
      expect(() => PostingRules.transfer(from: tl, to: tl, amount: env.tl('1')), throwsLedger('LEDGER_INVALID'));
    });
  });

  group('kredi kartı', () {
    test('harcama borcu artırır, ödeme bankadan düşer ve borcu azaltır', () async {
      final banka = await env.account(AccountKind.banka, 'Banka', opening: '10.000');
      final kart = await env.account(AccountKind.krediKarti, 'Kart');
      final market = await env.category('gider', 'Market');
      await env.post(EntryType.kartHarcama,
          PostingRules.expense(paidFrom: kart, expenseAccount: market, amount: env.tl('750,90')));
      expect(await env.balance(kart), env.tl('750,90'));
      expect(await env.balance(banka), env.tl('10.000'), reason: 'harcama bankayı etkilemez');

      final payment = PostingRules.transfer(from: banka, to: kart, amount: env.tl('500'));
      expect(PostingRules.transferType(banka, kart), EntryType.kartOdeme);
      await env.post(EntryType.kartOdeme, payment);
      expect(await env.balance(kart), env.tl('250,90'));
      expect(await env.balance(banka), env.tl('9.500'));
      expect(await env.balance(market), env.tl('750,90'), reason: 'ödeme gideri ikinci kez yazmaz');
    });
  });

  group('cari', () {
    test('veresiye satış + kısmi tahsilat = doğru kalan', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa');
      final cari = await env.account(AccountKind.cari, 'Ahmet');
      final satis = await env.category('gelir', 'Satış');
      await env.post(EntryType.alacak,
          PostingRules.receivable(cari: cari, incomeAccount: satis, amount: env.tl('1.200')));
      await env.post(EntryType.tahsilat,
          PostingRules.collection(cari: cari, moneyAccount: kasa, amount: env.tl('450')));
      expect(await env.balance(cari), env.tl('750'));
      expect(await env.balance(kasa), env.tl('450'));
    });

    test('tedarikçiden veresiye alış + ödeme', () async {
      final banka = await env.account(AccountKind.banka, 'Banka', opening: '5.000');
      final cari = await env.account(AccountKind.cari, 'Tedarikçi');
      final mal = await env.category('gider', 'Diğer Gider');
      await env.post(EntryType.borc, PostingRules.payable(cari: cari, expenseAccount: mal, amount: env.tl('2.000')));
      expect(await env.balance(cari), env.tl('-2.000'));
      await env.post(EntryType.odeme, PostingRules.payment(cari: cari, moneyAccount: banka, amount: env.tl('2.000')));
      expect(await env.balance(cari), env.tl('0'));
      expect(await env.balance(banka), env.tl('3.000'));
    });
  });

  group('bütünlük korumaları', () {
    test('aynı işlem anahtarı iki kez kaydedilmez', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa');
      final satis = await env.category('gelir', 'Satış');
      final lines = PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('10'));
      final a = await env.post(EntryType.gelir, lines, key: 'form-1');
      final b = await env.post(EntryType.gelir, lines, key: 'form-1');
      expect(a, b);
      expect(await env.balance(kasa), env.tl('10'));
    });

    test('dengesiz istek reddedilir ve iz bırakmaz', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa');
      final banka = await env.account(AccountKind.banka, 'Banka');
      final bad = [PostingLine.debit(kasa, env.tl('10')), PostingLine.credit(banka, env.tl('9,99'))];
      await expectLater(env.post(EntryType.transfer, bad), throwsLedger('LEDGER_UNBALANCED'));
      await expectLater(env.post(EntryType.transfer, [PostingLine.debit(kasa, env.tl('1'))]),
          throwsLedger('LEDGER_UNBALANCED'));
      final rows = await env.db.customSelect('SELECT COUNT(*) AS n FROM journal_entries').getSingle();
      expect(rows.read<int>('n'), 0);
    });

    test('hesap para birimiyle uyuşmayan satır reddedilir', () async {
      final usd = await env.account(AccountKind.kasa, 'USD', currency: Currency.usd);
      final banka = await env.account(AccountKind.banka, 'Banka');
      final lines = [
        PostingLine(accountId: usd.id, side: EntrySide.debit, amount: env.tl('5')),
        PostingLine.credit(banka, env.tl('5')),
      ];
      await expectLater(env.post(EntryType.transfer, lines), throwsLedger('LEDGER_ACCOUNT_MISMATCH'));
    });

    test('veritabanı kesinleşmiş satırın değiştirilmesine izin vermez', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      expect(kasa, isNotNull);
      await expectLater(
        env.db.customStatement('UPDATE journal_lines SET debit_minor = 1 WHERE debit_minor > 0'),
        throwsA(predicate((e) => e.toString().contains('LEDGER_IMMUTABLE'))),
      );
      await expectLater(
        env.db.customStatement('DELETE FROM journal_entries'),
        throwsA(predicate((e) => e.toString().contains('LEDGER_IMMUTABLE'))),
      );
      expect(await env.balance(kasa), env.tl('100'));
    });

    test('arşivlenmiş hesaba işlem yapılamaz; bakiyeli hesap arşivlenemez', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '1');
      final bos = await env.account(AccountKind.banka, 'Boş');
      await expectLater(env.accounts.archive(kasa.id), throwsA(isA<AppException>()));
      await env.accounts.archive(bos.id);
      final archived = await env.ledger.account(bos.id);
      expect(
        () => PostingRules.transfer(from: kasa, to: archived, amount: env.tl('1')),
        throwsLedger('ACCOUNT_ARCHIVED'),
      );
    });
  });

  group('iptal (ters kayıt)', () {
    test('bakiyeleri geri alır, tek sefer yapılır, anahtar tekrarında aynı kaydı döner', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '1.000');
      final kira = await env.category('gider', 'Kira');
      final id = await env.post(EntryType.gider,
          PostingRules.expense(paidFrom: kasa, expenseAccount: kira, amount: env.tl('300')));
      expect(await env.balance(kasa), env.tl('700'));

      final r1 = await env.ledger.reverse(entryId: id, idempotencyKey: 'iptal-1', reason: 'yanlış giriş');
      final r2 = await env.ledger.reverse(entryId: id, idempotencyKey: 'iptal-1');
      expect(r1, r2);
      expect(await env.balance(kasa), env.tl('1.000'));
      expect(await env.balance(kira), env.tl('0'));
      await expectLater(
          env.ledger.reverse(entryId: id, idempotencyKey: 'iptal-2'), throwsLedger('LEDGER_ALREADY_REVERSED'));
      await expectLater(env.ledger.reverse(entryId: r1, idempotencyKey: 'iptal-3'), throwsLedger('LEDGER_INVALID'));

      final audit = await env.db
          .customSelect("SELECT COUNT(*) AS n FROM audit_log WHERE audit_action = 'reverse' AND record_id = '$id'")
          .getSingle();
      expect(audit.read<int>('n'), 1);
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });

    test('ters kayıt orijinal tarihle yazılır (dönem raporu bozulmaz)', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final kira = await env.category('gider', 'Kira');
      final may = DateTime(2026, 5, 10);
      final id = await env.post(EntryType.gider,
          PostingRules.expense(paidFrom: kasa, expenseAccount: kira, amount: env.tl('40')), date: may);
      final rid = await env.ledger.reverse(entryId: id, idempotencyKey: newId());
      final row = await env.db
          .customSelect("SELECT entry_date FROM journal_entries WHERE id = '$rid'")
          .getSingle();
      expect(row.read<int>('entry_date'), may.toUtc().millisecondsSinceEpoch);
    });
  });

  test('balances(asOf) sonraki işlemleri saymaz', () async {
    final kasa = await env.account(AccountKind.kasa, 'Kasa');
    final satis = await env.category('gelir', 'Satış');
    await env.post(EntryType.gelir, PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('10')),
        date: DateTime(2026, 1, 5));
    await env.post(EntryType.gelir, PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('20')),
        date: DateTime(2026, 3, 5));
    final feb = await env.ledger.balances(env.businessId, asOf: DateTime(2026, 2, 1));
    expect(feb.firstWhere((b) => b.accountId == kasa.id).balance, env.tl('10'));
    expect(await env.balance(kasa), env.tl('30'));
  });

  test('yüzlerce işlemden sonra defter dengede ve bakiye satırlardan doğrulanır', () async {
    final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '50.000');
    final banka = await env.account(AccountKind.banka, 'Banka');
    final satis = await env.category('gelir', 'Satış');
    var expected = 5000000;
    for (var i = 1; i <= 200; i++) {
      final amt = Money.fromMinor(i * 7 + 3, Currency.tryLira);
      if (i.isEven) {
        await env.post(EntryType.gelir, PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: amt));
        expected += amt.minor;
      } else {
        await env.post(EntryType.transfer, PostingRules.transfer(from: kasa, to: banka, amount: amt));
        expected -= amt.minor;
      }
    }
    expect((await env.balance(kasa)).minor, expected);
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });
}
