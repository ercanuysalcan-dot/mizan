import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/errors/app_exception.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/business/data/business_repository.dart';

import '../helpers.dart';

void main() {
  late TestEnv env;
  late BusinessRepository repo;
  setUp(() async {
    env = await TestEnv.create();
    repo = BusinessRepository(env.db, env.settings, deviceId: env.boot.deviceId, clock: env.clock);
  });
  tearDown(() => env.dispose());

  test('en fazla 5 şirket; her şirketin verisi ayrı', () async {
    final b2 = await repo.create(name: 'Uysal İnşaat', baseCurrency: Currency.azn, formKey: newId());
    for (var i = 3; i <= 5; i++) {
      await repo.create(name: 'Şirket $i', baseCurrency: Currency.tryLira, formKey: newId());
    }
    expect((await repo.list()).length, 5);
    await expectLater(repo.create(name: 'Altıncı', baseCurrency: Currency.tryLira, formKey: newId()),
        throwsA(isA<AppException>().having((e) => e.code, 'code', 'BUSINESS_LIMIT')));
    await expectLater(repo.create(name: 'uysal inşaat', baseCurrency: Currency.tryLira, formKey: newId()),
        throwsA(isA<AppException>()));

    // Yeni şirketin kendi kategorileri var; hesaplar karışmaz.
    expect((await env.accounts.categories(b2.id, 'gider')).isNotEmpty, isTrue);
    await env.account(AccountKind.kasa, 'Ana Kasa', opening: '100');
    expect((await env.accounts.userAccounts(b2.id)), isEmpty);
    expect((await env.accounts.userAccounts(env.businessId)).length, 1);

    await repo.delete(b2.id);
    expect((await repo.list()).any((b) => b.id == b2.id), isFalse);
  });

  test('son şirket silinemez', () async {
    await expectLater(repo.delete(env.businessId), throwsA(isA<AppException>()));
  });
}
