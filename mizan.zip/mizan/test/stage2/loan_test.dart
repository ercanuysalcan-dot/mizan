import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/errors/app_exception.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/loans/data/loans_repository.dart';

import '../helpers.dart';
import 'services.dart';

void main() {
  late TestEnv env;
  late Stage2 s;
  setUp(() async {
    env = await TestEnv.create();
    s = Stage2(env);
  });
  tearDown(() => env.dispose());

  Future<LedgerAccount> denizbank({int prepaid = 0}) => s.loans.createLoan(
        businessId: env.businessId,
        name: 'Denizbank Kredi',
        bankName: 'Denizbank',
        currency: Currency.tryLira,
        total: env.tl('114.000'),
        installmentCount: 12,
        installmentAmount: env.tl('9.500'),
        firstDueDate: DateTime(2026, 7, 15),
        prepaidCount: prepaid,
        formKey: newId(),
      );

  test('ödeme planı toplamı her zaman toplam borca eşit', () {
    final plan = LoansRepository.planAmounts(totalMinor: 10000000, count: 3, installmentMinor: 3333333);
    expect(plan, [3333333, 3333333, 3333334]);
    expect(plan.fold<int>(0, (a, b) => a + b), 10000000);
    expect(() => LoansRepository.planAmounts(totalMinor: 100, count: 3, installmentMinor: 60),
        throwsA(isA<AppException>()));
  });

  test('vade ay sonuna taşar', () {
    expect(LoansRepository.dueDateFor(DateTime(2026, 1, 31), 2), DateTime(2026, 2, 28, 12));
    expect(LoansRepository.dueDateFor(DateTime(2026, 11, 15), 3), DateTime(2027, 1, 15, 12));
  });

  test('kredi toplam borçla açılır, taksit ödedikçe düşer', () async {
    final banka = await env.account(AccountKind.banka, 'Banka', opening: '200.000');
    final kredi = await denizbank();
    var info = (await s.loans.load(kredi.id))!;
    expect(info.remaining, env.tl('114.000'));
    expect(info.installments.length, 12);
    expect(info.next!.no, 1);
    expect(info.next!.dueDate, DateTime(2026, 7, 15, 12));
    expect(info.installments.last.dueDate, DateTime(2027, 6, 15, 12));

    final key = newId();
    final pay1 = await s.loans.pay(
      installmentId: info.next!.id,
      moneyAccountId: banka.id,
      amountText: '9.500',
      date: env.clock.now(),
      idempotencyKey: key,
    );
    // Aynı anahtar: ikinci ödeme yok.
    final again = await s.loans.pay(
      installmentId: info.installments.first.id,
      moneyAccountId: banka.id,
      amountText: '9.500',
      date: env.clock.now(),
      idempotencyKey: key,
    );
    expect(again, pay1);

    info = (await s.loans.load(kredi.id))!;
    expect(info.remaining, env.tl('104.500'));
    expect(info.paidCount, 1);
    expect(info.remainingCount, 11);
    expect(info.next!.no, 2);
    expect(await env.balance(banka), env.tl('190.500'));

    await expectLater(
      s.loans.pay(
        installmentId: info.installments.first.id,
        moneyAccountId: banka.id,
        amountText: '9.500',
        date: env.clock.now(),
        idempotencyKey: newId(),
      ),
      throwsA(isA<AppException>()),
    );
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });

  test('yanlış ödeme geri alınır ve düzeltilebilir', () async {
    final banka = await env.account(AccountKind.banka, 'Banka', opening: '50.000');
    final kredi = await denizbank();
    final first = (await s.loans.load(kredi.id))!.next!;
    final wrong = await s.loans.pay(
      installmentId: first.id,
      moneyAccountId: banka.id,
      amountText: '5.900',
      date: env.clock.now(),
      idempotencyKey: newId(),
    );

    // Tutar düzeltmesi: taksit yeni kayda bağlı kalır.
    final fixed = await s.edit.edit(entryId: wrong, editKey: newId(), amountText: '9.500', keepDescription: true);
    var info = (await s.loans.load(kredi.id))!;
    expect(info.installments.first.paidEntryId, fixed);
    expect(info.installments.first.paidAmount, env.tl('9.500'));
    expect(info.remaining, env.tl('104.500'));
    expect(await env.balance(banka), env.tl('40.500'));

    // Geri alma: taksit yeniden ödenmedi, bakiyeler eski haline döner.
    await s.loans.undoPayment(installmentId: first.id, idempotencyKey: newId());
    info = (await s.loans.load(kredi.id))!;
    expect(info.installments.first.isPaid, isFalse);
    expect(info.remaining, env.tl('114.000'));
    expect(await env.balance(banka), env.tl('50.000'));
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });

  test('önceden ödenmiş taksitler kalan borçtan düşer; düzenleme borcu yeniden hesaplar', () async {
    final kredi = await denizbank(prepaid: 3);
    var info = (await s.loans.load(kredi.id))!;
    expect(info.remaining, env.tl('85.500'));
    expect(info.paidCount, 3);
    expect(info.next!.no, 4);

    await s.loans.updateLoan(
      accountId: kredi.id,
      name: 'Denizbank Kredi',
      bankName: 'Denizbank',
      total: env.tl('120.000'),
      installmentCount: 12,
      installmentAmount: env.tl('10.000'),
      firstDueDate: DateTime(2026, 7, 15),
      prepaidCount: 3,
      editKey: newId(),
    );
    info = (await s.loans.load(kredi.id))!;
    expect(info.total, env.tl('120.000'));
    expect(info.remaining, env.tl('90.000'));
    expect(info.installments.length, 12);
    expect(info.installments.every((i) => i.amount == env.tl('10.000')), isTrue);
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });
}
