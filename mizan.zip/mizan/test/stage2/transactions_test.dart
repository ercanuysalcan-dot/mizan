import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';
import 'package:mizan/features/transactions/data/transactions_query.dart';

import '../helpers.dart';

void main() {
  late TestEnv env;
  setUp(() async => env = await TestEnv.create());
  tearDown(() => env.dispose());

  test('işlemler listesi: yön, kategori, süzgeç ve toplamlar', () async {
    final q = TransactionsQuery(env.db);
    final kasa = await env.account(AccountKind.kasa, 'Nakit', opening: '1.000');
    final banka = await env.account(AccountKind.banka, 'Banka');
    final maas = await env.category('gelir', 'Maaş');
    final market = await env.category('gider', 'Market');
    await env.ledger.post(PostingRequest(
      businessId: env.businessId,
      type: EntryType.gelir,
      date: env.clock.now(),
      idempotencyKey: 'maas-1',
      description: 'Maaş yattı',
      lines: PostingRules.income(moneyAccount: kasa, incomeAccount: maas, amount: env.tl('500')),
    ));
    await env.post(EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('120')));
    await env.post(EntryType.transfer, PostingRules.transfer(from: kasa, to: banka, amount: env.tl('200')));

    final all = await q.load(env.businessId, const TxFilter(start: null, end: null));
    // Açılış bakiyesi de transfer yönlü bir kayıt olarak listelenir.
    expect(all.items.length, 4);
    final income = all.items.firstWhere((i) => i.direction == TxDirection.income);
    expect(income.title, 'Maaş');
    expect(income.note, 'Maaş yattı');
    expect(income.entry.fromNames, isEmpty, reason: 'kategori akışta tekrarlanmaz');
    expect(income.entry.toNames, ['Nakit']);
    expect(all.totals.single.income, env.tl('500'));
    expect(all.totals.single.expense, env.tl('120'));
    expect(all.totals.single.net, env.tl('380'));

    final onlyExpense = await q.load(env.businessId, const TxFilter(start: null, end: null, direction: TxDirection.expense));
    expect(onlyExpense.items.single.title, 'Market');

    final bankOnly = await q.load(env.businessId, TxFilter(start: null, end: null, accountId: banka.id));
    expect(bankOnly.items.single.direction, TxDirection.transfer);

    final search = await q.load(env.businessId, const TxFilter(start: null, end: null, search: 'yattı'));
    expect(search.items.single.title, 'Maaş');
  });
}
