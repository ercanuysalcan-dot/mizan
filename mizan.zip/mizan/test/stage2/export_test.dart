import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';
import 'package:mizan/features/export/reports.dart';
import 'package:mizan/features/export/xlsx_writer.dart';
import 'package:mizan/features/transactions/data/entries_repository.dart';
import 'package:mizan/features/transactions/data/transactions_query.dart';

import '../helpers.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('xlsx yardımcıları', () {
    expect(ZipWriter.crc32(utf8.encode('123456789')), 0xCBF43926);
    expect(XlsxWorkbook.colName(1), 'A');
    expect(XlsxWorkbook.colName(28), 'AB');
    expect(XlsxWorkbook.excelSerial(DateTime(2026, 1, 1)), '46023');
    expect(const XMoney(-5, 2).text, '-0.05');
    expect(const XMoney(6544000, 2).text, '65440.00');
    final bytes = (XlsxWorkbook()..sheet('Test').add([const XCell('a & <b>')])).encode();
    expect(bytes.sublist(0, 2), [0x50, 0x4B]);
    expect(bytes.sublist(bytes.length - 22, bytes.length - 18), [0x50, 0x4B, 0x05, 0x06]);
  });

  test('işlemler ve ekstre Excel/PDF olarak üretilir', () async {
    final env = await TestEnv.create();
    addTearDown(env.dispose);
    final kasa = await env.account(AccountKind.kasa, 'Nakit', opening: '1.000');
    final market = await env.category('gider', 'Market');
    await env.post(EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('120,50')));

    final page = await TransactionsQuery(env.db).load(env.businessId, const TxFilter(start: null, end: null));
    final meta = ReportMeta(
      businessName: 'Uysal İnşaat',
      title: 'İşlemler raporu',
      periodLabel: 'Kasım 2026',
      generatedAt: env.clock.now(),
    );
    final x = transactionsXlsx(page, meta);
    expect(x.name, endsWith('.xlsx'));
    expect(x.name, startsWith('Mizan_Islemler_raporu_'));
    expect(x.bytes.length, greaterThan(1000));

    final p = await transactionsPdf(page, meta);
    expect(ascii.decode(p.bytes.sublist(0, 4)), '%PDF');

    final entries = await EntriesRepository(env.db).accountEntries(kasa.id);
    final d = AccountStatementData(
      accountName: 'Nakit',
      kind: AccountKind.kasa,
      currency: kasa.currency,
      closing: await env.balance(kasa),
      newestFirst: entries,
    );
    expect(d.opening, env.tl('0'));
    expect(d.rows.last.balance, env.tl('879,50'));
    expect(accountXlsx(d, meta).bytes.length, greaterThan(1000));
    expect(ascii.decode((await accountPdf(d, meta)).bytes.sublist(0, 4)), '%PDF');
  });
}
