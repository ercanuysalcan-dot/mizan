import 'package:mizan/features/attachments/data/attachments_repository.dart';
import 'package:mizan/features/cards/data/card_statements_repository.dart';
import 'package:mizan/features/categories/data/categories_repository.dart';
import 'package:mizan/features/loans/data/loans_repository.dart';
import 'package:mizan/features/transactions/application/entry_edit_service.dart';
import 'package:mizan/features/transactions/data/entries_repository.dart';

import '../helpers.dart';

/// Aşama 2 servisleri, test ortamının veritabanı ve saatine bağlı.
class Stage2 {
  Stage2(this.env)
      : entries = EntriesRepository(env.db),
        attachments = AttachmentsRepository(env.db, deviceId: env.boot.deviceId, clock: env.clock) {
    edit = EntryEditService(env.db, env.ledger, env.accounts, entries,
        deviceId: env.boot.deviceId, clock: env.clock);
    loans = LoansRepository(env.db, env.ledger, env.accounts, edit, deviceId: env.boot.deviceId, clock: env.clock);
    categories = CategoriesRepository(env.db, env.accounts, edit, deviceId: env.boot.deviceId, clock: env.clock);
    statements = CardStatementsRepository(env.db, env.ledger, env.accounts, entries, edit, attachments,
        deviceId: env.boot.deviceId, clock: env.clock);
  }

  final TestEnv env;
  final EntriesRepository entries;
  final AttachmentsRepository attachments;
  late final EntryEditService edit;
  late final LoansRepository loans;
  late final CategoriesRepository categories;
  late final CardStatementsRepository statements;
}
