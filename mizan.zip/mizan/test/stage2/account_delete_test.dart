import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/errors/app_exception.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';
import 'package:mizan/features/accounts/application/account_delete_service.dart';

import '../helpers.dart';
import 'services.dart';

void main() {
  late TestEnv env;
  late Stage2 s;
  late AccountDeleteService del;
  setUp(() async {
    env = await TestEnv.create();
    s = Stage2(env);
    del = AccountDeleteService(env.db, s.edit, deviceId: env.boot.deviceId, clock: env.clock);
  });
  tearDown(() => env.dispose());

  test('hareketsiz hesap doğrudan silinir', () async {
    final banka = await env.account(AccountKind.banka, 'Deniz Bank Kredi Ödemesi');
    expect(await del.movementCount(banka.id), 0);
    expect(await del.delete(accountId: banka.id, opKey: newId()), 0);
    final list = await env.accounts.userAccounts(env.businessId);
    expect(list.any((a) => a.account.id == banka.id), isFalse);
  });

  test('hareketli hesap onaysız silinmez; onayla işlemleri iptal edilerek silinir', () async {
    final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '500');
    final market = await env.category('gider', 'Market');
    await env.post(EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('120')));
    expect(await del.movementCount(kasa.id), 2);
    await expectLater(del.delete(accountId: kasa.id, opKey: newId()), throwsA(isA<AppException>()));

    expect(await del.delete(accountId: kasa.id, opKey: newId(), withEntries: true), 2);
    expect(await env.balance(market), env.tl('0'), reason: 'gider de geri alındı');
    final list = await env.accounts.userAccounts(env.businessId);
    expect(list.any((a) => a.account.id == kasa.id), isFalse);
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });
}
