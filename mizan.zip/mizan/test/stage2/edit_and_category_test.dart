import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/errors/app_exception.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';
import 'package:mizan/features/attachments/data/attachments_repository.dart';

import '../helpers.dart';
import 'services.dart';

void main() {
  late TestEnv env;
  late Stage2 s;
  setUp(() async {
    env = await TestEnv.create();
    s = Stage2(env);
  });
  tearDown(() => env.dispose());

  group('kayıt düzeltme', () {
    test('tutar, kategori ve hesap düzeltilir; bakiyeler ve geçmiş doğru', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '1.000');
      final kart = await env.account(AccountKind.krediKarti, 'Kart');
      final market = await env.category('gider', 'Market');
      final id = await env.post(
          EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('590')));

      final id2 = await s.edit.edit(entryId: id, editKey: newId(), amountText: '950', description: 'Haftalık');
      expect(await env.balance(kasa), env.tl('50'));
      expect(await env.balance(market), env.tl('950'));
      expect((await s.entries.detail(id))!.status, 'reversed');

      final faturalar = (await env.accounts.categories(env.businessId, 'gider')).firstWhere((c) => c.name == 'Faturalar');
      final id3 = await s.edit.edit(entryId: id2, editKey: newId(), categoryId: faturalar.id, moneyAccountId: kart.id,
          keepDescription: true);
      expect(await env.balance(kasa), env.tl('1.000'));
      expect(await env.balance(kart), env.tl('950'), reason: 'harcama karta taşındı');
      expect(await env.balance(market), env.tl('0'));
      final d3 = (await s.entries.detail(id3))!;
      expect(d3.type, EntryType.kartHarcama);
      expect(d3.description, 'Haftalık');

      final history = await s.entries.history(id3);
      expect(history.length, 2);
      expect(history.first.previousAmount, env.tl('950'));
      expect(history.last.previousAmount, env.tl('590'));
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });

    test('aynı düzenleme anahtarı iki kez işlenmez; değişiklik yoksa hata', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final market = await env.category('gider', 'Market');
      final id = await env.post(
          EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('10')));
      final key = newId();
      final a = await s.edit.edit(entryId: id, editKey: key, amountText: '20', keepDescription: true);
      final b = await s.edit.edit(entryId: id, editKey: key, amountText: '20', keepDescription: true);
      expect(a, b);
      expect(await env.balance(kasa), env.tl('80'));
      await expectLater(s.edit.edit(entryId: a, editKey: newId(), amountText: '20', keepDescription: true),
          throwsA(isA<AppException>().having((e) => e.code, 'code', 'EDIT_NOCHANGE')));
    });

    test('ek, düzeltilen kayda taşınır', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final market = await env.category('gider', 'Market');
      final id = await env.post(
          EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: market, amount: env.tl('10')));
      await s.attachments.add(
        businessId: env.businessId,
        ownerTable: AttachmentOwner.entry,
        ownerId: id,
        file: PendingAttachment(bytes: Uint8List.fromList([1, 2, 3]), mimeType: 'image/png'),
      );
      final id2 = await s.edit.edit(entryId: id, editKey: newId(), amountText: '12', keepDescription: true);
      expect(await s.attachments.list(AttachmentOwner.entry, id), isEmpty);
      final files = await s.attachments.list(AttachmentOwner.entry, id2);
      expect(files.length, 1);
      expect(await s.attachments.content(files.first.id), [1, 2, 3]);
    });
  });

  group('kategoriler', () {
    test('alt kategori ana kategorinin hemen altında listelenir', () async {
      final faturalar = (await env.accounts.categories(env.businessId, 'gider')).firstWhere((c) => c.name == 'Faturalar');
      await s.categories.create(
          businessId: env.businessId, type: 'gider', name: 'İnternet', parentId: faturalar.id, icon: 'internet');
      await s.categories.create(businessId: env.businessId, type: 'gider', name: 'Telefon', parentId: faturalar.id);
      final list = await env.accounts.categories(env.businessId, 'gider');
      final i = list.indexWhere((c) => c.id == faturalar.id);
      final children = list.skip(i + 1).take(2).map((c) => c.displayName).toSet();
      expect(children, {'Faturalar › İnternet', 'Faturalar › Telefon'});

      await expectLater(
        s.categories.create(businessId: env.businessId, type: 'gider', name: 'telefon', parentId: faturalar.id),
        throwsA(isA<AppException>()),
      );
      final telefon = list.firstWhere((c) => c.name == 'Telefon');
      await expectLater(
        s.categories.create(businessId: env.businessId, type: 'gider', name: 'Fatura', parentId: telefon.id),
        throwsA(isA<AppException>()),
        reason: 'tek seviye alt kategori',
      );
    });

    test('ad değişince eski kayıtlar yeni adla görünür', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final id = await s.categories.create(businessId: env.businessId, type: 'gider', name: 'Telfon');
      final acc = await env.accounts.ensureCategoryAccount(env.businessId, id, kasa.currency);
      await env.post(EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: acc, amount: env.tl('5')));
      await s.categories.update(id: id, name: 'Telefon');
      expect((await env.ledger.account(acc.id)).name, 'Telefon');
    });

    test('kayıtlı kategori silinirken kayıtlar seçilen kategoriye taşınır', () async {
      final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '100');
      final cats = await env.accounts.categories(env.businessId, 'gider');
      final market = cats.firstWhere((c) => c.name == 'Market');
      final diger = cats.firstWhere((c) => c.name == 'Diğer Gider');
      final marketAcc = await env.accounts.ensureCategoryAccount(env.businessId, market.id, kasa.currency);
      for (final t in ['10', '15']) {
        await env.post(
            EntryType.gider, PostingRules.expense(paidFrom: kasa, expenseAccount: marketAcc, amount: env.tl(t)));
      }
      await expectLater(s.categories.delete(id: market.id, opKey: newId()), throwsA(isA<AppException>()));

      final moved = await s.categories.delete(id: market.id, moveToId: diger.id, opKey: newId());
      expect(moved, 2);
      final digerAcc = await env.accounts.ensureCategoryAccount(env.businessId, diger.id, kasa.currency);
      expect(await env.balance(digerAcc), env.tl('25'));
      expect(await env.balance(marketAcc), env.tl('0'));
      expect(await env.balance(kasa), env.tl('75'), reason: 'taşıma kasayı etkilemez');
      final after = await env.accounts.categories(env.businessId, 'gider');
      expect(after.any((c) => c.id == market.id), isFalse);
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });
  });

  group('kart ekstresi', () {
    test('dönem borcu karta işlenir, düzeltilir, borçtan çıkarılır ve silinir', () async {
      final kart = await env.account(AccountKind.krediKarti, 'Finansbank');
      final catId = await s.categories.ensureByName(env.businessId, 'gider', 'Kredi Kartı Harcamaları');
      final sid = await s.statements.add(
        businessId: env.businessId,
        cardAccountId: kart.id,
        statementDate: DateTime(2026, 4, 10),
        dueDate: DateTime(2026, 4, 20),
        amountText: '8.750,40',
        addToDebt: true,
        categoryId: catId,
        files: [PendingAttachment(bytes: Uint8List.fromList([9, 9]), mimeType: 'image/jpeg')],
        formKey: newId(),
      );
      expect(await env.balance(kart), env.tl('8.750,40'));
      var list = await s.statements.list(kart.id);
      expect(list.single.attachmentCount, 1);
      expect(list.single.addedToDebt, isTrue);

      await s.statements.update(
        id: sid,
        statementDate: DateTime(2026, 4, 10),
        amountText: '8.900',
        addToDebt: true,
        categoryId: catId,
        editKey: newId(),
      );
      expect(await env.balance(kart), env.tl('8.900'));

      await s.statements.update(
        id: sid,
        statementDate: DateTime(2026, 4, 10),
        amountText: '8.900',
        addToDebt: false,
        editKey: newId(),
      );
      expect(await env.balance(kart), env.tl('0'));
      list = await s.statements.list(kart.id);
      expect(list.single.addedToDebt, isFalse);
      expect(list.single.amount, env.tl('8.900'));

      await s.statements.delete(id: sid, opKey: newId());
      expect(await s.statements.list(kart.id), isEmpty);
      expect(await s.attachments.list(AttachmentOwner.statement, sid), isEmpty);
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });
  });
}
