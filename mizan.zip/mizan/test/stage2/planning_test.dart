import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/planning/application/planning_service.dart';
import 'package:mizan/features/planning/data/budgets_repository.dart';
import 'package:mizan/features/planning/data/recurring_repository.dart';
import 'package:mizan/features/transactions/application/quick_entry_service.dart';

import '../helpers.dart';
import 'services.dart';

void main() {
  late TestEnv env;
  late Stage2 s;
  late RecurringRepository rec;
  late BudgetsRepository budgets;
  late PlanningService plan;
  setUp(() async {
    env = await TestEnv.create();
    s = Stage2(env);
    rec = RecurringRepository(env.db, QuickEntryService(env.ledger, env.accounts),
        deviceId: env.boot.deviceId, clock: env.clock);
    budgets = BudgetsRepository(env.db, env.accounts, deviceId: env.boot.deviceId, clock: env.clock);
    plan = PlanningService(env.accounts, s.loans, s.statements, rec, clock: env.clock);
  });
  tearDown(() => env.dispose());

  test('vade ilerletme: ay sonu ve hafta', () {
    expect(RecurringRepository.advance(DateTime(2026, 1, 31, 12), RecurFrequency.aylik, 1, 31), DateTime(2026, 2, 28, 12));
    expect(RecurringRepository.advance(DateTime(2026, 2, 28, 12), RecurFrequency.aylik, 1, 31), DateTime(2026, 3, 31, 12));
    expect(RecurringRepository.advance(DateTime(2026, 6, 15, 12), RecurFrequency.haftalik, 2, 15), DateTime(2026, 6, 29, 12));
    expect(RecurringRepository.advance(DateTime(2026, 6, 15, 12), RecurFrequency.yillik, 1, 15), DateTime(2027, 6, 15, 12));
  });

  test('tekrarlayan gider kaydedilir, sıradaki vadeye geçer; atlanabilir', () async {
    final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '50.000');
    final kira = await s.categories.ensureByName(env.businessId, 'gider', 'Kira');
    final id = await rec.save(
      businessId: env.businessId,
      name: 'Kira',
      kind: QuickEntryKind.expense,
      accountId: kasa.id,
      categoryId: kira,
      amount: env.tl('15.000'),
      frequency: RecurFrequency.aylik,
      firstDue: DateTime(2026, 6, 20),
    );
    await rec.post(businessId: env.businessId, ruleId: id, idempotencyKey: newId());
    expect(await env.balance(kasa), env.tl('35.000'));
    var r = (await rec.byId(id))!;
    expect(r.nextDue, DateTime(2026, 7, 20, 12));
    await rec.skip(id);
    r = (await rec.byId(id))!;
    expect(r.nextDue, DateTime(2026, 8, 20, 12));
    expect(await env.balance(kasa), env.tl('35.000'));
  });

  test('takvim ve nakit tahmini: maaş, kira, kredi taksiti', () async {
    // Saat: 15 Haziran 2026.
    final banka = await env.account(AccountKind.banka, 'Banka', opening: '10.000');
    final maas = await s.categories.ensureByName(env.businessId, 'gelir', 'Maaş');
    final kira = await s.categories.ensureByName(env.businessId, 'gider', 'Kira');
    await rec.save(
      businessId: env.businessId, name: 'Maaş', kind: QuickEntryKind.income, accountId: banka.id,
      categoryId: maas, amount: env.tl('40.000'), frequency: RecurFrequency.aylik, firstDue: DateTime(2026, 7, 1),
    );
    await rec.save(
      businessId: env.businessId, name: 'Kira', kind: QuickEntryKind.expense, accountId: banka.id,
      categoryId: kira, amount: env.tl('25.000'), frequency: RecurFrequency.aylik, firstDue: DateTime(2026, 6, 20),
    );
    await s.loans.createLoan(
      businessId: env.businessId, name: 'Denizbank', bankName: 'Denizbank', currency: Currency.tryLira,
      total: env.tl('12.000'), installmentCount: 12, installmentAmount: env.tl('1.000'),
      firstDueDate: DateTime(2026, 6, 25), formKey: newId(),
    );

    final p = await plan.snapshot(env.businessId, Currency.tryLira, horizonDays: 30);
    // Ufuk 15 Temmuz: 20 Haz kira, 25 Haz taksit, 1 Tem maaş (20 Tem kira ve 25 Tem taksit dışarıda).
    expect(p.upcoming.map((u) => u.kind).toList(), [UpcomingKind.expense, UpcomingKind.loan, UpcomingKind.income]);
    final f = p.forecast;
    expect(f.start, env.tl('10.000'));
    // 10.000 − 25.000 (20 Haz) − 1.000 (25 Haz) = −16.000; + 40.000 (1 Tem) = 24.000
    expect(f.lowest, -env.tl('16.000'));
    expect(f.end, env.tl('24.000'));
    expect(f.goesNegative, isTrue);
    expect(f.lowestDay, DateTime(2026, 6, 25));
  });

  test('bütçe: alt kategoriler dahil bu ay harcanan', () async {
    final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '10.000');
    final faturalar = await s.categories.ensureByName(env.businessId, 'gider', 'Faturalar');
    final internet = await s.categories.create(
        businessId: env.businessId, type: 'gider', name: 'İnternet', parentId: faturalar);
    await budgets.set(businessId: env.businessId, categoryId: faturalar, limit: env.tl('1.000'));
    final q = QuickEntryService(env.ledger, env.accounts);
    await q.submit(
      kind: QuickEntryKind.expense, businessId: env.businessId, sourceAccountId: kasa.id, categoryId: internet,
      amountText: '850', date: env.clock.now(), idempotencyKey: newId(),
    );
    final st = (await budgets.statuses(env.businessId)).single;
    expect(st.spent, env.tl('850'));
    expect(st.isWarning, isTrue);
    await budgets.set(businessId: env.businessId, categoryId: faturalar, limit: env.tl('800'));
    final st2 = (await budgets.statuses(env.businessId)).single;
    expect(st2.isOver, isTrue);
  });
}
