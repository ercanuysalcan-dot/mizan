import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/assets/data/assets_repository.dart';
import 'package:mizan/features/assets/domain/asset_type.dart';
import 'package:mizan/features/assets/domain/quantity.dart';

import '../helpers.dart';
import 'services.dart';

void main() {
  test('miktar ayrıştırma ve biçim', () {
    expect(Qty.parse('22,76'), 2276000000);
    expect(Qty.parse('0.00123456'), 123456);
    expect(Qty.parse('1.250,5'), 125050000000);
    expect(Qty.format(2276000000), '22,76');
    expect(Qty.format(125050000000), '1.250,5');
    expect(() => Qty.parse('0'), throwsFormatException);
    expect(() => Qty.parse('1,123456789'), throwsFormatException);
  });

  test('gümüş: alış, satış kârı, ortalama maliyet, güncel değer', () async {
    final env = await TestEnv.create();
    addTearDown(env.dispose);
    final s = Stage2(env);
    final repo = AssetsRepository(env.db, env.ledger, env.accounts, s.categories, s.edit,
        deviceId: env.boot.deviceId, clock: env.clock);
    final kasa = await env.account(AccountKind.kasa, 'Kasa', opening: '10.000');

    final gumus = await repo.create(
      businessId: env.businessId, name: 'Ak Gümüş', type: AssetType.gumus, unit: 'gr',
      currency: Currency.tryLira, openingQtyText: '22,76', openingCostText: '910,40', formKey: newId(),
    );
    var a = (await repo.load(gumus.id))!;
    expect(a.quantityE8, Qty.parse('22,76'));
    expect(a.cost, env.tl('910,40'));
    expect(a.averageCost, env.tl('40'));

    await repo.buy(accountId: gumus.id, qtyText: '10', totalText: '500', moneyAccountId: kasa.id,
        date: env.clock.now(), key: newId());
    a = (await repo.load(gumus.id))!;
    expect(Qty.format(a.quantityE8), '32,76');
    expect(a.cost, env.tl('1.410,40'));
    expect(await env.balance(kasa), env.tl('9.500'));

    // 16,38 gr (yarısı) 1.000 ₺'ye satılır: maliyet 705,20 → kâr 294,80
    await repo.sell(accountId: gumus.id, qtyText: '16,38', totalText: '1.000', moneyAccountId: kasa.id,
        date: env.clock.now(), key: newId());
    a = (await repo.load(gumus.id))!;
    expect(Qty.format(a.quantityE8), '16,38');
    expect(a.cost, env.tl('705,20'));
    expect(a.realized, env.tl('294,80'));
    expect(await env.balance(kasa), env.tl('10.500'));

    await repo.setPrice(gumus.id, '50');
    a = (await repo.load(gumus.id))!;
    expect(a.marketValue, env.tl('819'));
    expect(a.unrealized, env.tl('113,80'));

    // Elde olandan fazlası satılamaz; geri alma miktarı ve bakiyeyi düzeltir.
    await expectLater(
      repo.sell(accountId: gumus.id, qtyText: '100', totalText: '1', moneyAccountId: kasa.id,
          date: env.clock.now(), key: newId()),
      throwsA(anything),
    );
    final sale = a.moves.firstWhere((m) => m.type == AssetMoveType.satis);
    await repo.undo(sale.id, newId());
    a = (await repo.load(gumus.id))!;
    expect(Qty.format(a.quantityE8), '32,76');
    expect(a.cost, env.tl('1.410,40'));
    expect(await env.balance(kasa), env.tl('9.500'));
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });

  test('bitcoin: 8 ondalık, zararlı satış', () async {
    final env = await TestEnv.create();
    addTearDown(env.dispose);
    final s = Stage2(env);
    final repo = AssetsRepository(env.db, env.ledger, env.accounts, s.categories, s.edit,
        deviceId: env.boot.deviceId, clock: env.clock);
    final banka = await env.account(AccountKind.banka, 'Banka', opening: '100.000');
    final btc = await repo.create(
      businessId: env.businessId, name: 'Bitcoin', type: AssetType.bitcoin, unit: 'BTC',
      currency: Currency.tryLira, formKey: newId(),
    );
    await repo.buy(accountId: btc.id, qtyText: '0,01234567', totalText: '40.000', moneyAccountId: banka.id,
        date: env.clock.now(), key: newId());
    await repo.sell(accountId: btc.id, qtyText: '0,01234567', totalText: '35.000', moneyAccountId: banka.id,
        date: env.clock.now(), key: newId());
    final a = (await repo.load(btc.id))!;
    expect(a.quantityE8, 0);
    expect(a.cost, env.tl('0'));
    expect(a.realized, -env.tl('5.000'));
    expect(await env.balance(banka), env.tl('95.000'));
    expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
  });
}
