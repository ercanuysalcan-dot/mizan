import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:mizan/app/bootstrap.dart';
import 'package:mizan/core/database/app_database.dart' show AppDatabase;
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/clock.dart';
import 'package:mizan/core/utils/ids.dart';
import 'package:mizan/features/accounting/data/drift_ledger_repository.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounts/data/accounts_repository.dart';
import 'package:mizan/features/settings/data/settings_repository.dart';

/// Bellek içi gerçek SQLite + tüm tetikleyiciler. Her test temiz başlar.
class TestEnv {
  TestEnv._(this.db, this.boot, this.clock, this.ledger, this.accounts, this.settings);

  final AppDatabase db;
  final BootstrapResult boot;
  final FixedClock clock;
  final DriftLedgerRepository ledger;
  final AccountsRepository accounts;
  final SettingsRepository settings;

  String get businessId => boot.business.id;

  static Future<TestEnv> create({DateTime? now}) async {
    final db = AppDatabase(DatabaseConnection(NativeDatabase.memory(), closeStreamsSynchronously: true));
    final clock = FixedClock(now ?? DateTime(2026, 6, 15, 12));
    final boot = await bootstrap(db, clock: clock);
    final ledger = DriftLedgerRepository(db, deviceId: boot.deviceId, clock: clock);
    final accounts = AccountsRepository(db, ledger, deviceId: boot.deviceId, clock: clock);
    return TestEnv._(db, boot, clock, ledger, accounts, SettingsRepository(db, clock: clock));
  }

  Future<void> dispose() => db.close();

  Money tl(String text) => Money.parse(text, Currency.tryLira);

  Future<LedgerAccount> account(AccountKind kind, String name,
      {Currency currency = Currency.tryLira, String? opening, bool normal = true}) {
    return accounts.createAccount(
      businessId: businessId,
      kind: kind,
      name: name,
      currency: currency,
      formKey: newId(),
      openingBalance: opening == null ? null : Money.parse(opening, currency),
      openingInNormalDirection: normal,
    );
  }

  Future<LedgerAccount> category(String type, String name, {Currency currency = Currency.tryLira}) async {
    final c = (await accounts.categories(businessId, type)).firstWhere((x) => x.name == name);
    return accounts.ensureCategoryAccount(businessId, c.id, currency);
  }

  Future<String> post(EntryType type, List<PostingLine> lines, {String? key, DateTime? date}) => ledger.post(
        PostingRequest(
          businessId: businessId,
          type: type,
          date: date ?? clock.now(),
          idempotencyKey: key ?? newId(),
          lines: lines,
        ),
      );

  Future<Money> balance(LedgerAccount a) async => (await ledger.balanceOf(a.id)).balance;
}
