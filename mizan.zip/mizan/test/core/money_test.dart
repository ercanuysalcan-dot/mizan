import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/money/money_format.dart';

void main() {
  const tl = Currency.tryLira;

  group('Money.parse (Türkçe biçim)', () {
    test('gruplama ve ondalık', () {
      expect(Money.parse('1.234,56', tl).minor, 123456);
      expect(Money.parse('1234,5', tl).minor, 123450);
      expect(Money.parse('1.234', tl).minor, 123400);
      expect(Money.parse('0,01', tl).minor, 1);
      expect(Money.parse(',5', tl).minor, 50);
      expect(Money.parse('₺ 12.000.000,99', tl).minor, 1200000099);
      expect(Money.parse('-45,10', tl).minor, -4510);
    });

    test('yuvarlamak yerine reddeder', () {
      expect(() => Money.parse('1,234', tl), throwsFormatException); // 3 ondalık
      expect(() => Money.parse('12.34,5', tl), throwsFormatException); // hatalı gruplama
      expect(() => Money.parse('1,2,3', tl), throwsFormatException);
      expect(() => Money.parse('abc', tl), throwsFormatException);
      expect(() => Money.parse('', tl), throwsFormatException);
      expect(() => Money.parse('5,', tl), throwsFormatException);
    });

    test('nokta ondalık seçeneği', () {
      expect(Money.parse('1,234.56', tl, decimalSeparator: '.').minor, 123456);
    });

    test('güvenli sınır', () {
      expect(() => Money.parse('999.999.999.999.999,99', tl), throwsA(isA<MoneyOverflowError>()));
    });
  });

  group('aritmetik', () {
    test('0,1 + 0,2 tam olarak 0,3', () {
      final a = Money.parse('0,1', tl), b = Money.parse('0,2', tl);
      expect(a + b, Money.parse('0,3', tl));
    });

    test('farklı para birimi toplanamaz', () {
      expect(() => Money.parse('1', tl) + Money.parse('1', Currency.usd), throwsA(isA<CurrencyMismatchError>()));
    });

    test('allocate kuruş kaybetmez', () {
      final parts = Money.parse('100', tl).allocate(3);
      expect(parts.map((m) => m.minor), [3334, 3333, 3333]);
      expect(parts.fold<int>(0, (a, m) => a + m.minor), 10000);
      final neg = Money.fromMinor(-10, tl).allocate(3);
      expect(neg.fold<int>(0, (a, m) => a + m.minor), -10);
    });

    test('multiplyRatio half-even', () {
      // 0,05 × 1/2 = 0,025 → 0,02 (çift), 0,15 × 1/2 = 0,075 → 0,08
      expect(Money.fromMinor(5, tl).multiplyRatio(BigInt.one, BigInt.two).minor, 2);
      expect(Money.fromMinor(15, tl).multiplyRatio(BigInt.one, BigInt.two).minor, 8);
      expect(Money.fromMinor(-15, tl).multiplyRatio(BigInt.one, BigInt.two).minor, -8);
      // %18 KDV: 1.234,56 × 18/100 = 222,2208 → 222,22
      expect(Money.parse('1.234,56', tl).multiplyRatio(BigInt.from(18), BigInt.from(100)).minor, 22222);
    });

    test('divideRounded kipleri', () {
      final seven = BigInt.from(7), two = BigInt.two;
      expect(divideRounded(seven, two, RoundingMode.down), BigInt.from(3));
      expect(divideRounded(seven, two, RoundingMode.up), BigInt.from(4));
      expect(divideRounded(seven, two, RoundingMode.halfUp), BigInt.from(4));
      expect(divideRounded(seven, two, RoundingMode.halfEven), BigInt.from(4));
      expect(divideRounded(BigInt.from(5), two, RoundingMode.halfEven), BigInt.from(2));
    });
  });

  group('biçimlendirme', () {
    test('Türkçe gruplama', () {
      expect(MoneyFormat.format(Money.fromMinor(123456789, tl)), '₺1.234.567,89');
      expect(MoneyFormat.format(Money.fromMinor(-5, tl)), '-₺0,05');
      expect(MoneyFormat.format(Money.fromMinor(100, Currency.azn), showPlus: true), '+₼1,00');
      expect(MoneyFormat.format(Money.fromMinor(0, Currency.eur)), '€0,00');
    });

    test('kısa biçim', () {
      expect(MoneyFormat.compact(1250000, tl), '₺12,5 B');
      expect(MoneyFormat.compact(320000000, tl), '₺3,2 Mn');
      expect(MoneyFormat.compact(99900, tl), '₺999');
    });
  });
}
