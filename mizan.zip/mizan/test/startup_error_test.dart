import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/app/startup_error.dart';

void main() {
  testWidgets('açılış hatası ekranı hata metnini gösterir', (tester) async {
    await tester.pumpWidget(const StartupErrorApp(message: 'deneme hatası', stack: 'yığın'));
    expect(find.text('Mizan açılamadı'), findsOneWidget);
    expect(find.text('Hata metnini kopyala'), findsOneWidget);
    expect(find.textContaining('deneme hatası'), findsOneWidget);
  });
}
