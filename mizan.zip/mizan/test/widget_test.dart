import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/app/app.dart';
import 'package:mizan/app/bootstrap.dart';
import 'package:mizan/app/providers.dart';
import 'package:mizan/core/database/app_database.dart' show AppDatabase;

/// Uygulamanın tamamını bellek içi veritabanıyla açar (duman testi).
void main() {
  testWidgets('ilk açılışta boş dashboard ve başlangıç kartı görünür', (tester) async {
    tester.view.physicalSize = const Size(1280, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.reset);

    final db = AppDatabase(DatabaseConnection(NativeDatabase.memory(), closeStreamsSynchronously: true));
    final boot = (await tester.runAsync(() => bootstrap(db)))!;

    await tester.pumpWidget(ProviderScope(
      overrides: [
        databaseProvider.overrideWithValue(db),
        bootstrapProvider.overrideWithValue(boot),
      ],
      child: const MizanApp(),
    ));
    // Veritabanı akışlarının ilk değerini alması için gerçek zamanda bekle.
    for (var i = 0; i < 5; i++) {
      await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 50)));
      await tester.pump(const Duration(milliseconds: 100));
    }

    expect(find.text('Genel Bakış'), findsWidgets);
    expect(find.text('Hesap oluştur'), findsOneWidget);
    expect(find.text('Örnek verileri yükle'), findsOneWidget);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.runAsync(db.close);
  });
}
