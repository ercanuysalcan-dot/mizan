import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/design_system/design_system.dart';

Widget _wrap(Widget child, {ThemeData? theme}) =>
    MaterialApp(theme: theme ?? MizanTheme.light(), home: Scaffold(body: Center(child: child)));

void main() {
  testWidgets('KpiCard etiketi ve biçimli tutarı gösterir', (tester) async {
    await tester.pumpWidget(_wrap(SizedBox(
      width: 220,
      child: KpiCard(
        label: 'Kasa bakiyesi',
        value: Money.fromMinor(123456, Currency.tryLira),
        icon: Icons.payments_outlined,
        footnote: 'Bu ay',
      ),
    )));
    await tester.pumpAndSettle();
    expect(find.text('Kasa bakiyesi'), findsOneWidget);
    expect(find.text('₺1.234,56'), findsOneWidget);
    expect(find.text('Bu ay'), findsOneWidget);
  });

  testWidgets('MoneyText işaretli tonda negatif tutarı gider rengiyle çizer', (tester) async {
    await tester.pumpWidget(_wrap(MoneyText(Money.fromMinor(-500, Currency.usd), tone: MoneyTone.signed, animate: false)));
    final text = tester.widget<Text>(find.text('-\$5,00'));
    expect(text.style!.color, MizanTokens.light.expense);
  });

  testWidgets('koyu tema da tüm belirteçleri sağlar', (tester) async {
    await tester.pumpWidget(_wrap(
      const EmptyState(icon: Icons.inbox, title: 'Boş', message: 'Kayıt yok'),
      theme: MizanTheme.dark(),
    ));
    expect(find.text('Boş'), findsOneWidget);
    expect(MizanTheme.dark().extension<MizanTokens>(), isNotNull);
  });
}
