import 'package:flutter_test/flutter_test.dart';
import 'package:mizan/core/money/money.dart';
import 'package:mizan/core/utils/date_range.dart';
import 'package:mizan/features/accounting/domain/account_kind.dart';
import 'package:mizan/features/accounting/domain/ledger_models.dart';
import 'package:mizan/features/accounting/domain/posting_rules.dart';
import 'package:mizan/features/dashboard/data/dashboard_repository.dart';
import 'package:mizan/features/dashboard/domain/dashboard_calculator.dart';
import 'package:mizan/features/dashboard/domain/dashboard_models.dart';
import 'package:mizan/features/demo/demo_seeder.dart';

import '../helpers.dart';

AccountBalance bal(AccountKind k, int d, int c, [Currency cur = Currency.tryLira]) =>
    AccountBalance(accountId: '${k.code}-$d-$c', kind: k, currency: cur, debitMinor: d, creditMinor: c);

void main() {
  group('DashboardCalculator', () {
    test('varlık, borç, alacak ve net varlık sınıflandırması', () {
      final r = DashboardCalculator.summarize(
        currency: Currency.tryLira,
        balances: [
          bal(AccountKind.kasa, 1000, 0),
          bal(AccountKind.banka, 5000, 1000),
          bal(AccountKind.birikim, 2000, 0),
          bal(AccountKind.cari, 800, 0), // alacak 800
          bal(AccountKind.cari, 0, 300), // borç 300
          bal(AccountKind.krediKarti, 100, 600), // kart borcu 500
          bal(AccountKind.personel, 0, 200), // ödenecek 200
          bal(AccountKind.personel, 50, 0), // avans 50 → alacak
          bal(AccountKind.gelir, 0, 99999), // dikkate alınmaz
          bal(AccountKind.kasa, 7777, 0, Currency.usd), // başka para birimi
        ],
        periodIncomeMinor: 4000,
        periodExpenseMinor: 1500,
      );
      int k(DashboardKpi x) => r.kpis[x]!.minor;
      expect(k(DashboardKpi.cash), 1000);
      expect(k(DashboardKpi.bank), 4000);
      expect(k(DashboardKpi.totalReceivable), 850);
      expect(k(DashboardKpi.creditCardDebt), 500);
      expect(k(DashboardKpi.totalDebt), 300 + 500 + 200);
      expect(k(DashboardKpi.totalAssets), 1000 + 4000 + 2000 + 850);
      expect(r.netWorth.minor, 7850 - 1000);
      expect(k(DashboardKpi.periodNet), 2500);
      expect(r.assets.map((a) => a.group), [AssetGroup.cash, AssetGroup.bank, AssetGroup.savings, AssetGroup.receivable]);
    });

    test('aylara dağıtım', () {
      final months = [DateTime(2026, 4), DateTime(2026, 5)];
      final pts = DashboardCalculator.bucketMonths(months, [
        (date: DateTime(2026, 4, 3), kind: AccountKind.gelir, debit: 0, credit: 100),
        (date: DateTime(2026, 5, 9), kind: AccountKind.gider, debit: 40, credit: 0),
        (date: DateTime(2026, 5, 9), kind: AccountKind.kasa, debit: 0, credit: 40),
        (date: DateTime(2026, 3, 1), kind: AccountKind.gelir, debit: 0, credit: 999), // aralık dışı
      ]);
      expect(pts[0].income, 100);
      expect(pts[1].expense, 40);
      expect(pts[1].cashNet, -40);
    });
  });

  group('kart düzeni', () {
    test('bozuk veri varsayılana döner, yeni kartlar eklenir', () {
      expect(DashboardRepository.parseLayout('çöp').length, DashboardKpi.values.length);
      final l = DashboardRepository.parseLayout('[{"id":"cash","visible":false},{"id":"yok"}]');
      expect(l.first.kpi, DashboardKpi.cash);
      expect(l.first.visible, isFalse);
      expect(l.length, DashboardKpi.values.length);
    });
  });

  group('DashboardRepository (gerçek veritabanı)', () {
    late TestEnv env;
    setUp(() async => env = await TestEnv.create(now: DateTime(2026, 6, 15, 12)));
    tearDown(() => env.dispose());

    test('dönem filtresi gelir/gideri, bakiyeler dönem sonunu kullanır', () async {
      final repo = DashboardRepository(env.db, env.ledger, env.settings);
      final kasa = await env.account(AccountKind.kasa, 'Kasa');
      final kart = await env.account(AccountKind.krediKarti, 'Kart');
      final satis = await env.category('gelir', 'Satış');
      final market = await env.category('gider', 'Market');
      await env.post(EntryType.gelir,
          PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('1.000')),
          date: DateTime(2026, 5, 20));
      await env.post(EntryType.gelir,
          PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: env.tl('250')),
          date: DateTime(2026, 6, 2));
      await env.post(EntryType.kartHarcama,
          PostingRules.expense(paidFrom: kart, expenseAccount: market, amount: env.tl('80')),
          date: DateTime(2026, 6, 3));

      final june = PeriodFilter(PeriodPreset.month, DateRange.forPreset(PeriodPreset.month, env.clock.now()));
      final d = await repo.load(businessId: env.businessId, period: june, currency: Currency.tryLira);
      expect(d.kpi(DashboardKpi.periodIncome), env.tl('250'));
      expect(d.kpi(DashboardKpi.periodExpense), env.tl('80'));
      expect(d.kpi(DashboardKpi.cash), env.tl('1.250'));
      expect(d.kpi(DashboardKpi.creditCardDebt), env.tl('80'));
      expect(d.netWorth, env.tl('1.170'));
      expect(d.months.length, 6);
      expect(d.months.last.income, 25000);
      expect(d.months[4].income, 100000);
      expect(d.recent.first.type, EntryType.kartHarcama);

      final may = PeriodFilter(PeriodPreset.custom, DateRange(DateTime(2026, 5, 1), DateTime(2026, 6, 1)));
      final m = await repo.load(businessId: env.businessId, period: may, currency: Currency.tryLira);
      expect(m.kpi(DashboardKpi.cash), env.tl('1.000'), reason: 'Mayıs sonu bakiyesi');
      expect(m.kpi(DashboardKpi.periodIncome), env.tl('1.000'));
    });

    test('örnek veri yüklenir ve ters kayıtla tamamen kaldırılır', () async {
      final seeder = DemoSeeder(env.db, env.ledger, env.accounts, env.settings, clock: env.clock);
      final repo = DashboardRepository(env.db, env.ledger, env.settings);
      final period = PeriodFilter(PeriodPreset.year, DateRange.forPreset(PeriodPreset.year, env.clock.now()));

      await seeder.load(env.businessId);
      final loaded = await repo.load(businessId: env.businessId, period: period, currency: Currency.tryLira);
      expect(loaded.hasAnyAccount, isTrue);
      expect(loaded.kpi(DashboardKpi.periodIncome).isPositive, isTrue);
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);

      final n = await seeder.remove(env.businessId);
      expect(n, greaterThan(70));
      final after = await repo.load(businessId: env.businessId, period: period, currency: Currency.tryLira);
      expect(after.netWorth.isZero, isTrue);
      expect(after.kpi(DashboardKpi.periodIncome).isZero, isTrue);
      expect(after.recent, isEmpty);
      expect(await env.ledger.verifyIntegrity(env.businessId), isEmpty);
    });
  });
}
