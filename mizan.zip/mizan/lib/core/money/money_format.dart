import 'money.dart';

/// Görüntüleme biçimlendirici. Hesap yapmaz; yalnızca metin üretir.
abstract final class MoneyFormat {
  /// `₺1.234,56`, `-$12,00` gibi Türkçe gruplamalı biçim.
  static String format(Money m, {bool symbol = true, bool showPlus = false}) {
    final neg = m.minor < 0;
    final abs = m.minor.abs();
    final f = m.currency.minorPerMajor;
    final whole = _group((abs ~/ f).toString());
    final frac = (abs % f).toString().padLeft(m.currency.decimals, '0');
    final body = m.currency.decimals > 0 ? '$whole,$frac' : whole;
    final sign = neg ? '-' : (showPlus && m.minor > 0 ? '+' : '');
    return symbol ? '$sign${m.currency.symbol}$body' : '$sign$body';
  }

  /// Grafik ekseni için kısa biçim (yalnızca gösterim): `₺12,5 B`, `₺3,2 Mn`.
  static String compact(int minor, Currency c) {
    final major = minor.abs() ~/ c.minorPerMajor;
    final sign = minor < 0 ? '-' : '';
    String one(int value, int unit, String suffix) {
      final tenths = (value * 10) ~/ unit;
      final w = tenths ~/ 10, d = tenths % 10;
      return '$sign${c.symbol}${d == 0 ? '$w' : '$w,$d'} $suffix';
    }

    if (major >= 1000000000) return one(major, 1000000000, 'Mr');
    if (major >= 1000000) return one(major, 1000000, 'Mn');
    if (major >= 1000) return one(major, 1000, 'B');
    return '$sign${c.symbol}$major';
  }

  static String _group(String digits) {
    final b = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      if (i > 0 && (digits.length - i) % 3 == 0) b.write('.');
      b.write(digits[i]);
    }
    return b.toString();
  }
}
