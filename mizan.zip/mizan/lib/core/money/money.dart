import 'currency.dart';

export 'currency.dart';

/// Para birimi karışmasına ve yuvarlama hatasına izin vermeyen para değeri.
///
/// * Değer tam sayı minor unit (kuruş) olarak tutulur — double kullanılmaz.
/// * Farklı para birimleri toplanamaz/çıkarılamaz ([CurrencyMismatchError]).
/// * Web'de Dart `int` JavaScript sayısıdır; güvenli aralık ±2^53-1 olduğundan
///   her işlemden sonra sınır denetlenir ([MoneyOverflowError]).
/// * Oran/bölme gerektiren işlemler BigInt ile yapılır ve yuvarlama kuralı
///   açıkça seçilir (varsayılan: bankacı yuvarlaması / half-even).
class Money implements Comparable<Money> {
  const Money._(this.minor, this.currency);

  factory Money.fromMinor(int minor, Currency currency) {
    _checkRange(minor);
    return Money._(minor, currency);
  }

  factory Money.zero(Currency currency) => Money._(0, currency);

  /// Kullanıcı girdisini ondalık kaybı olmadan çözer.
  ///
  /// Türkçe biçim varsayılandır: `1.234,56`. [decimalSeparator] `.` verilirse
  /// `1,234.56` biçimi kabul edilir. Para biriminin ondalık hanesinden fazla
  /// hane girilirse sessizce yuvarlamak yerine [FormatException] fırlatır.
  factory Money.parse(String input, Currency currency, {String decimalSeparator = ','}) {
    assert(decimalSeparator == ',' || decimalSeparator == '.');
    final groupSeparator = decimalSeparator == ',' ? '.' : ',';
    var s = input.trim();
    for (final c in Currency.values) {
      s = s.replaceAll(c.symbol, '').replaceAll(c.code, '');
    }
    s = s.replaceAll(' ', '').replaceAll(' ', '');
    var negative = false;
    if (s.startsWith('-')) {
      negative = true;
      s = s.substring(1);
    } else if (s.startsWith('+')) {
      s = s.substring(1);
    }
    if (s.isEmpty) throw const FormatException('Tutar boş');

    final decIndex = s.lastIndexOf(decimalSeparator);
    var intPart = decIndex >= 0 ? s.substring(0, decIndex) : s;
    final fracPart = decIndex >= 0 ? s.substring(decIndex + 1) : '';
    if (intPart.contains(decimalSeparator)) {
      throw const FormatException('Birden fazla ondalık ayırıcı');
    }
    if (intPart.contains(groupSeparator)) {
      final groups = intPart.split(groupSeparator);
      final valid = groups.first.isNotEmpty &&
          groups.first.length <= 3 &&
          groups.skip(1).every((g) => g.length == 3);
      if (!valid) throw const FormatException('Hatalı basamak ayırıcı');
      intPart = groups.join();
    }
    if (intPart.isEmpty) intPart = '0';
    final digits = RegExp(r'^[0-9]+$');
    if (!digits.hasMatch(intPart) || (fracPart.isNotEmpty && !digits.hasMatch(fracPart))) {
      throw const FormatException('Geçersiz karakter');
    }
    if (decIndex >= 0 && fracPart.isEmpty) {
      throw const FormatException('Ondalık kısım eksik');
    }
    if (fracPart.length > currency.decimals) {
      throw FormatException('En fazla ${currency.decimals} ondalık hane girilebilir');
    }
    final frac = fracPart.padRight(currency.decimals, '0');
    final big = BigInt.parse(intPart) * BigInt.from(currency.minorPerMajor) +
        (frac.isEmpty ? BigInt.zero : BigInt.parse(frac));
    final value = negative ? -big : big;
    if (value.abs() > BigInt.from(maxMinor)) throw MoneyOverflowError();
    return Money._(value.toInt(), currency);
  }

  /// JavaScript'te güvenli tam sayı sınırı (2^53 - 1).
  static const int maxMinor = 9007199254740991;

  final int minor;
  final Currency currency;

  bool get isZero => minor == 0;
  bool get isNegative => minor < 0;
  bool get isPositive => minor > 0;

  Money operator +(Money other) {
    _same(other);
    return Money.fromMinor(minor + other.minor, currency);
  }

  Money operator -(Money other) {
    _same(other);
    return Money.fromMinor(minor - other.minor, currency);
  }

  Money operator -() => Money._(-minor, currency);

  Money abs() => minor < 0 ? -this : this;

  /// Tam sayı çarpımı (ör. adet × birim fiyat). Taşma denetlenir.
  Money times(int factor) {
    final r = BigInt.from(minor) * BigInt.from(factor);
    if (r.abs() > BigInt.from(maxMinor)) throw MoneyOverflowError();
    return Money._(r.toInt(), currency);
  }

  /// `this × numerator / denominator` — örn. yüzde, kur, gram × fiyat.
  /// Yuvarlama kuralı açıkça seçilir; varsayılan half-even.
  Money multiplyRatio(BigInt numerator, BigInt denominator,
      {RoundingMode rounding = RoundingMode.halfEven}) {
    if (denominator == BigInt.zero) throw ArgumentError('Payda sıfır olamaz');
    final r = divideRounded(BigInt.from(minor) * numerator, denominator, rounding);
    if (r.abs() > BigInt.from(maxMinor)) throw MoneyOverflowError();
    return Money._(r.toInt(), currency);
  }

  /// Tutarı kuruş kaybı olmadan [parts] parçaya böler (taksit için).
  /// Artan kuruşlar ilk parçalara dağıtılır; parçaların toplamı her zaman
  /// orijinale eşittir.
  List<Money> allocate(int parts) {
    if (parts <= 0) throw ArgumentError('Parça sayısı pozitif olmalı');
    final base = minor ~/ parts;
    var remainder = minor - base * parts;
    final step = remainder >= 0 ? 1 : -1;
    return List.generate(parts, (_) {
      var v = base;
      if (remainder != 0) {
        v += step;
        remainder -= step;
      }
      return Money._(v, currency);
    });
  }

  void _same(Money other) {
    if (other.currency != currency) throw CurrencyMismatchError(currency, other.currency);
  }

  static void _checkRange(int v) {
    if (v > maxMinor || v < -maxMinor) throw MoneyOverflowError();
  }

  @override
  int compareTo(Money other) {
    _same(other);
    return minor.compareTo(other.minor);
  }

  @override
  bool operator ==(Object other) =>
      other is Money && other.minor == minor && other.currency == currency;

  @override
  int get hashCode => Object.hash(minor, currency);

  /// Makine-okunur gösterim (log/test için): `TRY 1234.56`
  @override
  String toString() {
    final neg = minor < 0;
    final abs = minor.abs();
    final f = currency.minorPerMajor;
    final whole = abs ~/ f;
    final frac = (abs % f).toString().padLeft(currency.decimals, '0');
    return '${currency.code} ${neg ? '-' : ''}$whole${currency.decimals > 0 ? '.$frac' : ''}';
  }
}

enum RoundingMode { halfEven, halfUp, down, up }

/// BigInt bölme + açık yuvarlama.
BigInt divideRounded(BigInt n, BigInt d, RoundingMode mode) {
  if (d.isNegative) {
    n = -n;
    d = -d;
  }
  final q = n ~/ d; // sıfıra doğru keser
  final r = n.remainder(d);
  if (r == BigInt.zero) return q;
  final sign = n.isNegative ? BigInt.from(-1) : BigInt.one;
  switch (mode) {
    case RoundingMode.down:
      return q;
    case RoundingMode.up:
      return q + sign;
    case RoundingMode.halfUp:
      return (r.abs() * BigInt.two >= d) ? q + sign : q;
    case RoundingMode.halfEven:
      final twice = r.abs() * BigInt.two;
      if (twice > d) return q + sign;
      if (twice < d) return q;
      return q.isEven ? q : q + sign;
  }
}

class CurrencyMismatchError extends StateError {
  CurrencyMismatchError(Currency a, Currency b)
      : super('Farklı para birimleri birlikte işlenemez: ${a.code} / ${b.code}');
}

class MoneyOverflowError extends StateError {
  MoneyOverflowError() : super('Tutar güvenli sınırı aşıyor');
}
