/// Desteklenen para birimleri. Tutarlar her zaman "minor unit" (kuruş) cinsinden
/// tam sayı olarak tutulur; [decimals] kaç ondalık hane olduğunu belirtir.
enum Currency {
  tryLira('TRY', '₺', 'Türk Lirası', 2),
  azn('AZN', '₼', 'Azerbaycan Manatı', 2),
  usd('USD', '\$', 'ABD Doları', 2),
  eur('EUR', '€', 'Euro', 2);

  const Currency(this.code, this.symbol, this.label, this.decimals);

  final String code;
  final String symbol;
  final String label;
  final int decimals;

  int get minorPerMajor {
    var f = 1;
    for (var i = 0; i < decimals; i++) {
      f *= 10;
    }
    return f;
  }

  static Currency fromCode(String code) {
    for (final c in Currency.values) {
      if (c.code == code) return c;
    }
    throw ArgumentError.value(code, 'code', 'Desteklenmeyen para birimi');
  }
}
