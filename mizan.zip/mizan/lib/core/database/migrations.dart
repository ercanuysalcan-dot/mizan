/// Şema geçişleri (SQL). Her sürüm, bir önceki sürümden gelen veritabanını
/// `schema/core.drift` ile birebir aynı yapıya getirir.
///
/// tools/verify_schema.py bu dosyadaki r'''…''' bloklarını sırayla okur,
/// eski şema (tools/fixtures/schema_v1.sql) üzerinde verilerle çalıştırır ve
/// sonucu sıfırdan kurulan şemayla karşılaştırır. Bu yüzden ifadeler yalnızca
/// r''' … ''' bloklarında yazılır.
library;

/// v1 → v2: 'kredi' hesap türü (accounts CHECK kısıtı değişir, SQLite'ta
/// tablo yeniden kurulmadan değiştirilemez) + kredi, ekstre ve ek tabloları.
///
/// Tablo yeniden kurulumu SQLite'ın önerdiği yolla yapılır: yeni tablo
/// oluşturulur, veriler kopyalanır, eski tablo silinir, yeni tablo yeniden
/// adlandırılır, indeks ve tetikleyiciler tekrar oluşturulur.
const migrationV1ToV2 = <String>[
  // accounts'a başvuran ve tablo silinince bozulacak tetikleyici.
  r'''DROP TRIGGER IF EXISTS journal_lines_match_account''',
  r'''CREATE TABLE accounts_v2 (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  kind TEXT NOT NULL CHECK (kind IN (
    'cari','banka','kredi_karti','kredi','stok','personel','birikim','kasa',
    'gelir','gider','ozkaynak','kur_farki')),
  normal_side TEXT NOT NULL CHECK (normal_side IN ('D','C')),
  name TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (currency IN ('TRY','AZN','USD','EUR')),
  category_id TEXT REFERENCES categories(id),
  system_role TEXT CHECK (system_role IS NULL OR system_role IN ('acilis_ozkaynak','kur_farki')),
  archived INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER,
  CHECK (
    (kind IN ('cari','banka','stok','birikim','kasa','gider','kur_farki') AND normal_side = 'D')
    OR (kind IN ('kredi_karti','kredi','personel','gelir','ozkaynak') AND normal_side = 'C')
  ),
  CHECK ((kind IN ('gelir','gider')) = (category_id IS NOT NULL))
)''',
  r'''INSERT INTO accounts_v2 (id, business_id, kind, normal_side, name, currency, category_id,
  system_role, archived, sort_order, notes, created_at, updated_at, device_id, sync_status,
  version, deleted_at)
SELECT id, business_id, kind, normal_side, name, currency, category_id,
  system_role, archived, sort_order, notes, created_at, updated_at, device_id, sync_status,
  version, deleted_at
FROM accounts''',
  r'''DROP TABLE accounts''',
  r'''ALTER TABLE accounts_v2 RENAME TO accounts''',
  r'''CREATE INDEX accounts_business_kind ON accounts(business_id, kind)''',
  r'''CREATE UNIQUE INDEX accounts_category_currency
  ON accounts(business_id, category_id, currency) WHERE category_id IS NOT NULL''',
  r'''CREATE UNIQUE INDEX accounts_system_role_currency
  ON accounts(business_id, system_role, currency) WHERE system_role IS NOT NULL''',
  r'''CREATE TRIGGER journal_lines_match_account
BEFORE INSERT ON journal_lines
WHEN NOT EXISTS (
  SELECT 1 FROM accounts a
  WHERE a.id = NEW.account_id AND a.currency = NEW.currency AND a.business_id = NEW.business_id
)
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_ACCOUNT_MISMATCH');
END''',
  r'''CREATE TRIGGER accounts_lock_used
BEFORE UPDATE OF currency, kind, normal_side, business_id ON accounts
WHEN EXISTS (SELECT 1 FROM journal_lines WHERE account_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT, 'ACCOUNT_IN_USE');
END''',
  r'''CREATE TRIGGER accounts_no_delete_used
BEFORE DELETE ON accounts
WHEN EXISTS (SELECT 1 FROM journal_lines WHERE account_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT, 'ACCOUNT_IN_USE');
END''',
  r'''CREATE TABLE loan_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  bank_name TEXT NOT NULL,
  total_minor INTEGER NOT NULL CHECK (total_minor > 0),
  installment_count INTEGER NOT NULL CHECK (installment_count BETWEEN 1 AND 600),
  installment_minor INTEGER NOT NULL CHECK (installment_minor > 0),
  first_due_date INTEGER NOT NULL,
  opening_entry_id TEXT REFERENCES journal_entries(id),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
)''',
  r'''CREATE TABLE loan_installments (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  loan_account_id TEXT NOT NULL REFERENCES accounts(id),
  installment_no INTEGER NOT NULL CHECK (installment_no >= 1),
  due_date INTEGER NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  paid_entry_id TEXT REFERENCES journal_entries(id),
  -- Takibe başlamadan önce ödenmiş taksit (deftere ödeme yazılmaz).
  prepaid INTEGER NOT NULL DEFAULT 0 CHECK (prepaid IN (0, 1)),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  UNIQUE (loan_account_id, installment_no)
)''',
  r'''CREATE INDEX loan_installments_due ON loan_installments(business_id, due_date)''',
  r'''CREATE UNIQUE INDEX loan_installments_paid_entry
  ON loan_installments(paid_entry_id) WHERE paid_entry_id IS NOT NULL''',
  r'''CREATE TABLE card_statements (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  card_account_id TEXT NOT NULL REFERENCES accounts(id),
  statement_date INTEGER NOT NULL,
  due_date INTEGER,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  min_payment_minor INTEGER CHECK (min_payment_minor IS NULL OR min_payment_minor >= 0),
  entry_id TEXT REFERENCES journal_entries(id),
  note TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
)''',
  r'''CREATE INDEX card_statements_card ON card_statements(card_account_id, statement_date)''',
  r'''CREATE TABLE attachments (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  owner_table TEXT NOT NULL CHECK (owner_table IN ('card_statements','journal_entries')),
  owner_id TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_name TEXT,
  size_bytes INTEGER NOT NULL CHECK (size_bytes > 0),
  content BLOB NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
)''',
  r'''CREATE INDEX attachments_owner ON attachments(owner_table, owner_id)''',
];

/// v2 → v3: bütçeler (yalnızca yeni tablo). Tekrarlayan işlemler mevcut
/// recurring_rules tablosunu kullanır.
const migrationV2ToV3 = <String>[
  r'''CREATE TABLE budgets (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  category_id TEXT NOT NULL REFERENCES categories(id),
  currency TEXT NOT NULL CHECK (currency IN ('TRY','AZN','USD','EUR')),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
)''',
  r'''CREATE UNIQUE INDEX budgets_category_currency
  ON budgets(category_id, currency) WHERE deleted_at IS NULL''',
];

/// v3 → v4: varlık (altın, gümüş, kripto, döviz) miktar hareketleri;
/// savings_details yeni varlık türleri (gümüş, bitcoin …) ve güncel fiyat
/// sütunlarıyla yeniden kurulur.
const migrationV3ToV4 = <String>[
  r'''CREATE TABLE savings_details_v4 (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  asset_type TEXT NOT NULL CHECK (asset_type IN (
    'altin','gram_altin','ceyrek_altin','gumus','bitcoin','kripto','dolar','euro','hisse','nakit','diger')),
  unit_label TEXT NOT NULL DEFAULT 'adet',
  price_minor INTEGER CHECK (price_minor IS NULL OR price_minor >= 0),
  price_at INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
)''',
  r'''INSERT INTO savings_details_v4 (account_id, asset_type, unit_label, price_minor, price_at, created_at,
  updated_at, device_id, sync_status, version)
SELECT account_id, asset_type, unit_label, NULL, NULL, created_at, updated_at, device_id, sync_status, version
FROM savings_details''',
  r'''DROP TABLE savings_details''',
  r'''ALTER TABLE savings_details_v4 RENAME TO savings_details''',
  r'''CREATE TABLE asset_movements (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  account_id TEXT NOT NULL REFERENCES accounts(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN ('alis','satis','ekle','cikar')),
  quantity_e8 INTEGER NOT NULL CHECK (quantity_e8 > 0),
  amount_minor INTEGER NOT NULL DEFAULT 0 CHECK (amount_minor >= 0),
  cost_minor INTEGER NOT NULL DEFAULT 0 CHECK (cost_minor >= 0),
  journal_entry_id TEXT REFERENCES journal_entries(id),
  movement_date INTEGER NOT NULL,
  note TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','reversed')),
  idempotency_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
)''',
  r'''CREATE UNIQUE INDEX asset_movements_idempotency ON asset_movements(business_id, idempotency_key)''',
  r'''CREATE INDEX asset_movements_account ON asset_movements(account_id, movement_date)''',
];
