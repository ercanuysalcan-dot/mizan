import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';

/// Platforma göre veritabanı bağlantısı:
/// * Android: uygulama klasöründe yerel SQLite dosyası (sqlite3_flutter_libs).
/// * Web: SQLite WASM; tarayıcı destekliyorsa OPFS, değilse IndexedDB.
///   `web/sqlite3.wasm` ve `web/drift_worker.js` dosyaları gereklidir
///   (bkz. docs/SETUP.md).
QueryExecutor openAppDatabaseConnection() {
  return driftDatabase(
    name: 'mizan',
    web: DriftWebOptions(
      sqlite3Wasm: Uri.parse('sqlite3.wasm'),
      driftWorker: Uri.parse('drift_worker.js'),
    ),
  );
}
