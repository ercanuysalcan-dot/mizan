import 'package:drift/drift.dart';

import 'migrations.dart';

part 'app_database.g.dart';

/// Uygulamanın tek yerel veritabanı. Tablolar, indeksler ve muhasebe
/// tetikleyicileri `schema/core.drift` dosyasından üretilir.
///
/// Diğer dosyalar bu dosyayı `show AppDatabase` ile içe aktarmalıdır; üretilen
/// satır sınıfları (Account, Categorie …) alan sınıflarıyla çakışmasın.
@DriftDatabase(include: {'schema/core.drift'})
class AppDatabase extends _$AppDatabase {
  AppDatabase(super.executor);

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (m) => m.createAll(),
        onUpgrade: (m, from, to) async {
          // Tablo yeniden kurulurken yabancı anahtar denetimi geçici olarak
          // ertelenir; işlem sonunda tüm başvurular yeniden geçerli olur.
          await customStatement('PRAGMA foreign_keys = OFF');
          await transaction(() async {
            await customStatement('PRAGMA defer_foreign_keys = ON');
            if (from < 2) {
              for (final sql in migrationV1ToV2) {
                await customStatement(sql);
              }
            }
          });
        },
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );

  /// Herhangi bir tabloda değişiklik olduğunda [load] sonucunu yeniden yayınlar.
  /// Dashboard gibi birden çok tabloyu birleştiren ekranlar için.
  Stream<T> watchAll<T>(Future<T> Function() load) async* {
    yield await load();
    await for (final _ in tableUpdates()) {
      yield await load();
    }
  }

  /// Yazma işlemlerinde akışları bilgilendirmek için tüm tablolar.
  Set<TableInfo<Table, dynamic>> get everyTable => allTables.toSet();
}
