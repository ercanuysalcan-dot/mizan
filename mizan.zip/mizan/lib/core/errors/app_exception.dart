/// Kullanıcıya gösterilebilir, kodlu uygulama hatası.
class AppException implements Exception {
  const AppException(this.code, this.message);
  final String code;
  final String message;
  @override
  String toString() => '$code: $message';
}

/// Muhasebe motoru hataları. Kodlar veritabanı tetikleyicileriyle aynıdır.
class LedgerException extends AppException {
  const LedgerException(super.code, super.message);

  static const codes = <String, String>{
    'LEDGER_UNBALANCED': 'Kayıt dengesiz: borç ve alacak toplamları eşit değil.',
    'LEDGER_ENTRY_NOT_DRAFT': 'Kesinleşmiş kayda satır eklenemez.',
    'LEDGER_ACCOUNT_MISMATCH': 'Satırın para birimi veya işletmesi hesapla uyuşmuyor.',
    'LEDGER_IMMUTABLE': 'Kesinleşmiş kayıt değiştirilemez; iptal (ters kayıt) kullanın.',
    'LEDGER_BAD_STATUS': 'Geçersiz kayıt durumu geçişi.',
    'LEDGER_ALREADY_REVERSED': 'Bu işlem zaten iptal edilmiş.',
    'LEDGER_NOT_FOUND': 'İşlem bulunamadı.',
    'LEDGER_INVALID': 'İşlem bilgileri geçersiz.',
    'ACCOUNT_IN_USE': 'Hareketi olan hesabın türü/para birimi değiştirilemez.',
    'ACCOUNT_ARCHIVED': 'Arşivlenmiş hesaba işlem yapılamaz.',
  };

  /// SQLite hatasını tanınan bir koda çevirir; tanınmazsa null.
  static LedgerException? fromDatabaseError(Object error) {
    final text = error.toString();
    for (final e in codes.entries) {
      if (text.contains(e.key)) return LedgerException(e.key, e.value);
    }
    return null;
  }

  factory LedgerException.of(String code, [String? detail]) =>
      LedgerException(code, detail ?? codes[code] ?? code);
}
