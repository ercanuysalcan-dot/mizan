/// Yerel veri yüklemeye ihtiyaç duymayan Türkçe tarih biçimleri.
/// (intl yerel verisi testlerde ve ilk açılışta hazır olmayabilir.)
abstract final class TrFormat {
  static const monthsShort = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];
  static const monthsLong = [
    'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
    'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
  ];

  static String two(int v) => v.toString().padLeft(2, '0');

  /// 05.03.2026
  static String date(DateTime d) => '${two(d.day)}.${two(d.month)}.${d.year}';

  /// 5 Mar
  static String dayMonth(DateTime d) => '${d.day} ${monthsShort[d.month - 1]}';

  /// 5 Mar 2026, 14:05
  static String dateTime(DateTime d) =>
      '${d.day} ${monthsShort[d.month - 1]} ${d.year}, ${two(d.hour)}:${two(d.minute)}';

  static String monthShort(DateTime d) => monthsShort[d.month - 1];

  static String monthYear(DateTime d) => '${monthsLong[d.month - 1]} ${d.year}';
}
