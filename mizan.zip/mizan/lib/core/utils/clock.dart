/// Test edilebilir saat. Uygulama genelinde `DateTime.now()` yerine kullanılır.
class Clock {
  const Clock();
  DateTime now() => DateTime.now();
  int nowMs() => DateTime.now().toUtc().millisecondsSinceEpoch;
}

class FixedClock extends Clock {
  FixedClock(this.value);
  DateTime value;
  @override
  DateTime now() => value;
  @override
  int nowMs() => value.toUtc().millisecondsSinceEpoch;
}
