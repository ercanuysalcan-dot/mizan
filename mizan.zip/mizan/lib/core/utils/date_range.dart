/// Dashboard ve raporlarda kullanılan dönem filtresi.
enum PeriodPreset { today, week, month, year, custom }

extension PeriodPresetLabel on PeriodPreset {
  String get label => switch (this) {
        PeriodPreset.today => 'Bugün',
        PeriodPreset.week => 'Bu hafta',
        PeriodPreset.month => 'Bu ay',
        PeriodPreset.year => 'Bu yıl',
        PeriodPreset.custom => 'Özel',
      };
}

/// Yerel saatte [start] dahil, [end] hariç aralık.
class DateRange {
  const DateRange(this.start, this.end);

  final DateTime start;
  final DateTime end;

  int get startMs => start.toUtc().millisecondsSinceEpoch;
  int get endMs => end.toUtc().millisecondsSinceEpoch;

  bool contains(DateTime t) => !t.isBefore(start) && t.isBefore(end);

  /// Hazır dönemi [now] anına göre hesaplar. Hafta Pazartesi başlar.
  static DateRange forPreset(PeriodPreset p, DateTime now) {
    final today = DateTime(now.year, now.month, now.day);
    return switch (p) {
      PeriodPreset.today => DateRange(today, DateTime(now.year, now.month, now.day + 1)),
      PeriodPreset.week => () {
          final start = DateTime(today.year, today.month, today.day - (today.weekday - 1));
          return DateRange(start, DateTime(start.year, start.month, start.day + 7));
        }(),
      PeriodPreset.month => DateRange(DateTime(now.year, now.month), DateTime(now.year, now.month + 1)),
      PeriodPreset.year => DateRange(DateTime(now.year), DateTime(now.year + 1)),
      PeriodPreset.custom => DateRange(DateTime(now.year, now.month), DateTime(now.year, now.month + 1)),
    };
  }

  /// [end] ayı dahil geriye doğru [count] ay (grafikler için).
  static List<DateRange> trailingMonths(DateTime end, int count) {
    final last = DateTime(end.year, end.month);
    return List.generate(count, (i) {
      final s = DateTime(last.year, last.month - (count - 1 - i));
      return DateRange(s, DateTime(s.year, s.month + 1));
    });
  }

  @override
  bool operator ==(Object other) => other is DateRange && other.start == start && other.end == end;

  @override
  int get hashCode => Object.hash(start, end);
}

class PeriodFilter {
  const PeriodFilter(this.preset, this.range);
  final PeriodPreset preset;
  final DateRange range;

  @override
  bool operator ==(Object other) =>
      other is PeriodFilter && other.preset == preset && other.range == range;

  @override
  int get hashCode => Object.hash(preset, range);
}
