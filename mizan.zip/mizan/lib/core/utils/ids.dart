import 'package:uuid/uuid.dart';

const _uuid = Uuid();

/// Zaman sıralı UUID v7 — senkronizasyon ve indeks dostu.
String newId() => _uuid.v7();
