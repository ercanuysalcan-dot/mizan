import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/database/app_database.dart' show AppDatabase;
import '../core/utils/clock.dart';
import '../features/accounting/data/drift_ledger_repository.dart';
import '../features/accounting/domain/ledger_repository.dart';
import '../features/accounts/data/accounts_repository.dart';
import '../features/settings/data/settings_repository.dart';
import 'bootstrap.dart';

/// Bağımlılık enjeksiyonu kökü. Bu sağlayıcılar main.dart içinde
/// açılmış veritabanı ve bootstrap sonucu ile `overrideWithValue` edilir;
/// testlerde bellek içi veritabanı verilir.
final databaseProvider = Provider<AppDatabase>((ref) => throw UnimplementedError('databaseProvider'));

final bootstrapProvider = Provider<BootstrapResult>((ref) => throw UnimplementedError('bootstrapProvider'));

final clockProvider = Provider<Clock>((ref) => const Clock());

final deviceIdProvider = Provider<String>((ref) => ref.watch(bootstrapProvider).deviceId);

/// Seçili şirket (işletme). Şirket değişince ona bağlı tüm ekranlar ve
/// veriler kendiliğinden yeniden yüklenir.
class CurrentBusinessNotifier extends Notifier<BusinessInfo> {
  @override
  BusinessInfo build() => ref.watch(bootstrapProvider).business;

  void select(BusinessInfo business) => state = business;
}

final currentBusinessProvider =
    NotifierProvider<CurrentBusinessNotifier, BusinessInfo>(CurrentBusinessNotifier.new);

final ledgerRepositoryProvider = Provider<LedgerRepository>((ref) => DriftLedgerRepository(
      ref.watch(databaseProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final accountsRepositoryProvider = Provider<AccountsRepository>((ref) => AccountsRepository(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final settingsRepositoryProvider = Provider<SettingsRepository>(
    (ref) => SettingsRepository(ref.watch(databaseProvider), clock: ref.watch(clockProvider)));
