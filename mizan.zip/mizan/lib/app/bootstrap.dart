import 'package:drift/drift.dart';

import '../core/database/app_database.dart' show AppDatabase;
import '../core/money/money.dart';
import '../core/utils/clock.dart';
import '../core/utils/ids.dart';
import '../features/settings/data/settings_repository.dart';

class BusinessInfo {
  const BusinessInfo({required this.id, required this.name, required this.baseCurrency});
  final String id;
  final String name;
  final Currency baseCurrency;
}

class BootstrapResult {
  const BootstrapResult({required this.deviceId, required this.business});
  final String deviceId;
  final BusinessInfo business;
}

/// İlk açılış: cihaz kimliği ve varsayılan işletme + kategoriler.
/// Tekrar çalıştırılması güvenlidir (idempotent).
Future<BootstrapResult> bootstrap(AppDatabase db, {Clock clock = const Clock()}) async {
  final settings = SettingsRepository(db, clock: clock);
  final storedDeviceId = await settings.get(SettingsRepository.deviceIdKey);
  final String deviceId = storedDeviceId ?? newId();
  if (storedDeviceId == null) {
    await settings.set(SettingsRepository.deviceIdKey, deviceId);
  }

  final active = await settings.get(SettingsRepository.activeBusinessKey);
  final rows = await db.customSelect(
    'SELECT id, name, base_currency FROM businesses WHERE deleted_at IS NULL ORDER BY created_at',
  ).get();
  if (rows.isNotEmpty) {
    final row = rows.firstWhere((r) => r.read<String>('id') == active, orElse: () => rows.first);
    return BootstrapResult(
      deviceId: deviceId,
      business: BusinessInfo(
        id: row.read<String>('id'),
        name: row.read<String>('name'),
        baseCurrency: Currency.fromCode(row.read<String>('base_currency')),
      ),
    );
  }

  final businessId = newId();
  final now = clock.nowMs();
  await db.transaction(() async {
    await db.customInsert(
      'INSERT INTO businesses (id, name, base_currency, created_at, updated_at, device_id) '
      'VALUES (?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(businessId),
        Variable.withString('İşletmem'),
        Variable.withString(Currency.tryLira.code),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: db.everyTable,
    );
    await seedDefaultCategories(db, businessId: businessId, deviceId: deviceId, nowMs: now);
  });
  await settings.set(SettingsRepository.activeBusinessKey, businessId);
  return BootstrapResult(
    deviceId: deviceId,
    business: BusinessInfo(id: businessId, name: 'İşletmem', baseCurrency: Currency.tryLira),
  );
}

/// Yeni işletmenin varsayılan gelir/gider kategorileri.
Future<void> seedDefaultCategories(
  AppDatabase db, {
  required String businessId,
  required String deviceId,
  required int nowMs,
}) async {
  var order = 0;
  for (final entry in _defaultCategories.entries) {
    for (final name in entry.value) {
      await db.customInsert(
        'INSERT INTO categories (id, business_id, category_type, name, sort_order, created_at, '
        'updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(newId()),
          Variable.withString(businessId),
          Variable.withString(entry.key),
          Variable.withString(name),
          Variable.withInt(order++),
          Variable.withInt(nowMs),
          Variable.withInt(nowMs),
          Variable.withString(deviceId),
        ],
        updates: db.everyTable,
      );
    }
  }
}

const _defaultCategories = <String, List<String>>{
  'gelir': ['Satış', 'Hizmet Geliri', 'Faiz / Getiri', 'Diğer Gelir'],
  'gider': ['Kira', 'Maaş', 'Faturalar', 'Market', 'Ulaşım', 'Vergi', 'Diğer Gider'],
};
