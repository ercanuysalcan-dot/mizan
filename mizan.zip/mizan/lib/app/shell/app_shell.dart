import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../design_system/design_system.dart';
import '../../features/transactions/presentation/quick_entry_sheet.dart';
import '../providers.dart';

class _Destination {
  const _Destination(this.label, this.icon, this.selectedIcon);
  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

const _destinations = [
  _Destination('Genel Bakış', Icons.space_dashboard_outlined, Icons.space_dashboard_rounded),
  _Destination('İşlemler', Icons.receipt_long_outlined, Icons.receipt_long_rounded),
  _Destination('Plan', Icons.event_note_outlined, Icons.event_note_rounded),
  _Destination('Hesaplar', Icons.account_balance_wallet_outlined, Icons.account_balance_wallet_rounded),
  _Destination('Ayarlar', Icons.tune_outlined, Icons.tune_rounded),
];

/// Uyarlanabilir kabuk: telefonda alt gezinme çubuğu, tablette ray,
/// geniş ekranda açık kenar menüsü.
class AppShell extends ConsumerWidget {
  const AppShell({super.key, required this.shell});
  final StatefulNavigationShell shell;

  void _go(int i) => shell.goBranch(i, initialLocation: i == shell.currentIndex);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final size = windowSizeOf(context);
    final showFab = shell.currentIndex != 4; // Ayarlar'da gizli
    final fab = showFab
        ? FloatingActionButton.extended(
            heroTag: 'quick-entry',
            onPressed: () => showQuickEntrySheet(context),
            icon: const Icon(Icons.add_rounded),
            label: const Text('İşlem ekle'),
          )
        : null;

    if (size == WindowSize.compact) {
      return Scaffold(
        body: shell,
        floatingActionButton: fab,
        bottomNavigationBar: NavigationBar(
          selectedIndex: shell.currentIndex,
          onDestinationSelected: _go,
          destinations: [
            for (final d in _destinations)
              NavigationDestination(icon: Icon(d.icon), selectedIcon: Icon(d.selectedIcon), label: d.label),
          ],
        ),
      );
    }

    final extended = size == WindowSize.expanded || size == WindowSize.large;
    final business = ref.watch(currentBusinessProvider);
    return Scaffold(
      floatingActionButton: fab,
      body: Row(
        children: [
          NavigationRail(
            extended: extended,
            minExtendedWidth: 232,
            selectedIndex: shell.currentIndex,
            onDestinationSelected: _go,
            leading: Padding(
              padding: const EdgeInsets.fromLTRB(Space.sm, Space.lg, Space.sm, Space.xl),
              child: extended
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const BrandWordmark(),
                        Space.gapXs,
                        Text(business.name, style: context.text.bodySmall),
                      ],
                    )
                  : const BrandMark(),
            ),
            destinations: [
              for (final d in _destinations)
                NavigationRailDestination(
                  icon: Icon(d.icon),
                  selectedIcon: Icon(d.selectedIcon),
                  label: Text(d.label),
                ),
            ],
          ),
          VerticalDivider(width: 1, color: context.tokens.border),
          Expanded(child: shell),
        ],
      ),
    );
  }
}
