import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Uygulama açılamadığında gösterilen ekran. Hata metnini gösterir ve
/// kopyalanabilmesini sağlar; böylece sorun boş ekran yerine okunabilir olur.
class StartupErrorApp extends StatelessWidget {
  const StartupErrorApp({super.key, required this.message, this.stack = ''});

  final String message;
  final String stack;

  String get _report => 'Mizan açılış hatası\n\n$message\n\n$stack';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mizan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0A1A33), brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: Builder(
        builder: (context) => Scaffold(
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                const Icon(Icons.error_outline, size: 48, color: Color(0xFFFF8A80)),
                const SizedBox(height: 16),
                Text('Mizan açılamadı', style: Theme.of(context).textTheme.headlineSmall),
                const SizedBox(height: 8),
                const Text(
                  'Verileriniz silinmedi. Aşağıdaki hata metnini kopyalayıp geliştiriciye iletin, '
                  'ardından sayfayı yenileyerek tekrar deneyin.',
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: _report));
                    if (context.mounted) {
                      ScaffoldMessenger.of(context)
                          .showSnackBar(const SnackBar(content: Text('Hata metni kopyalandı')));
                    }
                  },
                  icon: const Icon(Icons.copy),
                  label: const Text('Hata metnini kopyala'),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: SelectableText(
                    _report,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
