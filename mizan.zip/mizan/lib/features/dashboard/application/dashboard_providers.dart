import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/date_range.dart';
import '../data/dashboard_repository.dart';
import '../domain/dashboard_models.dart';

final dashboardRepositoryProvider = Provider<DashboardRepository>((ref) => DashboardRepository(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(settingsRepositoryProvider),
    ));

/// Seçili dönem (ViewModel durumu).
class DashboardPeriodNotifier extends Notifier<PeriodFilter> {
  @override
  PeriodFilter build() {
    final now = ref.watch(clockProvider).now();
    return PeriodFilter(PeriodPreset.month, DateRange.forPreset(PeriodPreset.month, now));
  }

  void selectPreset(PeriodPreset p) {
    if (p == PeriodPreset.custom) return; // özel aralık selectCustom ile gelir
    state = PeriodFilter(p, DateRange.forPreset(p, ref.read(clockProvider).now()));
  }

  /// [start] ve [end] gün olarak dahildir.
  void selectCustom(DateTime start, DateTime end) {
    final s = DateTime(start.year, start.month, start.day);
    final e = DateTime(end.year, end.month, end.day + 1);
    state = PeriodFilter(PeriodPreset.custom, DateRange(s, e));
  }
}

final dashboardPeriodProvider =
    NotifierProvider<DashboardPeriodNotifier, PeriodFilter>(DashboardPeriodNotifier.new);

class DashboardCurrencyNotifier extends Notifier<Currency> {
  @override
  Currency build() => ref.watch(currentBusinessProvider).baseCurrency;
  void select(Currency c) => state = c;
}

final dashboardCurrencyProvider =
    NotifierProvider<DashboardCurrencyNotifier, Currency>(DashboardCurrencyNotifier.new);

final dashboardDataProvider = StreamProvider.autoDispose<DashboardData>((ref) {
  return ref.watch(dashboardRepositoryProvider).watch(
        businessId: ref.watch(currentBusinessProvider).id,
        period: ref.watch(dashboardPeriodProvider),
        currency: ref.watch(dashboardCurrencyProvider),
      );
});

final dashboardLayoutProvider = StreamProvider<List<KpiSlot>>(
  (ref) => ref.watch(dashboardRepositoryProvider).watchLayout(),
);
