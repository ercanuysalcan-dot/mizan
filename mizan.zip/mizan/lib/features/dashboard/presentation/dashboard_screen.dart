import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/date_range.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounts/presentation/create_account_sheet.dart';
import '../../business/presentation/business_widgets.dart';
import '../../settings/application/settings_providers.dart';
import '../application/dashboard_providers.dart';
import '../data/dashboard_repository.dart';
import '../domain/dashboard_models.dart';
import 'widgets/charts.dart';
import 'widgets/kpi_grid.dart';
import 'widgets/kpi_layout_sheet.dart';
import 'widgets/net_worth_hero.dart';
import 'widgets/recent_entries_card.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final period = ref.watch(dashboardPeriodProvider);
    final data = ref.watch(dashboardDataProvider);
    final layout = ref.watch(dashboardLayoutProvider).valueOrNull ?? DashboardRepository.defaultLayout;
    final business = ref.watch(currentBusinessProvider);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: data.when(
          skipLoadingOnReload: true,
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, st) => Center(
            child: EmptyState(icon: Icons.error_outline_rounded, title: 'Veriler yüklenemedi', message: '$e'),
          ),
          data: (d) => LayoutBuilder(builder: (context, c) {
            final size = c.windowSize;
            final hPad = size == WindowSize.compact ? Space.lg : Space.xxl;
            return Align(
              alignment: Alignment.topCenter,
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1440),
                child: CustomScrollView(
                  slivers: [
                    SliverPadding(
                      padding: EdgeInsets.fromLTRB(hPad, Space.lg, hPad, 120),
                      sliver: SliverList.list(children: [
                        _Header(businessName: business.name, layout: layout),
                        Space.gapLg,
                        _Filters(period: period, data: d),
                        Space.gapLg,
                        if (!d.hasAnyAccount)
                          const _Onboarding()
                        else
                          _Body(data: d, layout: layout, period: period, size: size),
                      ]),
                    ),
                  ],
                ),
              ),
            );
          }),
        ),
      ),
    );
  }
}

String periodLabel(PeriodFilter p) => p.preset == PeriodPreset.custom
    ? '${TrFormat.dayMonth(p.range.start)} – '
        '${TrFormat.dayMonth(p.range.end.subtract(const Duration(days: 1)))}'
    : p.preset.label;

class _Header extends StatelessWidget {
  const _Header({required this.businessName, required this.layout});
  final String businessName;
  final List<KpiSlot> layout;

  @override
  Widget build(BuildContext context) {
    final compact = windowSizeOf(context) == WindowSize.compact;
    return Row(
      children: [
        if (compact) ...[const BrandMark(size: 36), Space.gapMd],
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Genel Bakış', style: context.text.headlineMedium),
              const BusinessSwitchButton(),
            ],
          ),
        ),
        IconButton.outlined(
          tooltip: 'Kartları düzenle',
          onPressed: () => showKpiLayoutSheet(context, layout),
          icon: const Icon(Icons.dashboard_customize_outlined),
        ),
      ],
    );
  }
}

class _Filters extends ConsumerWidget {
  const _Filters({required this.period, required this.data});
  final PeriodFilter period;
  final DashboardData data;

  Future<void> _pickCustom(BuildContext context, WidgetRef ref) async {
    final now = ref.read(clockProvider).now();
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 5, 12, 31),
      initialDateRange: DateTimeRange(
        start: period.range.start,
        end: period.range.end.subtract(const Duration(days: 1)),
      ),
      helpText: 'Tarih aralığı seç',
      saveText: 'Uygula',
    );
    if (picked != null) {
      ref.read(dashboardPeriodProvider.notifier).selectCustom(picked.start, picked.end);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currencies = data.availableCurrencies;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final p in PeriodPreset.values) ...[
            ChoiceChip(
              label: Text(p == PeriodPreset.custom && period.preset == PeriodPreset.custom
                  ? periodLabel(period)
                  : p.label),
              avatar: p == PeriodPreset.custom ? const Icon(Icons.date_range_rounded, size: 16) : null,
              selected: period.preset == p,
              onSelected: (_) => p == PeriodPreset.custom
                  ? _pickCustom(context, ref)
                  : ref.read(dashboardPeriodProvider.notifier).selectPreset(p),
            ),
            Space.gapSm,
          ],
          if (currencies.length > 1 || (currencies.isNotEmpty && !currencies.contains(data.currency))) ...[
            Container(width: 1, height: 24, color: context.tokens.border),
            Space.gapSm,
            for (final c in {...currencies, data.currency}) ...[
              ChoiceChip(
                label: Text(c.code),
                selected: data.currency == c,
                onSelected: (_) => ref.read(dashboardCurrencyProvider.notifier).select(c),
              ),
              Space.gapSm,
            ],
          ],
        ],
      ),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.data, required this.layout, required this.period, required this.size});
  final DashboardData data;
  final List<KpiSlot> layout;
  final PeriodFilter period;
  final WindowSize size;

  @override
  Widget build(BuildContext context) {
    final label = periodLabel(period);
    final hero = NetWorthHero(data: data, periodLabel: label);
    final kpis = KpiGrid(data: data, slots: layout, periodLabel: label);
    final incomeExpense = IncomeExpenseChart(months: data.months, currency: data.currency);
    final cashFlow = CashFlowChart(months: data.months, currency: data.currency);
    final assets = AssetDistributionCard(slices: data.assets, currency: data.currency);
    final debtRec = DebtReceivableCard(
      receivable: data.kpi(DashboardKpi.totalReceivable),
      debt: data.kpi(DashboardKpi.totalDebt),
    );
    final wide = size == WindowSize.expanded || size == WindowSize.large;
    final recent = RecentEntriesCard(entries: data.recent, maxItems: wide ? 8 : 6);

    Widget row(List<(int, Widget)> items) => Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var i = 0; i < items.length; i++) ...[
              if (i > 0) Space.gapLg,
              Expanded(flex: items[i].$1, child: items[i].$2),
            ],
          ],
        );

    final List<Widget> children = switch (size) {
      WindowSize.compact => [hero, kpis, incomeExpense, cashFlow, recent, assets, debtRec],
      WindowSize.medium => [
          hero,
          kpis,
          incomeExpense,
          row([(1, assets), (1, debtRec)]),
          cashFlow,
          recent,
        ],
      _ => [
          row([(5, hero), (3, debtRec)]),
          kpis,
          row([(3, incomeExpense), (2, assets)]),
          row([(3, cashFlow), (2, recent)]),
        ],
    };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < children.length; i++) ...[
          if (i > 0) Space.gapLg,
          TweenAnimationBuilder<double>(
            tween: Tween(begin: 0, end: 1),
            duration: Duration(milliseconds: 280 + i * 60),
            curve: Motion.curve,
            builder: (_, v, child) => Opacity(
              opacity: v,
              child: Transform.translate(offset: Offset(0, (1 - v) * 12), child: child),
            ),
            child: children[i],
          ),
        ],
      ],
    );
  }
}

/// Hiç hesap yokken gösterilen başlangıç alanı. İki düğme de gerçek iş yapar.
class _Onboarding extends ConsumerStatefulWidget {
  const _Onboarding();
  @override
  ConsumerState<_Onboarding> createState() => _OnboardingState();
}

class _OnboardingState extends ConsumerState<_Onboarding> {
  bool _busy = false;

  Future<void> _loadDemo() async {
    setState(() => _busy = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(demoSeederProvider).load(ref.read(currentBusinessProvider).id);
      messenger.showSnackBar(const SnackBar(
        content: Text('Örnek veriler yüklendi. Ayarlar’dan tek dokunuşla kaldırabilirsin.'),
      ));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return MizanCard(
      padding: const EdgeInsets.all(Space.xxl),
      child: Column(
        children: [
          const BrandMark(size: 56),
          Space.gapLg,
          Text('Mizan’a hoş geldin', style: context.text.headlineSmall, textAlign: TextAlign.center),
          Space.gapSm,
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 460),
            child: Text(
              'Varlıklarını, borç ve alacaklarını tek yerde görmek için ilk hesabını oluştur. '
              'Önce denemek istersen 6 aylık örnek işletme verisi yükleyebilirsin.',
              style: context.text.bodyMedium!.copyWith(color: context.tokens.subtleText),
              textAlign: TextAlign.center,
            ),
          ),
          Space.gapXl,
          Wrap(
            spacing: Space.md,
            runSpacing: Space.md,
            alignment: WrapAlignment.center,
            children: [
              FilledButton.icon(
                onPressed: () => showCreateAccountSheet(context),
                icon: const Icon(Icons.add_rounded),
                label: const Text('Hesap oluştur'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _loadDemo,
                icon: _busy
                    ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.auto_awesome_outlined),
                label: const Text('Örnek verileri yükle'),
              ),
            ],
          ),
          Space.gapLg,
          Text('Para birimi: ${Currency.tryLira.code} varsayılan · AZN, USD, EUR desteklenir',
              style: context.text.bodySmall),
        ],
      ),
    );
  }
}
