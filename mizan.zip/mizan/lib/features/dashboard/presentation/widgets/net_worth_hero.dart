import 'package:flutter/material.dart';

import '../../../../core/money/money.dart';
import '../../../../core/money/money_format.dart';
import '../../../../design_system/design_system.dart';
import '../../domain/dashboard_models.dart';

/// Üstteki ana kart: net varlık ve varlık / borç özeti.
class NetWorthHero extends StatelessWidget {
  const NetWorthHero({super.key, required this.data, required this.periodLabel});

  final DashboardData data;
  final String periodLabel;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final fg = t.heroForeground;
    final assets = data.kpi(DashboardKpi.totalAssets);
    final debt = data.kpi(DashboardKpi.totalDebt);
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(gradient: t.heroGradient, borderRadius: Radii.card),
      padding: const EdgeInsets.all(Space.xl),
      child: Stack(
        children: [
          Positioned(
            right: -30,
            top: -40,
            child: IgnorePointer(
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: MizanPalette.teal400.withValues(alpha: 0.25), width: 22),
                ),
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text('NET VARLIK',
                      style: context.text.labelSmall!.copyWith(color: fg.withValues(alpha: 0.7))),
                  const Spacer(),
                  _Pill(text: '${data.currency.code} · $periodLabel sonu', color: fg),
                ],
              ),
              Space.gapSm,
              FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: MoneyText(
                  data.netWorth,
                  style: context.text.displaySmall!.copyWith(color: fg),
                ),
              ),
              Space.gapXl,
              Row(
                children: [
                  Expanded(child: _HeroStat(label: 'Varlıklar', value: assets, dot: MizanPalette.teal400)),
                  Container(width: 1, height: 36, color: fg.withValues(alpha: 0.15)),
                  const SizedBox(width: Space.lg),
                  Expanded(child: _HeroStat(label: 'Borçlar', value: debt, dot: const Color(0xFFFF8A8E))),
                ],
              ),
              Space.gapLg,
              _RatioBar(assets: assets, debt: debt),
            ],
          ),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  const _HeroStat({required this.label, required this.value, required this.dot});
  final String label;
  final Money value;
  final Color dot;

  @override
  Widget build(BuildContext context) {
    final fg = context.tokens.heroForeground;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Container(width: 8, height: 8, decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(label, style: context.text.bodySmall!.copyWith(color: fg.withValues(alpha: 0.7))),
        ]),
        const SizedBox(height: 2),
        FittedBox(
          fit: BoxFit.scaleDown,
          alignment: Alignment.centerLeft,
          child: Text(MoneyFormat.format(value),
              style: context.text.titleMedium!.copyWith(color: fg, fontFeatures: MizanTheme.tabular)),
        ),
      ],
    );
  }
}

class _RatioBar extends StatelessWidget {
  const _RatioBar({required this.assets, required this.debt});
  final Money assets;
  final Money debt;

  @override
  Widget build(BuildContext context) {
    final a = assets.minor < 0 ? 0 : assets.minor;
    final d = debt.minor < 0 ? 0 : debt.minor;
    final total = a + d;
    // Yalnızca görsel oran (BigInt: büyük tutarlarda taşma olmasın).
    var aFlex = total == 0 ? 500 : (BigInt.from(a) * BigInt.from(1000) ~/ BigInt.from(total)).toInt();
    if (aFlex < 1) aFlex = 1;
    if (aFlex > 999) aFlex = 999;
    return ClipRRect(
      borderRadius: Radii.pill,
      child: SizedBox(
        height: 6,
        child: Row(children: [
          Expanded(flex: aFlex, child: ColoredBox(color: total == 0 ? Colors.white24 : MizanPalette.teal400)),
          Expanded(
            flex: 1000 - aFlex,
            child: ColoredBox(color: total == 0 ? Colors.white24 : const Color(0xFFFF8A8E)),
          ),
        ]),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.color});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: Radii.pill),
        child: Text(text, style: context.text.labelMedium!.copyWith(color: color.withValues(alpha: 0.85))),
      );
}
