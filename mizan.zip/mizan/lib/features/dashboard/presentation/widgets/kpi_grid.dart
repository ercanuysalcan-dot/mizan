import 'package:flutter/material.dart';

import '../../../../design_system/design_system.dart';
import '../../domain/dashboard_models.dart';

class KpiGrid extends StatelessWidget {
  const KpiGrid({super.key, required this.data, required this.slots, required this.periodLabel});

  final DashboardData data;
  final List<KpiSlot> slots;
  final String periodLabel;

  @override
  Widget build(BuildContext context) {
    final visible = slots.where((s) => s.visible).map((s) => s.kpi).toList();
    if (visible.isEmpty) return const SizedBox.shrink();
    return LayoutBuilder(builder: (context, c) {
      final cols = switch (c.maxWidth) {
        < 520 => 2,
        < 820 => 3,
        < 1180 => 4,
        _ => 5,
      };
      const gap = Space.md;
      final w = (c.maxWidth - gap * (cols - 1)) / cols;
      return Wrap(
        spacing: gap,
        runSpacing: gap,
        children: [
          for (final k in visible)
            SizedBox(
              width: w,
              child: _card(context, k),
            ),
        ],
      );
    });
  }

  Widget _card(BuildContext context, DashboardKpi k) {
    final t = context.tokens;
    final (tone, accent) = switch (k) {
      DashboardKpi.totalAssets => (MoneyTone.neutral, context.colors.secondary),
      DashboardKpi.totalDebt => (MoneyTone.neutral, t.expense),
      DashboardKpi.totalReceivable => (MoneyTone.neutral, t.chart[1]),
      DashboardKpi.cash => (MoneyTone.neutral, t.chart[3]),
      DashboardKpi.bank => (MoneyTone.neutral, t.chart[1]),
      DashboardKpi.creditCardDebt => (MoneyTone.neutral, t.expense),
      DashboardKpi.periodIncome => (MoneyTone.income, t.income),
      DashboardKpi.periodExpense => (MoneyTone.expense, t.expense),
      DashboardKpi.periodNet => (MoneyTone.signed, t.chart[2]),
    };
    return KpiCard(
      key: ValueKey('kpi-${k.id}'),
      label: k.label,
      value: data.kpi(k),
      icon: k.icon,
      tone: tone,
      accent: accent,
      footnote: k.isPeriodBased ? periodLabel : 'Dönem sonu bakiye',
    );
  }
}
