import 'package:flutter/material.dart';

import '../../../../core/utils/tr_format.dart';
import '../../../../design_system/design_system.dart';
import '../../../accounting/domain/ledger_models.dart';
import '../../../transactions/presentation/entry_detail_sheet.dart';
import '../../domain/dashboard_models.dart';

enum _RecentFilter { all, collections, payments }

class RecentEntriesCard extends StatefulWidget {
  const RecentEntriesCard({super.key, required this.entries, this.maxItems = 7});
  final List<RecentEntry> entries;
  final int maxItems;

  @override
  State<RecentEntriesCard> createState() => _RecentEntriesCardState();
}

class _RecentEntriesCardState extends State<RecentEntriesCard> {
  _RecentFilter _filter = _RecentFilter.all;

  @override
  Widget build(BuildContext context) {
    final items = widget.entries
        .where((e) => switch (_filter) {
              _RecentFilter.all => true,
              _RecentFilter.collections => e.type == EntryType.tahsilat,
              _RecentFilter.payments => e.type == EntryType.odeme,
            })
        .take(widget.maxItems)
        .toList();

    return MizanCard(
      title: 'Hareketler',
      padding: const EdgeInsets.fromLTRB(Space.lg, Space.lg, Space.lg, Space.sm),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SegmentedButton<_RecentFilter>(
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(value: _RecentFilter.all, label: Text('Son işlemler')),
              ButtonSegment(value: _RecentFilter.collections, label: Text('Tahsilatlar')),
              ButtonSegment(value: _RecentFilter.payments, label: Text('Ödemeler')),
            ],
            selected: {_filter},
            onSelectionChanged: (s) => setState(() => _filter = s.first),
          ),
          Space.gapSm,
          AnimatedSwitcher(
            duration: Motion.normal,
            child: items.isEmpty
                ? EmptyState(
                    key: ValueKey(_filter),
                    compact: true,
                    icon: Icons.receipt_long_outlined,
                    title: 'Kayıt yok',
                    message: switch (_filter) {
                      _RecentFilter.all => 'İlk işlemini sağ alttaki “İşlem ekle” ile girebilirsin.',
                      _RecentFilter.collections => 'Cari hesaplardan yapılan tahsilatlar burada görünür.',
                      _RecentFilter.payments => 'Cari hesaplara yapılan ödemeler burada görünür.',
                    },
                  )
                : Column(
                    key: ValueKey(_filter),
                    children: [for (final e in items) RecentEntryTile(entry: e)],
                  ),
          ),
        ],
      ),
    );
  }
}

class RecentEntryTile extends StatelessWidget {
  const RecentEntryTile({super.key, required this.entry});
  final RecentEntry entry;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final (icon, color, tone) = switch (entry.type) {
      EntryType.gelir || EntryType.tahsilat || EntryType.alacak =>
        (Icons.south_west_rounded, t.income, MoneyTone.income),
      EntryType.gider || EntryType.kartHarcama || EntryType.odeme || EntryType.borc || EntryType.maas =>
        (Icons.north_east_rounded, t.expense, MoneyTone.expense),
      EntryType.kartOdeme => (Icons.credit_score_rounded, t.chart[1], MoneyTone.neutral),
      EntryType.acilis => (Icons.flag_outlined, t.chart[2], MoneyTone.neutral),
      _ => (Icons.swap_horiz_rounded, t.chart[1], MoneyTone.neutral),
    };
    return InkWell(
      borderRadius: Radii.control,
      onTap: () => showEntryDetailSheet(context, entry),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: Space.sm + 2, horizontal: Space.xs),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.12),
                borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
              ),
              child: Icon(icon, size: 18, color: color),
            ),
            Space.gapMd,
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(entry.title, style: context.text.titleSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 2),
                  Text(
                    '${TrFormat.dayMonth(entry.date)} · ${entry.flow}',
                    style: context.text.bodySmall,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Space.gapSm,
            MoneyText(entry.amount, tone: tone, animate: false, style: context.text.titleSmall),
          ],
        ),
      ),
    );
  }
}
