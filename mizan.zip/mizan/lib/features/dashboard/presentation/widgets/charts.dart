import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../../../../core/money/money.dart';
import '../../../../core/money/money_format.dart';
import '../../../../core/utils/tr_format.dart';
import '../../../../design_system/design_system.dart';
import '../../domain/dashboard_models.dart';

/// Grafikler double ile çizilir — yalnızca piksel konumu içindir. Ekranda
/// görünen her tutar (ipucu, lejant) tam sayı Money'den biçimlendirilir.
double _major(int minor, Currency c) => minor / c.minorPerMajor;

({double max, double interval}) _scale(double maxValue) {
  if (maxValue <= 0) return (max: 1, interval: 1);
  final raw = maxValue * 1.15;
  return (max: raw, interval: raw / 4);
}

class ChartLegend extends StatelessWidget {
  const ChartLegend(this.items, {super.key});
  final List<(String, Color)> items;

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: Space.md,
        children: [
          for (final (label, color) in items)
            Row(mainAxisSize: MainAxisSize.min, children: [
              Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: Radii.pill)),
              const SizedBox(width: 6),
              Text(label, style: context.text.bodySmall),
            ]),
        ],
      );
}

// ---------------------------------------------------------------- Gelir / gider
class IncomeExpenseChart extends StatelessWidget {
  const IncomeExpenseChart({super.key, required this.months, required this.currency});
  final List<MonthPoint> months;
  final Currency currency;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final empty = months.every((m) => m.income == 0 && m.expense == 0);
    final maxV = months.fold<int>(0, (a, m) => [a, m.income, m.expense].reduce((x, y) => x > y ? x : y));
    final s = _scale(_major(maxV, currency));
    final rodWidth = months.length > 8 ? 7.0 : 11.0;

    return MizanCard(
      title: 'Gelir ve gider',
      subtitle: 'Son ${months.length} ay',
      trailing: ChartLegend([('Gelir', t.income), ('Gider', t.expense)]),
      child: SizedBox(
        height: 220,
        child: empty
            ? const _ChartEmpty()
            : BarChart(
                BarChartData(
                  maxY: s.max,
                  minY: 0,
                  alignment: BarChartAlignment.spaceAround,
                  borderData: FlBorderData(show: false),
                  gridData: FlGridData(
                    drawVerticalLine: false,
                    horizontalInterval: s.interval,
                    getDrawingHorizontalLine: (_) => FlLine(color: t.border, strokeWidth: 1),
                  ),
                  titlesData: _titles(context, months, currency, s.interval),
                  barTouchData: BarTouchData(
                    touchTooltipData: BarTouchTooltipData(
                      getTooltipColor: (_) => context.colors.inverseSurface,
                      getTooltipItem: (group, _, rod, rodIndex) {
                        final m = months[group.x];
                        final v = rodIndex == 0 ? m.income : m.expense;
                        return BarTooltipItem(
                          '${rodIndex == 0 ? 'Gelir' : 'Gider'}\n${MoneyFormat.format(Money.fromMinor(v, currency))}',
                          context.text.labelMedium!.copyWith(color: context.colors.onInverseSurface),
                        );
                      },
                    ),
                  ),
                  barGroups: [
                    for (var i = 0; i < months.length; i++)
                      BarChartGroupData(x: i, barsSpace: 4, barRods: [
                        BarChartRodData(
                          toY: _major(months[i].income, currency),
                          color: t.income,
                          width: rodWidth,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                        BarChartRodData(
                          toY: _major(months[i].expense, currency),
                          color: t.expense,
                          width: rodWidth,
                          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                        ),
                      ]),
                  ],
                ),
                duration: Motion.slow,
                curve: Motion.curve,
              ),
      ),
    );
  }
}

// ---------------------------------------------------------------- Nakit akışı
class CashFlowChart extends StatelessWidget {
  const CashFlowChart({super.key, required this.months, required this.currency});
  final List<MonthPoint> months;
  final Currency currency;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final accent = context.colors.secondary;
    final empty = months.every((m) => m.cashNet == 0);
    final values = months.map((m) => _major(m.cashNet, currency)).toList();
    final maxAbs = values.fold<double>(0, (a, v) => v.abs() > a ? v.abs() : a);
    final hasNegative = values.any((v) => v < 0);
    final s = _scale(maxAbs);

    return MizanCard(
      title: 'Aylık nakit akışı',
      subtitle: 'Kasa ve banka hesaplarındaki net değişim',
      child: SizedBox(
        height: 200,
        child: empty
            ? const _ChartEmpty()
            : LineChart(
                LineChartData(
                  minY: hasNegative ? -s.max : 0,
                  maxY: s.max,
                  borderData: FlBorderData(show: false),
                  gridData: FlGridData(
                    drawVerticalLine: false,
                    horizontalInterval: s.interval,
                    getDrawingHorizontalLine: (v) =>
                        FlLine(color: v == 0 ? t.subtleText.withValues(alpha: 0.5) : t.border, strokeWidth: 1),
                  ),
                  titlesData: _titles(context, months, currency, s.interval),
                  lineTouchData: LineTouchData(
                    touchTooltipData: LineTouchTooltipData(
                      getTooltipColor: (_) => context.colors.inverseSurface,
                      getTooltipItems: (spots) => [
                        for (final sp in spots)
                          LineTooltipItem(
                            '${TrFormat.monthYear(months[sp.x.toInt()].month)}\n'
                            '${MoneyFormat.format(Money.fromMinor(months[sp.x.toInt()].cashNet, currency), showPlus: true)}',
                            context.text.labelMedium!.copyWith(color: context.colors.onInverseSurface),
                          ),
                      ],
                    ),
                  ),
                  lineBarsData: [
                    LineChartBarData(
                      spots: [for (var i = 0; i < values.length; i++) FlSpot(i.toDouble(), values[i])],
                      isCurved: true,
                      preventCurveOverShooting: true,
                      color: accent,
                      barWidth: 3,
                      dotData: FlDotData(
                        getDotPainter: (spot, _, __, ___) => FlDotCirclePainter(
                          radius: 3.5,
                          color: context.colors.surface,
                          strokeWidth: 2.5,
                          strokeColor: spot.y < 0 ? t.expense : accent,
                        ),
                      ),
                      belowBarData: BarAreaData(
                        show: true,
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [accent.withValues(alpha: 0.28), accent.withValues(alpha: 0.0)],
                        ),
                      ),
                    ),
                  ],
                ),
                duration: Motion.slow,
                curve: Motion.curve,
              ),
      ),
    );
  }
}

FlTitlesData _titles(BuildContext context, List<MonthPoint> months, Currency c, double interval) {
  final style = context.text.bodySmall!;
  return FlTitlesData(
    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
    leftTitles: AxisTitles(
      sideTitles: SideTitles(
        showTitles: true,
        reservedSize: 56,
        interval: interval,
        getTitlesWidget: (value, meta) {
          if (value == meta.max && value != 0) return const SizedBox.shrink();
          return Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Text(
              MoneyFormat.compact((value * c.minorPerMajor).round(), c),
              style: style,
              textAlign: TextAlign.right,
            ),
          );
        },
      ),
    ),
    bottomTitles: AxisTitles(
      sideTitles: SideTitles(
        showTitles: true,
        reservedSize: 26,
        interval: 1,
        getTitlesWidget: (value, meta) {
          final i = value.toInt();
          if (i < 0 || i >= months.length || value != i.toDouble()) return const SizedBox.shrink();
          return Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(TrFormat.monthShort(months[i].month), style: style),
          );
        },
      ),
    ),
  );
}

class _ChartEmpty extends StatelessWidget {
  const _ChartEmpty();
  @override
  Widget build(BuildContext context) => const Center(
        child: EmptyState(
          compact: true,
          icon: Icons.bar_chart_rounded,
          title: 'Bu dönemde hareket yok',
          message: 'İşlem ekledikçe grafik burada oluşur.',
        ),
      );
}

// ---------------------------------------------------------------- Varlık dağılımı
class AssetDistributionCard extends StatelessWidget {
  const AssetDistributionCard({super.key, required this.slices, required this.currency});
  final List<AssetSlice> slices;
  final Currency currency;

  @override
  Widget build(BuildContext context) {
    final palette = context.tokens.chart;
    final total = slices.fold<int>(0, (a, s) => a + s.amount.minor);
    Color colorOf(AssetSlice s) => palette[s.group.index % palette.length];

    return MizanCard(
      title: 'Varlık dağılımı',
      subtitle: 'Toplam ${MoneyFormat.format(Money.fromMinor(total, currency))}',
      child: slices.isEmpty
          ? const SizedBox(
              height: 200,
              child: Center(
                child: EmptyState(compact: true, icon: Icons.donut_large_rounded, title: 'Henüz varlık yok'),
              ),
            )
          : Column(
              children: [
                SizedBox(
                  height: 160,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 3,
                      centerSpaceRadius: 48,
                      startDegreeOffset: -90,
                      sections: [
                        for (final s in slices)
                          PieChartSectionData(
                            value: _major(s.amount.minor, currency),
                            color: colorOf(s),
                            radius: 22,
                            showTitle: false,
                          ),
                      ],
                    ),
                    duration: Motion.slow,
                    curve: Motion.curve,
                  ),
                ),
                Space.gapLg,
                for (final s in slices)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(children: [
                      Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(color: colorOf(s), borderRadius: Radii.pill),
                      ),
                      Space.gapSm,
                      Expanded(child: Text(s.group.label, style: context.text.bodyMedium)),
                      Text(_percent(s.amount.minor, total), style: context.text.bodySmall),
                      Space.gapMd,
                      MoneyText(s.amount, animate: false, style: context.text.labelLarge),
                    ]),
                  ),
              ],
            ),
    );
  }

  /// Tam sayı yüzde (bir ondalık): %12,3
  static String _percent(int part, int total) {
    if (total <= 0) return '';
    final permille = (BigInt.from(part) * BigInt.from(1000) ~/ BigInt.from(total)).toInt();
    return '%${permille ~/ 10},${permille % 10}';
  }
}

// ---------------------------------------------------------------- Borç / alacak
class DebtReceivableCard extends StatelessWidget {
  const DebtReceivableCard({super.key, required this.receivable, required this.debt});
  final Money receivable;
  final Money debt;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final maxV = receivable.minor > debt.minor ? receivable.minor : debt.minor;
    final diff = receivable - debt;

    Widget bar(String label, Money v, Color color) {
      final ratio = maxV <= 0 ? 0.0 : v.minor / maxV; // yalnızca genişlik
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Expanded(child: Text(label, style: context.text.bodyMedium)),
            MoneyText(v, style: context.text.titleSmall),
          ]),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: Radii.pill,
            child: Stack(children: [
              Container(height: 10, color: t.mutedSurface),
              TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: ratio),
                duration: Motion.slow,
                curve: Motion.curve,
                builder: (_, r, __) => FractionallySizedBox(
                  widthFactor: r < 0 ? 0.0 : (r > 1 ? 1.0 : r),
                  child: Container(height: 10, color: color),
                ),
              ),
            ]),
          ),
        ],
      );
    }

    return MizanCard(
      title: 'Borç ve alacak',
      subtitle: 'Cari, kart ve personel bakiyeleri',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          bar('Alacaklar', receivable, t.chart[0]),
          Space.gapLg,
          bar('Borçlar', debt, t.expense),
          Space.gapLg,
          Divider(color: t.border),
          Space.gapMd,
          Row(children: [
            Expanded(child: Text('Net pozisyon', style: context.text.labelLarge)),
            MoneyText(diff, tone: MoneyTone.signed, showPlus: true, style: context.text.titleMedium),
          ]),
        ],
      ),
    );
  }
}
