import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/design_system.dart';
import '../../application/dashboard_providers.dart';
import '../../data/dashboard_repository.dart';
import '../../domain/dashboard_models.dart';

Future<void> showKpiLayoutSheet(BuildContext context, List<KpiSlot> current) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 520),
      builder: (_) => _KpiLayoutSheet(initial: current),
    );

/// Dashboard kartlarını göster/gizle ve sürükleyerek sırala.
class _KpiLayoutSheet extends ConsumerStatefulWidget {
  const _KpiLayoutSheet({required this.initial});
  final List<KpiSlot> initial;

  @override
  ConsumerState<_KpiLayoutSheet> createState() => _KpiLayoutSheetState();
}

class _KpiLayoutSheetState extends ConsumerState<_KpiLayoutSheet> {
  late List<KpiSlot> _slots = List.of(widget.initial);

  Future<void> _save() async {
    await ref.read(dashboardRepositoryProvider).saveLayout(_slots);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text('Kartları düzenle', style: context.text.headlineSmall),
          Space.gapXs,
          Text('Göstermek istediklerini seç, sürükleyerek sırala.', style: context.text.bodySmall),
          Space.gapLg,
          Flexible(
            child: ReorderableListView(
              shrinkWrap: true,
              buildDefaultDragHandles: false,
              onReorder: (oldIndex, newIndex) => setState(() {
                if (newIndex > oldIndex) newIndex -= 1;
                final item = _slots.removeAt(oldIndex);
                _slots.insert(newIndex, item);
              }),
              children: [
                for (var i = 0; i < _slots.length; i++)
                  ListTile(
                    key: ValueKey(_slots[i].kpi),
                    contentPadding: EdgeInsets.zero,
                    leading: Checkbox(
                      value: _slots[i].visible,
                      onChanged: (v) => setState(() => _slots[i] = KpiSlot(_slots[i].kpi, visible: v ?? true)),
                    ),
                    title: Text(_slots[i].kpi.label),
                    trailing: ReorderableDragStartListener(
                      index: i,
                      child: const Icon(Icons.drag_indicator_rounded),
                    ),
                  ),
              ],
            ),
          ),
          Space.gapLg,
          Row(children: [
            TextButton(
              onPressed: () => setState(() => _slots = DashboardRepository.defaultLayout),
              child: const Text('Varsayılana dön'),
            ),
            const Spacer(),
            FilledButton(onPressed: _save, child: const Text('Kaydet')),
          ]),
        ],
      ),
    );
  }
}
