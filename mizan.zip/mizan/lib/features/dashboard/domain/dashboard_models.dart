import 'package:flutter/material.dart';

import '../../../core/money/money.dart';
import '../../accounting/domain/ledger_models.dart';

/// Kullanıcının düzenleyebildiği dashboard kartları. Net varlık her zaman
/// üstteki ana kartta gösterilir.
enum DashboardKpi {
  totalAssets('total_assets', 'Toplam varlık', Icons.account_balance_wallet_outlined),
  totalDebt('total_debt', 'Toplam borç', Icons.trending_down_rounded),
  totalReceivable('total_receivable', 'Toplam alacak', Icons.call_received_rounded),
  cash('cash', 'Kasa bakiyesi', Icons.payments_outlined),
  bank('bank', 'Banka bakiyesi', Icons.account_balance_outlined),
  creditCardDebt('card_debt', 'Kredi kartı borcu', Icons.credit_card_rounded),
  periodIncome('income', 'Gelir', Icons.south_west_rounded),
  periodExpense('expense', 'Gider', Icons.north_east_rounded),
  periodNet('net', 'Net kazanç', Icons.insights_rounded);

  const DashboardKpi(this.id, this.label, this.icon);
  final String id;
  final String label;
  final IconData icon;

  bool get isPeriodBased => this == periodIncome || this == periodExpense || this == periodNet;

  static DashboardKpi? fromId(String id) {
    for (final k in values) {
      if (k.id == id) return k;
    }
    return null;
  }
}

class KpiSlot {
  const KpiSlot(this.kpi, {this.visible = true});
  final DashboardKpi kpi;
  final bool visible;
  Map<String, Object> toJson() => {'id': kpi.id, 'visible': visible};
}

class MonthPoint {
  const MonthPoint(this.month, this.income, this.expense, this.cashNet);
  final DateTime month;
  final int income; // minor
  final int expense; // minor
  final int cashNet; // kasa+banka net değişim, minor
}

enum AssetGroup {
  cash('Kasa'),
  bank('Banka'),
  savings('Birikim'),
  stock('Stok'),
  receivable('Alacaklar');

  const AssetGroup(this.label);
  final String label;
}

class AssetSlice {
  const AssetSlice(this.group, this.amount);
  final AssetGroup group;
  final Money amount;
}

class RecentEntry {
  const RecentEntry({
    required this.id,
    required this.type,
    required this.date,
    required this.description,
    required this.amount,
    required this.fromNames,
    required this.toNames,
  });

  final String id;
  final EntryType type;
  final DateTime date;
  final String? description;
  final Money amount;
  final List<String> fromNames; // alacak (C) tarafı: paranın geldiği yer
  final List<String> toNames; // borç (D) tarafı: paranın gittiği yer

  String get title => (description == null || description!.trim().isEmpty) ? type.label : description!;
  String get flow => '${fromNames.join(', ')} → ${toNames.join(', ')}';
}

/// Tek bir para birimindeki dashboard özeti.
class DashboardData {
  const DashboardData({
    required this.currency,
    required this.availableCurrencies,
    required this.kpis,
    required this.netWorth,
    required this.months,
    required this.assets,
    required this.recent,
    required this.hasAnyAccount,
  });

  final Currency currency;
  final List<Currency> availableCurrencies;
  final Map<DashboardKpi, Money> kpis;
  final Money netWorth;
  final List<MonthPoint> months;
  final List<AssetSlice> assets;
  final List<RecentEntry> recent;
  final bool hasAnyAccount;

  Money kpi(DashboardKpi k) => kpis[k] ?? Money.zero(currency);
}
