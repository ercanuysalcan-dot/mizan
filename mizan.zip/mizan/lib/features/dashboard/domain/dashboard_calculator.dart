import '../../../core/money/money.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import 'dashboard_models.dart';

/// Bakiyelerden dashboard göstergelerini üreten saf hesaplayıcı.
///
/// Sınıflandırma:
///  * Varlık  = kasa + banka + birikim + stok + alacaklar
///  * Alacak  = pozitif cari bakiyeler + negatif personel bakiyeleri (verilen avans)
///  * Borç    = kredi kartı borçları + negatif cari bakiyeler + pozitif personel bakiyeleri
///  * Net varlık = Varlık − Borç
abstract final class DashboardCalculator {
  static ({Map<DashboardKpi, Money> kpis, Money netWorth, List<AssetSlice> assets}) summarize({
    required Currency currency,
    required Iterable<AccountBalance> balances,
    required int periodIncomeMinor,
    required int periodExpenseMinor,
  }) {
    var cash = 0, bank = 0, savings = 0, stock = 0, receivable = 0, debt = 0, card = 0;
    for (final b in balances) {
      if (b.currency != currency) continue;
      final v = b.balance.minor;
      switch (b.kind) {
        case AccountKind.kasa:
          cash += v;
        case AccountKind.banka:
          bank += v;
        case AccountKind.birikim:
          savings += v;
        case AccountKind.stok:
          stock += v;
        case AccountKind.cari:
          if (v >= 0) {
            receivable += v;
          } else {
            debt += -v;
          }
        case AccountKind.krediKarti:
          // Negatif kart bakiyesi = karta fazla ödeme → alacak gibi davranır.
          if (v >= 0) {
            card += v;
          } else {
            receivable += -v;
          }
        case AccountKind.personel:
          if (v >= 0) {
            debt += v;
          } else {
            receivable += -v;
          }
        case AccountKind.gelir:
        case AccountKind.gider:
        case AccountKind.ozkaynak:
        case AccountKind.kurFarki:
          break;
      }
    }
    final totalDebt = debt + card;
    final totalAssets = cash + bank + savings + stock + receivable;
    Money m(int v) => Money.fromMinor(v, currency);

    final kpis = <DashboardKpi, Money>{
      DashboardKpi.totalAssets: m(totalAssets),
      DashboardKpi.totalDebt: m(totalDebt),
      DashboardKpi.totalReceivable: m(receivable),
      DashboardKpi.cash: m(cash),
      DashboardKpi.bank: m(bank),
      DashboardKpi.creditCardDebt: m(card),
      DashboardKpi.periodIncome: m(periodIncomeMinor),
      DashboardKpi.periodExpense: m(periodExpenseMinor),
      DashboardKpi.periodNet: m(periodIncomeMinor - periodExpenseMinor),
    };
    final assets = [
      AssetSlice(AssetGroup.cash, m(cash)),
      AssetSlice(AssetGroup.bank, m(bank)),
      AssetSlice(AssetGroup.savings, m(savings)),
      AssetSlice(AssetGroup.stock, m(stock)),
      AssetSlice(AssetGroup.receivable, m(receivable)),
    ].where((s) => s.amount.isPositive).toList();

    return (kpis: kpis, netWorth: m(totalAssets - totalDebt), assets: assets);
  }

  /// Satırları aylara dağıtır. [rows]: (tarih, hesap türü, borç, alacak).
  static List<MonthPoint> bucketMonths(
    List<DateTime> monthStarts,
    Iterable<({DateTime date, AccountKind kind, int debit, int credit})> rows,
  ) {
    final income = List.filled(monthStarts.length, 0);
    final expense = List.filled(monthStarts.length, 0);
    final cash = List.filled(monthStarts.length, 0);
    for (final r in rows) {
      final i = monthStarts.indexWhere((m) => m.year == r.date.year && m.month == r.date.month);
      if (i < 0) continue;
      switch (r.kind) {
        case AccountKind.gelir:
          income[i] += r.credit - r.debit;
        case AccountKind.gider:
          expense[i] += r.debit - r.credit;
        case AccountKind.kasa:
        case AccountKind.banka:
          cash[i] += r.debit - r.credit;
        default:
          break;
      }
    }
    return [
      for (var i = 0; i < monthStarts.length; i++) MonthPoint(monthStarts[i], income[i], expense[i], cash[i]),
    ];
  }
}
