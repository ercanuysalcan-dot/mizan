import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/money/money.dart';
import '../../../core/utils/date_range.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../settings/data/settings_repository.dart';
import '../domain/dashboard_calculator.dart';
import '../domain/dashboard_models.dart';

class DashboardRepository {
  DashboardRepository(this._db, this._ledger, this._settings);

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final SettingsRepository _settings;

  Stream<DashboardData> watch({
    required String businessId,
    required PeriodFilter period,
    required Currency currency,
  }) =>
      _db.watchAll(() => load(businessId: businessId, period: period, currency: currency));

  Future<DashboardData> load({
    required String businessId,
    required PeriodFilter period,
    required Currency currency,
  }) async {
    final range = period.range;
    final balances = await _ledger.balances(businessId, asOf: range.end);

    final userKinds = AccountKind.creatable.map((k) => "'${k.code}'").join(',');
    final currencyRows = await _db.customSelect(
      'SELECT DISTINCT currency FROM accounts WHERE business_id = ? AND deleted_at IS NULL '
      'AND kind IN ($userKinds)',
      variables: [Variable.withString(businessId)],
    ).get();
    final available = currencyRows.map((r) => Currency.fromCode(r.read<String>('currency'))).toSet();

    final periodRows = await _db.customSelect(
      '''
      SELECT a.kind, COALESCE(SUM(l.debit_minor), 0) AS d, COALESCE(SUM(l.credit_minor), 0) AS c
      FROM journal_lines l
      JOIN journal_entries e ON e.id = l.entry_id
      JOIN accounts a ON a.id = l.account_id
      WHERE e.business_id = ? AND e.status <> 'draft' AND l.currency = ?
        AND a.kind IN ('gelir', 'gider') AND e.entry_date >= ? AND e.entry_date < ?
      GROUP BY a.kind
      ''',
      variables: [
        Variable.withString(businessId),
        Variable.withString(currency.code),
        Variable.withInt(range.startMs),
        Variable.withInt(range.endMs),
      ],
    ).get();
    var income = 0, expense = 0;
    for (final r in periodRows) {
      final kind = AccountKind.fromCode(r.read<String>('kind'));
      final d = r.read<int>('d'), c = r.read<int>('c');
      if (kind == AccountKind.gelir) income = c - d;
      if (kind == AccountKind.gider) expense = d - c;
    }

    final summary = DashboardCalculator.summarize(
      currency: currency,
      balances: balances,
      periodIncomeMinor: income,
      periodExpenseMinor: expense,
    );

    // Grafikler: dönem sonuna kadar son 6 ay (yıl filtresinde 12 ay).
    final lastInstant = range.end.subtract(const Duration(milliseconds: 1));
    final months = DateRange.trailingMonths(lastInstant, period.preset == PeriodPreset.year ? 12 : 6);
    final monthRows = await _db.customSelect(
      '''
      SELECT e.entry_date, a.kind, l.debit_minor, l.credit_minor
      FROM journal_lines l
      JOIN journal_entries e ON e.id = l.entry_id
      JOIN accounts a ON a.id = l.account_id
      WHERE e.business_id = ? AND e.status <> 'draft' AND l.currency = ?
        AND a.kind IN ('gelir', 'gider', 'kasa', 'banka')
        AND e.entry_date >= ? AND e.entry_date < ?
      ''',
      variables: [
        Variable.withString(businessId),
        Variable.withString(currency.code),
        Variable.withInt(months.first.startMs),
        Variable.withInt(months.last.endMs),
      ],
    ).get();
    final monthPoints = DashboardCalculator.bucketMonths(
      months.map((m) => m.start).toList(),
      monthRows.map((r) => (
            date: DateTime.fromMillisecondsSinceEpoch(r.read<int>('entry_date')),
            kind: AccountKind.fromCode(r.read<String>('kind')),
            debit: r.read<int>('debit_minor'),
            credit: r.read<int>('credit_minor'),
          )),
    );

    return DashboardData(
      currency: currency,
      availableCurrencies: Currency.values.where(available.contains).toList(),
      kpis: summary.kpis,
      netWorth: summary.netWorth,
      months: monthPoints,
      assets: summary.assets,
      recent: await recentEntries(businessId),
      hasAnyAccount: available.isNotEmpty,
    );
  }

  /// Son kesinleşmiş işlemler (iptal edilenler ve iptal kayıtları hariç).
  Future<List<RecentEntry>> recentEntries(String businessId, {int limit = 30}) async {
    final rows = await _db.customSelect(
      '''
      SELECT e.id, e.entry_type, e.entry_date, e.description, e.created_at,
        l.currency, l.debit_minor, l.credit_minor, l.line_no, a.name
      FROM journal_entries e
      JOIN journal_lines l ON l.entry_id = e.id
      JOIN accounts a ON a.id = l.account_id
      WHERE e.id IN (
        SELECT id FROM journal_entries
        WHERE business_id = ? AND status = 'posted' AND entry_type <> 'iptal'
        ORDER BY entry_date DESC, created_at DESC LIMIT ?
      )
      ORDER BY e.entry_date DESC, e.created_at DESC, l.line_no
      ''',
      variables: [Variable.withString(businessId), Variable.withInt(limit)],
    ).get();

    final order = <String>[];
    final byId = <String, List<QueryRow>>{};
    for (final r in rows) {
      final id = r.read<String>('id');
      if (!byId.containsKey(id)) order.add(id);
      byId.putIfAbsent(id, () => []).add(r);
    }
    return [
      for (final id in order)
        () {
          final lines = byId[id]!;
          final first = lines.first;
          final currency = Currency.fromCode(first.read<String>('currency'));
          var amount = 0;
          final from = <String>[], to = <String>[];
          for (final l in lines) {
            final d = l.read<int>('debit_minor');
            final name = l.read<String>('name');
            if (d > 0) {
              if (l.read<String>('currency') == currency.code) amount += d;
              if (!to.contains(name)) to.add(name);
            } else if (!from.contains(name)) {
              from.add(name);
            }
          }
          return RecentEntry(
            id: id,
            type: EntryType.fromCode(first.read<String>('entry_type')),
            date: DateTime.fromMillisecondsSinceEpoch(first.read<int>('entry_date')),
            description: first.readNullable<String>('description'),
            amount: Money.fromMinor(amount, currency),
            fromNames: from,
            toNames: to,
          );
        }(),
    ];
  }

  // ----------------------------------------------------- kart düzeni (ayar)

  static List<KpiSlot> get defaultLayout => [for (final k in DashboardKpi.values) KpiSlot(k)];

  Stream<List<KpiSlot>> watchLayout() =>
      _settings.watch(SettingsRepository.dashboardKpisKey).map(parseLayout);

  Future<void> saveLayout(List<KpiSlot> slots) =>
      _settings.set(SettingsRepository.dashboardKpisKey, jsonEncode([for (final s in slots) s.toJson()]));

  /// Kayıtlı düzeni çözer; bilinmeyen kimlikleri atar, yeni eklenen kartları
  /// sona ekler. Bozuk veri varsayılana döner.
  static List<KpiSlot> parseLayout(String? raw) {
    if (raw == null) return defaultLayout;
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      final result = <KpiSlot>[];
      for (final item in list) {
        final map = item as Map<String, dynamic>;
        final k = DashboardKpi.fromId(map['id'] as String);
        if (k != null && result.every((s) => s.kpi != k)) {
          result.add(KpiSlot(k, visible: map['visible'] as bool? ?? true));
        }
      }
      for (final k in DashboardKpi.values) {
        if (result.every((s) => s.kpi != k)) result.add(KpiSlot(k));
      }
      return result;
    } catch (_) {
      return defaultLayout;
    }
  }
}
