import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../transactions/application/entry_edit_service.dart';

/// Hesap silme.
///
/// * Hareketi olmayan hesap doğrudan silinir.
/// * Hareketi olan hesapta, kullanıcı onaylarsa önce her işlem ters kayıtla
///   iptal edilir (karşı hesapların bakiyeleri de eski haline döner), sonra
///   hesap silinir. Defterden hiçbir satır fiziksel olarak silinmez; iptaller
///   ve silme denetim kaydına yazılır.
class AccountDeleteService {
  AccountDeleteService(this._db, this._edit, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final EntryEditService _edit;
  final String deviceId;
  final Clock _clock;

  /// Hesaba dokunan, iptal edilmemiş işlem sayısı.
  Future<int> movementCount(String accountId) async {
    final row = await _db.customSelect(
      'SELECT COUNT(DISTINCT e.id) AS n FROM journal_entries e '
      'JOIN journal_lines l ON l.entry_id = e.id '
      "WHERE l.account_id = ? AND e.status = 'posted' AND e.entry_type <> 'iptal'",
      variables: [Variable.withString(accountId)],
    ).getSingle();
    return row.read<int>('n');
  }

  /// Hesabı siler. Hareketi varsa [withEntries] true olmalıdır; dönen değer
  /// iptal edilen işlem sayısıdır.
  Future<int> delete({required String accountId, required String opKey, bool withEntries = false}) {
    return _db.transaction(() async {
      final acc = await _db.customSelect(
        'SELECT business_id, name, kind FROM accounts WHERE id = ? AND deleted_at IS NULL',
        variables: [Variable.withString(accountId)],
      ).getSingleOrNull();
      if (acc == null) throw const AppException('ACCOUNT', 'Hesap bulunamadı ya da zaten silinmiş.');

      final rows = await _db.customSelect(
        'SELECT DISTINCT e.id, e.entry_date FROM journal_entries e '
        'JOIN journal_lines l ON l.entry_id = e.id '
        "WHERE l.account_id = ? AND e.status = 'posted' AND e.entry_type <> 'iptal' "
        'ORDER BY e.entry_date',
        variables: [Variable.withString(accountId)],
      ).get();
      if (rows.isNotEmpty && !withEntries) {
        throw AppException('ACCOUNT_IN_USE',
            'Bu hesapta ${rows.length} işlem var. Silmek için işlemlerin de iptal edilmesini onaylayın.');
      }
      for (final r in rows) {
        final entryId = r.read<String>('id');
        await _edit.reverse(
          entryId: entryId,
          idempotencyKey: 'hesap-sil:$opKey:$entryId',
          reason: 'Hesap silindi: ${acc.read<String>('name')}',
        );
      }

      final now = _clock.nowMs();
      await _db.customUpdate(
        'UPDATE accounts SET deleted_at = ?, archived = 1, updated_at = ?, sync_status = 0, '
        'version = version + 1 WHERE id = ?',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(accountId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      // Karta bağlı ekstreler ve görüntüleri de kaldırılır.
      await _db.customUpdate(
        "UPDATE attachments SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 "
        "WHERE owner_table = 'card_statements' AND deleted_at IS NULL "
        'AND owner_id IN (SELECT id FROM card_statements WHERE card_account_id = ?)',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(accountId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _db.customUpdate(
        'UPDATE card_statements SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE card_account_id = ? AND deleted_at IS NULL',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(accountId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );

      await _db.customInsert(
        'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, after_json, '
        "reason, occurred_at, created_at, updated_at, device_id) VALUES (?, ?, 'accounts', ?, 'delete', ?, ?, "
        "'Hesap silindi', ?, ?, ?, ?)",
        variables: [
          Variable.withString(newId()),
          Variable.withString(acc.read<String>('business_id')),
          Variable.withString(accountId),
          Variable.withString(jsonEncode({'name': acc.read<String>('name'), 'kind': acc.read<String>('kind')})),
          Variable.withString(jsonEncode({'reversed_entries': rows.length})),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      return rows.length;
    });
  }
}

final accountDeleteServiceProvider = Provider<AccountDeleteService>((ref) => AccountDeleteService(
      ref.watch(databaseProvider),
      ref.watch(entryEditServiceProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));
