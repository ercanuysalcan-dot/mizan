import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../data/accounts_repository.dart';

final userAccountsProvider = StreamProvider.autoDispose<List<AccountWithBalance>>((ref) {
  return ref.watch(accountsRepositoryProvider).watchUserAccounts(ref.watch(currentBusinessProvider).id);
});

/// 'gelir' veya 'gider' kategorileri.
final categoriesProvider = FutureProvider.autoDispose.family<List<CategoryInfo>, String>((ref, type) {
  return ref.watch(accountsRepositoryProvider).categories(ref.watch(currentBusinessProvider).id, type);
});
