import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounting/domain/posting_rules.dart';

class CategoryInfo {
  const CategoryInfo({required this.id, required this.type, required this.name});
  final String id;
  final String type; // 'gelir' | 'gider'
  final String name;
}

class AccountWithBalance {
  const AccountWithBalance(this.account, this.balance);
  final LedgerAccount account;
  final Money balance;
}

/// Hesap ve kategori yönetimi. Açılış bakiyeleri muhasebe motorundan geçer.
class AccountsRepository {
  AccountsRepository(this._db, this._ledger, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final String deviceId;
  final Clock _clock;

  /// Yeni hesap oluşturur. [formKey] formun açılışında üretilen sabit kimliktir;
  /// aynı anahtarla tekrar çağrılırsa ikinci hesap oluşmaz.
  Future<LedgerAccount> createAccount({
    required String businessId,
    required AccountKind kind,
    required String name,
    required Currency currency,
    required String formKey,
    Money? openingBalance,
    bool openingInNormalDirection = true,
    DateTime? openingDate,
  }) async {
    if (!kind.userFacing) {
      throw const AppException('ACCOUNT_KIND', 'Bu hesap türü elle oluşturulamaz.');
    }
    final trimmed = name.trim();
    if (trimmed.isEmpty) throw const AppException('ACCOUNT_NAME', 'Hesap adı boş olamaz.');
    if (openingBalance != null && openingBalance.currency != currency) {
      throw CurrencyMismatchError(currency, openingBalance.currency);
    }

    return _db.transaction(() async {
      final existing = await _findAccount(formKey);
      if (existing != null) return existing;

      final now = _clock.nowMs();
      await _db.customInsert(
        'INSERT INTO accounts (id, business_id, kind, normal_side, name, currency, '
        'created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(formKey),
          Variable.withString(businessId),
          Variable.withString(kind.code),
          Variable.withString(kind.normalSide.code),
          Variable.withString(trimmed),
          Variable.withString(currency.code),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      await _audit(businessId, 'accounts', formKey, 'insert',
          {'kind': kind.code, 'name': trimmed, 'currency': currency.code});

      final account = (await _findAccount(formKey))!;
      if (openingBalance != null && !openingBalance.isZero) {
        final equity = await ensureSystemAccount(businessId, 'acilis_ozkaynak', currency);
        await _ledger.post(PostingRequest(
          businessId: businessId,
          type: EntryType.acilis,
          date: openingDate ?? _clock.now(),
          idempotencyKey: 'acilis:$formKey',
          description: 'Açılış bakiyesi — $trimmed',
          lines: PostingRules.opening(
            account: account,
            equity: equity,
            amount: openingBalance.abs(),
            inNormalDirection: openingInNormalDirection,
          ),
        ));
      }
      return account;
    });
  }

  Future<void> rename(String accountId, String newName) async {
    final a = await _ledger.account(accountId);
    final trimmed = newName.trim();
    if (trimmed.isEmpty) throw const AppException('ACCOUNT_NAME', 'Hesap adı boş olamaz.');
    await _db.transaction(() async {
      await _db.customUpdate(
        'UPDATE accounts SET name = ?, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE id = ?',
        variables: [
          Variable.withString(trimmed),
          Variable.withInt(_clock.nowMs()),
          Variable.withString(accountId),
        ],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(a.businessId, 'accounts', accountId, 'update', {'name': trimmed},
          before: {'name': a.name});
    });
  }

  /// Hesabı arşivler. Bakiyesi sıfır olmayan hesap arşivlenemez.
  Future<void> archive(String accountId) async {
    final a = await _ledger.account(accountId);
    final b = await _ledger.balanceOf(accountId);
    if (!b.balance.isZero) {
      throw const AppException('ACCOUNT_BALANCE', 'Bakiyesi sıfır olmayan hesap arşivlenemez.');
    }
    await _db.transaction(() async {
      await _db.customUpdate(
        'UPDATE accounts SET archived = 1, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE id = ?',
        variables: [Variable.withInt(_clock.nowMs()), Variable.withString(accountId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(a.businessId, 'accounts', accountId, 'update', {'archived': true});
    });
  }

  /// Açılış özkaynağı / kur farkı gibi para birimine özel sistem hesabı.
  Future<LedgerAccount> ensureSystemAccount(String businessId, String role, Currency currency) async {
    final row = await _db.customSelect(
      'SELECT id FROM accounts WHERE business_id = ? AND system_role = ? AND currency = ?',
      variables: [Variable.withString(businessId), Variable.withString(role), Variable.withString(currency.code)],
    ).getSingleOrNull();
    if (row != null) return _ledger.account(row.read<String>('id'));

    final kind = role == 'kur_farki' ? AccountKind.kurFarki : AccountKind.ozkaynak;
    final name = role == 'kur_farki' ? 'Kur Farkı (${currency.code})' : 'Açılış Bakiyeleri (${currency.code})';
    final id = newId();
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO accounts (id, business_id, kind, normal_side, name, currency, system_role, '
      'created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(id),
        Variable.withString(businessId),
        Variable.withString(kind.code),
        Variable.withString(kind.normalSide.code),
        Variable.withString(name),
        Variable.withString(currency.code),
        Variable.withString(role),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    return _ledger.account(id);
  }

  /// Kategori + para birimi için defter hesabı (yoksa oluşturur).
  Future<LedgerAccount> ensureCategoryAccount(String businessId, String categoryId, Currency currency) async {
    final row = await _db.customSelect(
      'SELECT id FROM accounts WHERE business_id = ? AND category_id = ? AND currency = ?',
      variables: [
        Variable.withString(businessId),
        Variable.withString(categoryId),
        Variable.withString(currency.code),
      ],
    ).getSingleOrNull();
    if (row != null) return _ledger.account(row.read<String>('id'));

    final cat = await _db.customSelect(
      'SELECT category_type, name FROM categories WHERE id = ? AND business_id = ?',
      variables: [Variable.withString(categoryId), Variable.withString(businessId)],
    ).getSingleOrNull();
    if (cat == null) throw const AppException('CATEGORY', 'Kategori bulunamadı.');
    final kind = cat.read<String>('category_type') == 'gelir' ? AccountKind.gelir : AccountKind.gider;
    final id = newId();
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO accounts (id, business_id, kind, normal_side, name, currency, category_id, '
      'created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(id),
        Variable.withString(businessId),
        Variable.withString(kind.code),
        Variable.withString(kind.normalSide.code),
        Variable.withString(cat.read<String>('name')),
        Variable.withString(currency.code),
        Variable.withString(categoryId),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    return _ledger.account(id);
  }

  Future<String> createCategory(String businessId, String type, String name) async {
    assert(type == 'gelir' || type == 'gider');
    final id = newId();
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO categories (id, business_id, category_type, name, created_at, updated_at, device_id) '
      'VALUES (?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(id),
        Variable.withString(businessId),
        Variable.withString(type),
        Variable.withString(name.trim()),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    return id;
  }

  Future<List<CategoryInfo>> categories(String businessId, String type) async {
    final rows = await _db.customSelect(
      'SELECT id, category_type, name FROM categories '
      'WHERE business_id = ? AND category_type = ? AND archived = 0 AND deleted_at IS NULL '
      'ORDER BY sort_order, name',
      variables: [Variable.withString(businessId), Variable.withString(type)],
    ).get();
    return [
      for (final r in rows)
        CategoryInfo(id: r.read<String>('id'), type: r.read<String>('category_type'), name: r.read<String>('name')),
    ];
  }

  /// Kullanıcıya görünen 7 türdeki hesaplar ve güncel bakiyeleri (canlı).
  Stream<List<AccountWithBalance>> watchUserAccounts(String businessId) =>
      _db.watchAll(() => userAccounts(businessId));

  Future<List<AccountWithBalance>> userAccounts(String businessId, {bool includeArchived = false}) async {
    final kinds = AccountKind.creatable.map((k) => "'${k.code}'").join(',');
    final rows = await _db.customSelect(
      '''
      SELECT a.id, a.business_id, a.kind, a.name, a.currency, a.archived,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.debit_minor END), 0) AS d,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.credit_minor END), 0) AS c
      FROM accounts a
      LEFT JOIN journal_lines l ON l.account_id = a.id
      LEFT JOIN journal_entries e ON e.id = l.entry_id AND e.status <> 'draft'
      WHERE a.business_id = ? AND a.deleted_at IS NULL AND a.kind IN ($kinds)
        ${includeArchived ? '' : 'AND a.archived = 0'}
      GROUP BY a.id
      ORDER BY a.sort_order, a.name
      ''',
      variables: [Variable.withString(businessId)],
    ).get();
    return [
      for (final r in rows)
        () {
          final kind = AccountKind.fromCode(r.read<String>('kind'));
          final currency = Currency.fromCode(r.read<String>('currency'));
          return AccountWithBalance(
            LedgerAccount(
              id: r.read<String>('id'),
              businessId: r.read<String>('business_id'),
              kind: kind,
              name: r.read<String>('name'),
              currency: currency,
              archived: r.read<int>('archived') == 1,
            ),
            Money.fromMinor(kind.signedBalance(r.read<int>('d'), r.read<int>('c')), currency),
          );
        }(),
    ];
  }

  Future<LedgerAccount?> _findAccount(String id) async {
    try {
      return await _ledger.account(id);
    } on LedgerException {
      return null;
    }
  }

  Future<void> _audit(String businessId, String table, String id, String action, Map<String, Object?> after,
      {Map<String, Object?>? before}) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, action, before_json, after_json, '
      'occurred_at, created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(table),
        Variable.withString(id),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable.withString(jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}
