import 'package:flutter/material.dart';

import '../../accounting/domain/account_kind.dart';

extension AccountKindUi on AccountKind {
  IconData get icon => switch (this) {
        AccountKind.cari => Icons.people_alt_outlined,
        AccountKind.banka => Icons.account_balance_outlined,
        AccountKind.krediKarti => Icons.credit_card_rounded,
        AccountKind.kredi => Icons.request_quote_outlined,
        AccountKind.stok => Icons.inventory_2_outlined,
        AccountKind.personel => Icons.badge_outlined,
        AccountKind.birikim => Icons.savings_outlined,
        AccountKind.kasa => Icons.payments_outlined,
        _ => Icons.circle_outlined,
      };

  String get description => switch (this) {
        AccountKind.cari => 'Müşteri ve tedarikçi borç / alacak takibi',
        AccountKind.banka => 'Vadesiz, ticari ve döviz hesapları',
        AccountKind.krediKarti => 'Harcama, dönem borcu (ekstre) ve ödeme',
        AccountKind.kredi => 'Taksitli kredi: ödeme planı, kalan borç',
        AccountKind.stok => 'Depo ve ürün değeri',
        AccountKind.personel => 'Maaş, avans ve ödemeler',
        AccountKind.birikim => 'Altın, döviz ve diğer birikimler',
        AccountKind.kasa => 'Nakit giriş ve çıkışları',
        _ => '',
      };

  /// Açılış bakiyesi alanının etiketi ve yön seçenekleri.
  ({String label, String normal, String opposite})? get openingLabels => switch (this) {
        AccountKind.cari => (label: 'Açılış bakiyesi', normal: 'Bize borçlu (alacak)', opposite: 'Biz borçluyuz'),
        AccountKind.personel => (label: 'Açılış bakiyesi', normal: 'Ödenecek tutar', opposite: 'Verilmiş avans'),
        AccountKind.krediKarti => (label: 'Mevcut kart borcu', normal: '', opposite: ''),
        AccountKind.kredi => (label: 'Toplam borç', normal: '', opposite: ''),
        AccountKind.stok => (label: 'Açılış stok değeri', normal: '', opposite: ''),
        AccountKind.birikim => (label: 'Birikimin maliyet değeri', normal: '', opposite: ''),
        _ => (label: 'Açılış bakiyesi', normal: '', opposite: ''),
      };

  bool get hasDirectionChoice => this == AccountKind.cari || this == AccountKind.personel;
}
