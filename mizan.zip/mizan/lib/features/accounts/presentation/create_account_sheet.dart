import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/ids.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../loans/presentation/loan_form.dart';
import 'account_kind_ui.dart';

Future<void> showCreateAccountSheet(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 640),
      builder: (_) => const CreateAccountSheet(),
    );

/// Yeni hesap: 8 hesap türü. Banka kredisi kendi formunu (taksit planı)
/// kullanır; diğer türlere özel ayrıntılı formlar sonraki adımlarda eklenecek.
class CreateAccountSheet extends ConsumerStatefulWidget {
  const CreateAccountSheet({super.key});

  @override
  ConsumerState<CreateAccountSheet> createState() => _CreateAccountSheetState();
}

class _CreateAccountSheetState extends ConsumerState<CreateAccountSheet> {
  AccountKind? _kind;
  late Currency _currency = ref.read(currentBusinessProvider).baseCurrency;
  final _name = TextEditingController();
  final _opening = TextEditingController();
  bool _normalDirection = true;
  bool _busy = false;
  String? _error;
  final String _formKey = newId();

  @override
  void dispose() {
    _name.dispose();
    _opening.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final kind = _kind!;
    Money? opening;
    if (_opening.text.trim().isNotEmpty) {
      final Money parsed;
      try {
        parsed = Money.parse(_opening.text, _currency);
      } on FormatException catch (e) {
        setState(() => _error = 'Açılış bakiyesi geçersiz: ${e.message}');
        return;
      }
      opening = parsed;
      if (parsed.isNegative) {
        setState(() => _error = 'Tutarı pozitif girin; yönü aşağıdan seçin.');
        return;
      }
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(accountsRepositoryProvider).createAccount(
            businessId: ref.read(currentBusinessProvider).id,
            kind: kind,
            name: _name.text,
            currency: _currency,
            formKey: _formKey,
            openingBalance: opening,
            openingInNormalDirection: _normalDirection,
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('“${_name.text.trim()}” oluşturuldu.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: AnimatedSize(
          duration: Motion.normal,
          curve: Motion.curve,
          alignment: Alignment.topCenter,
          child: switch (_kind) {
            null => _kindPicker(context),
            AccountKind.kredi => LoanForm(onBack: () => setState(() => _kind = null)),
            final AccountKind k => _form(context, k),
          },
        ),
      ),
    );
  }

  Widget _kindPicker(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('Yeni hesap', style: context.text.headlineSmall),
        Space.gapXs,
        Text('Hesap türünü seç', style: context.text.bodySmall),
        Space.gapLg,
        LayoutBuilder(builder: (context, c) {
          final cols = c.maxWidth > 460 ? 2 : 1;
          final w = (c.maxWidth - Space.md * (cols - 1)) / cols;
          return Wrap(
            spacing: Space.md,
            runSpacing: Space.md,
            children: [
              for (final k in AccountKind.creatable)
                SizedBox(
                  width: w,
                  child: MizanCard(
                    key: ValueKey('kind-${k.code}'),
                    padding: const EdgeInsets.all(Space.md),
                    onTap: () => setState(() => _kind = k),
                    child: Row(children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: context.colors.secondary.withValues(alpha: 0.12),
                          borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                        ),
                        child: Icon(k.icon, color: context.colors.secondary, size: 20),
                      ),
                      Space.gapMd,
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(k.label, style: context.text.titleSmall),
                          Text(k.description, style: context.text.bodySmall, maxLines: 2),
                        ]),
                      ),
                    ]),
                  ),
                ),
            ],
          );
        }),
      ],
    );
  }

  Widget _form(BuildContext context, AccountKind kind) {
    final labels = kind.openingLabels!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(children: [
          IconButton(
            tooltip: 'Tür seçimine dön',
            onPressed: () => setState(() => _kind = null),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
          Icon(kind.icon, color: context.colors.secondary),
          Space.gapSm,
          Expanded(child: Text(kind.label, style: context.text.titleLarge)),
        ]),
        Space.gapLg,
        TextField(
          controller: _name,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: InputDecoration(
            labelText: kind == AccountKind.personel ? 'Ad soyad' : 'Hesap adı',
            hintText: switch (kind) {
              AccountKind.kasa => 'Ana Kasa',
              AccountKind.banka => 'İş Bankası Vadesiz',
              AccountKind.krediKarti => 'Bonus Kart',
              AccountKind.cari => 'Yıldız Yapı Ltd.',
              AccountKind.birikim => 'Gram Altın',
              AccountKind.stok => 'Ana Depo',
              _ => '',
            },
          ),
        ),
        Space.gapLg,
        Text('Para birimi', style: context.text.labelLarge),
        Space.gapSm,
        SegmentedButton<Currency>(
          showSelectedIcon: false,
          segments: [
            for (final c in Currency.values) ButtonSegment(value: c, label: Text('${c.symbol} ${c.code}')),
          ],
          selected: {_currency},
          onSelectionChanged: (s) => setState(() => _currency = s.first),
        ),
        Space.gapLg,
        TextField(
          controller: _opening,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
          decoration: InputDecoration(
            labelText: '${labels.label} (isteğe bağlı)',
            hintText: '0,00',
            suffixText: _currency.code,
          ),
        ),
        if (kind.hasDirectionChoice) ...[
          Space.gapMd,
          SegmentedButton<bool>(
            showSelectedIcon: false,
            segments: [
              ButtonSegment(value: true, label: Text(labels.normal)),
              ButtonSegment(value: false, label: Text(labels.opposite)),
            ],
            selected: {_normalDirection},
            onSelectionChanged: (s) => setState(() => _normalDirection = s.first),
          ),
        ],
        Space.gapSm,
        Text(
          'Açılış bakiyesi “Açılış Bakiyeleri” özkaynak hesabına karşılık çift kayıtla işlenir.',
          style: context.text.bodySmall,
        ),
        if (_error != null) ...[
          Space.gapMd,
          Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
        ],
        Space.gapXl,
        FilledButton(
          onPressed: _busy ? null : _save,
          child: _busy
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Hesabı oluştur'),
        ),
      ],
    );
  }
}
