import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../assets/application/assets_providers.dart';
import '../../assets/domain/quantity.dart';
import '../../loans/application/loans_providers.dart';
import '../../loans/presentation/loan_section.dart';
import '../application/account_delete_service.dart';
import '../application/accounts_providers.dart';
import '../data/accounts_repository.dart';
import 'account_kind_ui.dart';
import 'create_account_sheet.dart';

/// Hesaplar: türe göre gruplanmış liste ve canlı bakiyeler.
/// Bir hesaba dokununca ayrıntı sayfası (hareketler, kredi planı, kart ekstreleri) açılır.
class AccountsScreen extends ConsumerWidget {
  const AccountsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(userAccountsProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hesaplar'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: Space.md),
            child: FilledButton.tonalIcon(
              onPressed: () => showCreateAccountSheet(context),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Hesap ekle'),
            ),
          ),
        ],
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Hesaplar yüklenemedi: $e')),
        data: (accounts) {
          if (accounts.isEmpty) {
            return Center(
              child: EmptyState(
                icon: Icons.account_balance_wallet_outlined,
                title: 'Henüz hesap yok',
                message: 'Kasa, banka, kredi kartı, banka kredisi, cari, stok, personel veya birikim hesabı '
                    'ekleyerek başla.',
                action: FilledButton(
                  onPressed: () => showCreateAccountSheet(context),
                  child: const Text('İlk hesabı oluştur'),
                ),
              ),
            );
          }
          final groups = <AccountKind, List<AccountWithBalance>>{};
          for (final a in accounts) {
            groups.putIfAbsent(a.account.kind, () => []).add(a);
          }
          return Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 960),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(Space.lg, Space.sm, Space.lg, 120),
                children: [
                  for (final kind in AccountKind.creatable)
                    if (groups[kind] case final list?) ...[
                      SectionHeader(kind.label, trailing: _GroupTotal(list)),
                      MizanCard(
                        padding: const EdgeInsets.symmetric(vertical: Space.xs),
                        child: Column(children: [
                          for (var i = 0; i < list.length; i++) ...[
                            if (i > 0) const Divider(indent: 68),
                            _AccountTile(item: list[i]),
                          ],
                        ]),
                      ),
                      Space.gapLg,
                    ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _GroupTotal extends StatelessWidget {
  const _GroupTotal(this.items);
  final List<AccountWithBalance> items;

  @override
  Widget build(BuildContext context) {
    final totals = <Currency, Money>{};
    for (final a in items) {
      totals[a.balance.currency] = (totals[a.balance.currency] ?? Money.zero(a.balance.currency)) + a.balance;
    }
    return Text(
      totals.values.map(MoneyFormat.format).join('  ·  '),
      style: context.text.labelMedium!.copyWith(fontFeatures: MizanTheme.tabular),
    );
  }
}

enum _Action { rename, archive, delete }

class _AccountTile extends ConsumerWidget {
  const _AccountTile({required this.item});
  final AccountWithBalance item;

  String _hint(AccountKind k, Money b) => switch (k) {
        AccountKind.cari => b.isNegative ? 'Borçluyuz' : (b.isZero ? 'Kapalı' : 'Alacaklıyız'),
        AccountKind.personel => b.isNegative ? 'Avans verildi' : (b.isZero ? 'Ödenecek yok' : 'Ödenecek'),
        AccountKind.krediKarti => b.isZero ? 'Borç yok' : 'Kart borcu',
        AccountKind.kredi => b.isPositive ? 'Kalan kredi borcu' : 'Kredi kapandı',
        _ => item.account.currency.label,
      };

  Future<void> _onAction(BuildContext context, WidgetRef ref, _Action a) async {
    final repo = ref.read(accountsRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    try {
      switch (a) {
        case _Action.rename:
          final controller = TextEditingController(text: item.account.name);
          final name = await showDialog<String>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text('Hesabı yeniden adlandır'),
              content: TextField(controller: controller, autofocus: true),
              actions: [
                TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
                FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Kaydet')),
              ],
            ),
          );
          controller.dispose();
          if (name != null) await repo.rename(item.account.id, name);
        case _Action.archive:
          await repo.archive(item.account.id);
          messenger.showSnackBar(SnackBar(content: Text('“${item.account.name}” arşivlendi.')));
        case _Action.delete:
          await _delete(context, ref, messenger);
      }
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _delete(BuildContext context, WidgetRef ref, ScaffoldMessengerState messenger) async {
    final service = ref.read(accountDeleteServiceProvider);
    final name = item.account.name;
    final count = await service.movementCount(item.account.id);
    if (!context.mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('“$name” silinsin mi?'),
        content: Text(count == 0
            ? 'Bu hesapta işlem yok. Hesap listeden kaldırılır.'
            : 'Bu hesapta $count işlem var. Silersen bu işlemler iptal edilir (ters kayıt) ve '
                'karşı hesapların bakiyeleri de buna göre düzelir. Bu adım geri alınamaz; '
                'denetim kaydına yazılır.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: ctx.tokens.expense),
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(count == 0 ? 'Sil' : 'İşlemlerle birlikte sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final reversed = await service.delete(accountId: item.account.id, opKey: newId(), withEntries: count > 0);
    messenger.showSnackBar(SnackBar(
      content: Text(reversed == 0 ? '“$name” silindi.' : '“$name” silindi, $reversed işlem iptal edildi.'),
    ));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = item.account;
    final tone = switch (a.kind) {
      AccountKind.krediKarti || AccountKind.kredi =>
        item.balance.isPositive ? MoneyTone.expense : MoneyTone.neutral,
      AccountKind.cari => MoneyTone.signed,
      _ => item.balance.isNegative ? MoneyTone.expense : MoneyTone.neutral,
    };
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.xxs),
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: context.tokens.mutedSurface,
          borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
        ),
        child: Icon(a.kind.icon, size: 20, color: context.colors.secondary),
      ),
      title: Text(a.name, style: context.text.titleSmall),
      subtitle: switch (a.kind) {
        AccountKind.kredi => _LoanHint(accountId: a.id),
        AccountKind.birikim => _AssetHint(accountId: a.id),
        _ => Text(_hint(a.kind, item.balance), style: context.text.bodySmall),
      },
      onTap: () => context.push('/hesaplar/${a.id}'),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        MoneyText(item.balance, tone: tone, style: context.text.titleSmall),
        PopupMenuButton<_Action>(
          tooltip: 'Hesap işlemleri',
          onSelected: (v) => _onAction(context, ref, v),
          itemBuilder: (_) => const [
            PopupMenuItem(value: _Action.rename, child: Text('Yeniden adlandır')),
            PopupMenuItem(value: _Action.archive, child: Text('Arşivle (bakiye sıfırsa)')),
            PopupMenuItem(value: _Action.delete, child: Text('Sil')),
          ],
        ),
      ]),
    );
  }
}

/// Kredi satırında sıradaki taksit hatırlatması.
class _LoanHint extends ConsumerWidget {
  const _LoanHint({required this.accountId});
  final String accountId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final next = ref.watch(nextInstallmentProvider(accountId)).valueOrNull;
    if (next == null) return Text('Kalan kredi borcu', style: context.text.bodySmall);
    final now = ref.watch(clockProvider).now();
    final due = DateTime(next.dueDate.year, next.dueDate.month, next.dueDate.day);
    final soon = !due.isAfter(DateTime(now.year, now.month, now.day + 3));
    return Text(
      '${next.no}. taksit ${TrFormat.dayMonth(next.dueDate)} · ${MoneyFormat.format(next.amount)} · '
      '${dueLabel(next.dueDate, now)}',
      style: context.text.bodySmall!.copyWith(color: soon ? context.tokens.expense : null),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

/// Birikim satırında miktar ve (fiyat girildiyse) güncel değer / kâr-zarar.
class _AssetHint extends ConsumerWidget {
  const _AssetHint({required this.accountId});
  final String accountId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final a = ref.watch(assetProvider(accountId)).valueOrNull;
    if (a == null) return Text('Birikim', style: context.text.bodySmall);
    final un = a.unrealized;
    return Text(
      '${Qty.format(a.quantityE8)} ${a.unit}'
      '${a.marketValue == null ? ' · maliyet' : ' · değer ${MoneyFormat.format(a.marketValue!)}'}'
      '${un == null ? '' : ' (${un.isNegative ? '' : '+'}${MoneyFormat.format(un)})'}',
      style: context.text.bodySmall!.copyWith(
        color: un == null ? null : (un.isNegative ? context.tokens.expense : context.tokens.income),
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}
