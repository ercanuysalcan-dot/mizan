import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../cards/presentation/card_section.dart';
import '../../loans/presentation/loan_section.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../../transactions/data/entries_repository.dart';
import '../../transactions/presentation/entry_detail_sheet.dart';
import '../application/accounts_providers.dart';
import 'account_kind_ui.dart';

final accountEntriesProvider = StreamProvider.autoDispose.family<List<AccountEntry>, String>((ref, accountId) {
  return ref.watch(entriesRepositoryProvider).watchAccountEntries(accountId);
});

/// Hesap ayrıntısı: bakiye, türe özel bölüm (kredi planı, kart ekstreleri)
/// ve hesap hareketleri (ekstre).
class AccountDetailScreen extends ConsumerWidget {
  const AccountDetailScreen({super.key, required this.accountId});
  final String accountId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final accounts = ref.watch(userAccountsProvider);
    return accounts.when(
      loading: () => Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(appBar: AppBar(), body: Center(child: Text('Hesap yüklenemedi: $e'))),
      data: (list) {
        final item = list.where((a) => a.account.id == accountId).firstOrNull;
        if (item == null) {
          return Scaffold(appBar: AppBar(), body: const Center(child: Text('Hesap bulunamadı.')));
        }
        final a = item.account;
        final entries = ref.watch(accountEntriesProvider(accountId));
        return Scaffold(
          appBar: AppBar(title: Text(a.name)),
          body: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 820),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(Space.lg, Space.sm, Space.lg, 120),
                children: [
                  if (a.kind != AccountKind.kredi) ...[
                    MizanCard(
                      child: Row(children: [
                        Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(
                            color: context.tokens.mutedSurface,
                            borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                          ),
                          child: Icon(a.kind.icon, color: context.colors.secondary),
                        ),
                        Space.gapMd,
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(
                              a.kind == AccountKind.krediKarti ? 'KART BORCU' : a.kind.label.toUpperCase(),
                              style: context.text.labelSmall,
                            ),
                            MoneyText(
                              item.balance,
                              style: context.text.headlineMedium,
                              tone: a.kind == AccountKind.krediKarti && item.balance.isPositive
                                  ? MoneyTone.expense
                                  : MoneyTone.neutral,
                            ),
                          ]),
                        ),
                      ]),
                    ),
                    Space.gapLg,
                  ],
                  if (a.kind == AccountKind.kredi) ...[
                    LoanSection(accountId: a.id),
                    Space.gapLg,
                  ],
                  if (a.kind == AccountKind.krediKarti) ...[
                    CardSection(card: a),
                    Space.gapLg,
                  ],
                  const SectionHeader('Hareketler'),
                  entries.when(
                    loading: () => const Center(child: CircularProgressIndicator()),
                    error: (e, _) => Text('Hareketler yüklenemedi: $e'),
                    data: (rows) => rows.isEmpty
                        ? const MizanCard(
                            child: EmptyState(compact: true, icon: Icons.list_alt_rounded, title: 'Henüz hareket yok'),
                          )
                        : MizanCard(
                            padding: const EdgeInsets.symmetric(vertical: Space.xs),
                            child: Column(children: [
                              for (var i = 0; i < rows.length; i++) ...[
                                if (i > 0) const Divider(height: 1),
                                _EntryTile(row: rows[i], kind: a.kind),
                              ],
                            ]),
                          ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _EntryTile extends StatelessWidget {
  const _EntryTile({required this.row, required this.kind});
  final AccountEntry row;
  final AccountKind kind;

  @override
  Widget build(BuildContext context) {
    final e = row.entry;
    // Borç hesaplarında (kart, kredi) artış kötü, azalış iyi.
    final liability = kind.normalSide.code == 'C';
    final good = liability ? row.effect.isNegative : row.effect.isPositive;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg),
      title: Text(e.title, style: context.text.titleSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${TrFormat.date(e.date)} · ${e.flow}',
          style: context.text.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: MoneyText(
        row.effect,
        showPlus: true,
        animate: false,
        style: context.text.titleSmall!.copyWith(color: good ? context.tokens.income : context.tokens.expense),
      ),
      onTap: () => showEntryDetailSheet(context, e),
    );
  }
}
