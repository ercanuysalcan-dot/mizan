import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../application/entry_edit_service.dart';
import '../data/entries_repository.dart';

/// Kayıt düzenleme formu. Kaydedilirse true döner.
Future<bool?> showEditEntrySheet(BuildContext context, EntryDetail entry) => showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 600),
      builder: (_) => _EditEntrySheet(entry: entry),
    );

class _EditEntrySheet extends ConsumerStatefulWidget {
  const _EditEntrySheet({required this.entry});
  final EntryDetail entry;

  @override
  ConsumerState<_EditEntrySheet> createState() => _EditEntrySheetState();
}

class _EditEntrySheetState extends ConsumerState<_EditEntrySheet> {
  late final EntryDetail _d = widget.entry;
  late final _amount = TextEditingController(text: MoneyFormat.format(_d.amount, symbol: false));
  late final _desc = TextEditingController(text: _d.description ?? '');
  late DateTime _date = _d.date;
  late String? _categoryId = _d.categoryLineIndex == null ? null : _d.lines[_d.categoryLineIndex!].categoryId;
  late String? _moneyId = _d.moneyLineIndex == null ? null : _d.lines[_d.moneyLineIndex!].accountId;
  final String _key = newId();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _amount.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(entryEditServiceProvider).edit(
            entryId: _d.id,
            editKey: _key,
            amountText: _amount.text,
            date: _date,
            description: _desc.text,
            categoryId: _categoryId,
            moneyAccountId: _moneyId,
          );
      if (!mounted) return;
      Navigator.pop(context, true);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kayıt düzeltildi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final c = _d.amount.currency;
    final catIndex = _d.categoryLineIndex;
    final moneyIndex = _d.moneyLineIndex;
    final catType = catIndex == null ? null : _d.lines[catIndex].kind.code; // 'gelir' | 'gider'
    final cats = catType == null
        ? const <CategoryInfo>[]
        : (ref.watch(categoriesProvider(catType)).valueOrNull ?? const <CategoryInfo>[]);

    final otherKind = moneyIndex == null ? null : _d.lines[1 - moneyIndex].kind;
    final allowedMoney = otherKind == AccountKind.gider
        ? {AccountKind.kasa, AccountKind.banka, AccountKind.krediKarti}
        : {AccountKind.kasa, AccountKind.banka};
    final otherAccountId = moneyIndex == null ? null : _d.lines[1 - moneyIndex].accountId;
    final moneyAccounts = moneyIndex == null
        ? const <AccountWithBalance>[]
        : (ref.watch(userAccountsProvider).valueOrNull ?? const <AccountWithBalance>[])
            .where((a) =>
                a.account.currency == c &&
                allowedMoney.contains(a.account.kind) &&
                a.account.id != otherAccountId)
            .toList();

    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Kaydı düzenle', style: context.text.headlineSmall),
            Space.gapXs,
            Text(_d.type.label, style: context.text.bodySmall),
            Space.gapLg,
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
              style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
              decoration: InputDecoration(labelText: 'Tutar', suffixText: c.code),
            ),
            Space.gapMd,
            OutlinedButton.icon(
              icon: const Icon(Icons.event_outlined, size: 18),
              label: Text('Tarih: ${TrFormat.date(_date)}'),
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(_date.year + 5),
                );
                if (picked != null) {
                  setState(() => _date = DateTime(picked.year, picked.month, picked.day, _date.hour, _date.minute));
                }
              },
            ),
            if (moneyIndex != null) ...[
              Space.gapMd,
              DropdownButtonFormField<String>(
                // ignore: deprecated_member_use
                value: moneyAccounts.any((a) => a.account.id == _moneyId) ? _moneyId : null,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Hesap'),
                items: [
                  for (final a in moneyAccounts)
                    DropdownMenuItem(
                      value: a.account.id,
                      child: Text(a.account.name, overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: (v) => setState(() => _moneyId = v),
              ),
            ],
            if (catIndex != null) ...[
              Space.gapMd,
              DropdownButtonFormField<String>(
                // ignore: deprecated_member_use
                value: cats.any((x) => x.id == _categoryId) ? _categoryId : null,
                isExpanded: true,
                decoration: InputDecoration(labelText: catType == 'gelir' ? 'Gelir kategorisi' : 'Gider kategorisi'),
                items: [
                  for (final x in cats)
                    DropdownMenuItem(value: x.id, child: Text(x.displayName, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _categoryId = v),
              ),
            ],
            Space.gapMd,
            TextField(
              controller: _desc,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Açıklama'),
            ),
            Space.gapSm,
            Text(
              'Kaydettiğinde eski kayıt ters kayıtla iptal edilir, doğrusu yazılır ve ilgili tüm bakiyeler '
              'kendiliğinden düzelir. Eski hali “Değişiklik geçmişi”nde görünür.',
              style: context.text.bodySmall,
            ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Düzeltmeyi kaydet'),
            ),
          ],
        ),
      ),
    );
  }
}
