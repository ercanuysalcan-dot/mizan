import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../attachments/data/attachments_repository.dart';
import '../../attachments/presentation/attachment_widgets.dart';
import '../../dashboard/domain/dashboard_models.dart';
import '../application/entry_edit_service.dart';
import '../data/entries_repository.dart';
import 'edit_entry_sheet.dart';

Future<void> showEntryDetailSheet(BuildContext context, RecentEntry entry) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _EntryDetailSheet(entry: entry),
    );

class _EntryDetailSheet extends ConsumerStatefulWidget {
  const _EntryDetailSheet({required this.entry});
  final RecentEntry entry;

  @override
  ConsumerState<_EntryDetailSheet> createState() => _EntryDetailSheetState();
}

class _EntryDetailSheetState extends ConsumerState<_EntryDetailSheet> {
  // İptal anahtarı sayfa açılışında sabitlenir: çift dokunma iki ters kayıt üretmez.
  final _reverseKey = 'iptal:${newId()}';
  bool _busy = false;
  late final Future<EntryDetail?> _detail = ref.read(entriesRepositoryProvider).detail(widget.entry.id);
  late final Future<List<EntryHistoryItem>> _history = ref.read(entriesRepositoryProvider).history(widget.entry.id);

  Future<void> _reverse() async {
    final isLoan = await ref.read(entryEditServiceProvider).isLoanPayment(widget.entry.id);
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('İşlem iptal edilsin mi?'),
        content: Text(
          'Kayıt silinmez; aynı tarihli bir ters kayıt oluşturulur ve bakiyeler eski haline döner. '
          'Bu adım denetim kaydına yazılır.'
          '${isLoan ? '\n\nBu bir kredi taksiti ödemesi; taksit yeniden “ödenmedi” olur.' : ''}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('İptal et')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(entryEditServiceProvider).reverse(entryId: widget.entry.id, idempotencyKey: _reverseKey);
      if (mounted) Navigator.pop(context);
      messenger.showSnackBar(const SnackBar(content: Text('İşlem iptal edildi.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _edit(EntryDetail d) async {
    final saved = await showEditEntrySheet(context, d);
    // Düzeltilen kayıt artık iptal edilmiş durumda; ayrıntı sayfası kapanır.
    if (saved == true && mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    Widget row(String k, String v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 110, child: Text(k, style: context.text.bodySmall)),
            Expanded(child: Text(v, style: context.text.bodyMedium)),
          ]),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(e.type.label.toUpperCase(), style: context.text.labelSmall),
            Space.gapXs,
            Text(e.title, style: context.text.headlineSmall),
            Space.gapSm,
            MoneyText(e.amount, style: context.text.displaySmall, animate: false),
            Space.gapLg,
            row('Tarih', TrFormat.dateTime(e.date)),
            row('Çıkış', e.fromNames.join(', ')),
            row('Giriş', e.toNames.join(', ')),
            Space.gapLg,
            AttachmentStrip(ownerTable: AttachmentOwner.entry, ownerId: e.id, title: 'Fiş / fotoğraf'),
            Space.gapXl,
            FutureBuilder<EntryDetail?>(
              future: _detail,
              builder: (context, snap) {
                final d = snap.data;
                if (d == null || !d.isEditable) return const SizedBox.shrink();
                return Padding(
                  padding: const EdgeInsets.only(bottom: Space.sm),
                  child: FilledButton.tonalIcon(
                    onPressed: _busy ? null : () => _edit(d),
                    icon: const Icon(Icons.edit_outlined),
                    label: const Text('Düzenle (tutar, tarih, hesap, kategori)'),
                  ),
                );
              },
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _reverse,
              icon: _busy
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : Icon(Icons.undo_rounded, color: context.tokens.expense),
              label: Text('İşlemi iptal et', style: TextStyle(color: context.tokens.expense)),
            ),
            FutureBuilder<List<EntryHistoryItem>>(
              future: _history,
              builder: (context, snap) {
                final items = snap.data ?? const <EntryHistoryItem>[];
                if (items.isEmpty) return const SizedBox.shrink();
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Space.gapXl,
                    const SectionHeader('Değişiklik geçmişi'),
                    for (final h in items)
                      Padding(
                        padding: const EdgeInsets.only(bottom: Space.md),
                        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Icon(Icons.history_rounded, size: 18, color: context.colors.secondary),
                          Space.gapSm,
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${TrFormat.dateTime(h.changedAt)} düzeltildi', style: context.text.labelLarge),
                              Text(
                                'Önceki hali: ${MoneyFormat.format(h.previousAmount)} · '
                                '${TrFormat.date(h.previousDate)} · ${h.previousAccounts.join(' → ')}'
                                '${h.previousDescription == null ? '' : ' · “${h.previousDescription}”'}',
                                style: context.text.bodySmall,
                              ),
                            ]),
                          ),
                        ]),
                      ),
                  ],
                );
              },
            ),
            Space.gapSm,
            Text(
              'Muhasebe gereği düzenleme “iptal + yeni kayıt” olarak işlenir; eski hali değişiklik geçmişinde kalır.',
              style: context.text.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
