import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../dashboard/domain/dashboard_models.dart';

Future<void> showEntryDetailSheet(BuildContext context, RecentEntry entry) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _EntryDetailSheet(entry: entry),
    );

class _EntryDetailSheet extends ConsumerStatefulWidget {
  const _EntryDetailSheet({required this.entry});
  final RecentEntry entry;

  @override
  ConsumerState<_EntryDetailSheet> createState() => _EntryDetailSheetState();
}

class _EntryDetailSheetState extends ConsumerState<_EntryDetailSheet> {
  // İptal anahtarı sayfa açılışında sabitlenir: çift dokunma iki ters kayıt üretmez.
  final _reverseKey = 'iptal:${newId()}';
  bool _busy = false;

  Future<void> _reverse() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('İşlem iptal edilsin mi?'),
        content: const Text(
          'Kayıt silinmez; aynı tarihli bir ters kayıt oluşturulur ve bakiyeler eski haline döner. '
          'Bu adım denetim kaydına yazılır.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('İptal et')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    setState(() => _busy = true);
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(ledgerRepositoryProvider).reverse(entryId: widget.entry.id, idempotencyKey: _reverseKey);
      if (mounted) Navigator.pop(context);
      messenger.showSnackBar(const SnackBar(content: Text('İşlem iptal edildi.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    Widget row(String k, String v) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 110, child: Text(k, style: context.text.bodySmall)),
            Expanded(child: Text(v, style: context.text.bodyMedium)),
          ]),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(e.type.label.toUpperCase(), style: context.text.labelSmall),
          Space.gapXs,
          Text(e.title, style: context.text.headlineSmall),
          Space.gapSm,
          MoneyText(e.amount, style: context.text.displaySmall, animate: false),
          Space.gapLg,
          row('Tarih', TrFormat.dateTime(e.date)),
          row('Çıkış', e.fromNames.join(', ')),
          row('Giriş', e.toNames.join(', ')),
          Space.gapXl,
          OutlinedButton.icon(
            onPressed: _busy ? null : _reverse,
            icon: _busy
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : Icon(Icons.undo_rounded, color: context.tokens.expense),
            label: Text('İşlemi iptal et', style: TextStyle(color: context.tokens.expense)),
          ),
          Space.gapSm,
          Text(
            'Düzenleme ekranı Aşama 2’de gelecek. Muhasebe gereği düzenleme de “iptal + yeni kayıt” olarak işlenir.',
            style: context.text.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
