import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../export/export_sheet.dart';
import '../../export/reports.dart';
import '../application/transactions_providers.dart';
import '../data/transactions_query.dart';
import 'entry_detail_sheet.dart';

const _weekdays = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar'];

/// Tüm hesap hareketleri: güne göre gruplu, dönem / tür / hesap / kategori
/// süzgeci ve arama ile.
class TransactionsScreen extends ConsumerStatefulWidget {
  const TransactionsScreen({super.key});

  @override
  ConsumerState<TransactionsScreen> createState() => _TransactionsScreenState();
}

class _TransactionsScreenState extends ConsumerState<TransactionsScreen> {
  bool _searching = false;
  final _search = TextEditingController();

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _pickCustom() async {
    final now = ref.read(clockProvider).now();
    final f = ref.read(txViewProvider).filter;
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(now.year + 5, 12, 31),
      initialDateRange: f.start != null && f.end != null
          ? DateTimeRange(start: f.start!, end: f.end!.subtract(const Duration(days: 1)))
          : null,
      helpText: 'Tarih aralığı seç',
      saveText: 'Uygula',
    );
    if (picked != null) ref.read(txViewProvider.notifier).selectCustom(picked.start, picked.end);
  }

  String _periodLabel(TxView view) {
    final f = view.filter;
    final base = switch (view.period) {
      TxPeriod.month || TxPeriod.lastMonth => f.start == null ? view.period.label : TrFormat.monthYear(f.start!),
      TxPeriod.year => f.start == null ? view.period.label : '${f.start!.year} yılı',
      TxPeriod.all => 'Tüm zamanlar',
      TxPeriod.custom => f.start == null || f.end == null
          ? 'Seçili tarihler'
          : '${TrFormat.date(f.start!)} – ${TrFormat.date(f.end!.subtract(const Duration(days: 1)))}',
    };
    return f.direction == null ? base : '$base · ${f.direction!.label}';
  }

  void _export() {
    final page = ref.read(transactionsPageProvider).valueOrNull;
    if (page == null) return;
    final business = ref.read(currentBusinessProvider);
    final meta = ReportMeta(
      businessName: business.name,
      title: 'İşlemler raporu',
      periodLabel: _periodLabel(ref.read(txViewProvider)),
      generatedAt: ref.read(clockProvider).now(),
    );
    showExportSheet(
      context,
      title: 'Dışa aktar',
      subtitle: '${meta.periodLabel} · ${page.items.length} işlem (seçili dönem ve süzgeçle)',
      excel: () async => transactionsXlsx(page, meta),
      pdf: () => transactionsPdf(page, meta),
    );
  }

  @override
  Widget build(BuildContext context) {
    final view = ref.watch(txViewProvider);
    final page = ref.watch(transactionsPageProvider);
    final f = view.filter;
    final activeFilters = (f.direction != null ? 1 : 0) + (f.accountId != null ? 1 : 0) + (f.categoryId != null ? 1 : 0);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: CustomScrollView(slivers: [
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(Space.lg, Space.lg, Space.lg, 0),
                sliver: SliverList.list(children: [
                  Row(children: [
                    Icon(Icons.history_rounded, color: context.colors.secondary),
                    Space.gapSm,
                    Expanded(child: Text('İşlemler', style: context.text.headlineMedium)),
                    IconButton(
                      tooltip: 'Ara',
                      onPressed: () => setState(() {
                        _searching = !_searching;
                        if (!_searching) {
                          _search.clear();
                          ref.read(txViewProvider.notifier).setSearch('');
                        }
                      }),
                      icon: Icon(_searching ? Icons.search_off_rounded : Icons.search_rounded),
                    ),
                    IconButton(
                      tooltip: 'Excel / PDF',
                      onPressed: _export,
                      icon: const Icon(Icons.file_download_outlined),
                    ),
                    Badge(
                      isLabelVisible: activeFilters > 0,
                      label: Text('$activeFilters'),
                      child: IconButton.outlined(
                        tooltip: 'Filtrele',
                        onPressed: () => showTxFilterSheet(context),
                        icon: const Icon(Icons.filter_list_rounded),
                      ),
                    ),
                  ]),
                  if (_searching) ...[
                    Space.gapSm,
                    TextField(
                      controller: _search,
                      autofocus: true,
                      textInputAction: TextInputAction.search,
                      onChanged: (v) => ref.read(txViewProvider.notifier).setSearch(v),
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search_rounded),
                        hintText: 'Açıklama ya da hesap / kategori adı',
                      ),
                    ),
                  ],
                  Space.gapMd,
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(children: [
                      for (final p in TxPeriod.values) ...[
                        ChoiceChip(
                          label: Text(p == TxPeriod.custom && view.period == TxPeriod.custom && f.start != null
                              ? '${TrFormat.dayMonth(f.start!)} – '
                                  '${TrFormat.dayMonth(f.end!.subtract(const Duration(days: 1)))}'
                              : p.label),
                          selected: view.period == p,
                          onSelected: (_) => p == TxPeriod.custom
                              ? _pickCustom()
                              : ref.read(txViewProvider.notifier).selectPeriod(p),
                        ),
                        Space.gapSm,
                      ],
                    ]),
                  ),
                  if (activeFilters > 0) ...[
                    Space.gapSm,
                    _ActiveFilters(filter: f),
                  ],
                  Space.gapMd,
                ]),
              ),
              ...page.when<List<Widget>>(
                skipLoadingOnReload: true,
                loading: () => [
                  const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator())),
                ],
                error: (e, _) => [SliverToBoxAdapter(child: Center(child: Text('İşlemler yüklenemedi: $e')))],
                data: (p) => _content(context, p),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  List<Widget> _content(BuildContext context, TxPage p) {
    if (p.items.isEmpty) {
      return [
        const SliverFillRemaining(
          hasScrollBody: false,
          child: Center(
            child: EmptyState(
              icon: Icons.receipt_long_outlined,
              title: 'Bu dönemde işlem yok',
              message: 'Dönemi ya da süzgeci değiştir, veya “İşlem ekle” ile yeni kayıt gir.',
            ),
          ),
        ),
      ];
    }
    final groups = <DateTime, List<TxItem>>{};
    for (final it in p.items) {
      final d = it.entry.date;
      groups.putIfAbsent(DateTime(d.year, d.month, d.day), () => []).add(it);
    }
    return [
      SliverPadding(
        padding: const EdgeInsets.symmetric(horizontal: Space.lg),
        sliver: SliverToBoxAdapter(child: _TotalsCard(page: p)),
      ),
      const SliverToBoxAdapter(child: SizedBox(height: Space.md)),
      for (final g in groups.entries) ...[
        SliverToBoxAdapter(child: _DayHeader(day: g.key, items: g.value)),
        SliverList.separated(
          itemCount: g.value.length,
          separatorBuilder: (_, __) => const Divider(height: 1, indent: Space.lg, endIndent: Space.lg),
          itemBuilder: (_, i) => _TxTile(item: g.value[i]),
        ),
      ],
      if (p.truncated)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(Space.lg),
            child: Text(
              'En yeni ${TransactionsQuery.limit} işlem gösteriliyor. Daha eskileri için dönemi daralt.',
              style: context.text.bodySmall,
              textAlign: TextAlign.center,
            ),
          ),
        ),
      const SliverToBoxAdapter(child: SizedBox(height: 120)),
    ];
  }
}

class _TotalsCard extends StatelessWidget {
  const _TotalsCard({required this.page});
  final TxPage page;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    Widget cell(String label, Money m, Color? color) => Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: context.text.labelSmall),
            Text(
              MoneyFormat.format(m),
              style: context.text.titleSmall!.copyWith(color: color, fontFeatures: MizanTheme.tabular),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ]),
        );
    return MizanCard(
      child: Column(children: [
        if (page.totals.isEmpty)
          Row(children: [
            Expanded(child: Text('${page.items.length} işlem · gelir/gider yok', style: context.text.bodySmall)),
          ]),
        for (var i = 0; i < page.totals.length; i++) ...[
          if (i > 0) const Divider(height: Space.lg),
          Row(children: [
            cell('GELİR', page.totals[i].income, t.income),
            cell('GİDER', page.totals[i].expense, t.expense),
            cell('NET', page.totals[i].net, page.totals[i].net.isNegative ? t.expense : t.income),
          ]),
        ],
        if (page.totals.isNotEmpty) ...[
          Space.gapSm,
          Align(
            alignment: Alignment.centerLeft,
            child: Text('${page.items.length} işlem', style: context.text.bodySmall),
          ),
        ],
      ]),
    );
  }
}

class _DayHeader extends StatelessWidget {
  const _DayHeader({required this.day, required this.items});
  final DateTime day;
  final List<TxItem> items;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final net = <Currency, int>{};
    for (final it in items) {
      final sign = switch (it.direction) {
        TxDirection.income => 1,
        TxDirection.expense => -1,
        TxDirection.transfer => 0,
      };
      if (sign == 0) continue;
      final c = it.entry.amount.currency;
      net[c] = (net[c] ?? 0) + sign * it.entry.amount.minor;
    }
    return Container(
      margin: const EdgeInsets.only(top: Space.sm),
      color: t.mutedSurface,
      padding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.sm),
      child: Row(children: [
        Text('${day.day}', style: context.text.displaySmall!.copyWith(color: context.colors.onSurfaceVariant)),
        Space.gapMd,
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(TrFormat.monthYear(day), style: context.text.titleSmall),
            Text(_weekdays[day.weekday - 1], style: context.text.bodySmall),
          ]),
        ),
        for (final e in net.entries)
          Padding(
            padding: const EdgeInsets.only(left: Space.sm),
            child: Text(
              '${e.value > 0 ? '+' : ''}${MoneyFormat.format(Money.fromMinor(e.value, e.key))}',
              style: context.text.labelLarge!.copyWith(
                color: e.value < 0 ? t.expense : t.income,
                fontFeatures: MizanTheme.tabular,
              ),
            ),
          ),
      ]),
    );
  }
}

class _TxTile extends StatelessWidget {
  const _TxTile({required this.item});
  final TxItem item;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final e = item.entry;
    final color = switch (item.direction) {
      TxDirection.income => t.income,
      TxDirection.expense => t.expense,
      TxDirection.transfer => context.colors.onSurface,
    };
    final sign = switch (item.direction) {
      TxDirection.income => '+',
      TxDirection.expense => '−',
      TxDirection.transfer => '',
    };
    final from = e.fromNames.join(', ');
    final to = e.toNames.join(', ');
    final flow = from.isEmpty ? to : (to.isEmpty ? from : '$from → $to');
    return InkWell(
      onTap: () => showEntryDetailSheet(context, e),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.md),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                '${e.type.label.toUpperCase()}  ·  ${TrFormat.two(e.date.hour)}:${TrFormat.two(e.date.minute)}',
                style: context.text.labelSmall,
              ),
              const SizedBox(height: Space.xxs),
              Text(item.title, style: context.text.titleMedium, maxLines: 1, overflow: TextOverflow.ellipsis),
              if (flow.isNotEmpty)
                Text(flow,
                    style: context.text.bodyMedium!.copyWith(color: context.colors.primary),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              if (item.note != null)
                Text(item.note!, style: context.text.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
            ]),
          ),
          Space.gapMd,
          Text(
            '$sign${MoneyFormat.format(e.amount)}',
            style: context.text.titleMedium!.copyWith(color: color, fontFeatures: MizanTheme.tabular),
          ),
        ]),
      ),
    );
  }
}

class _ActiveFilters extends ConsumerWidget {
  const _ActiveFilters({required this.filter});
  final TxFilter filter;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final n = ref.read(txViewProvider.notifier);
    final accounts = ref.watch(userAccountsProvider).valueOrNull ?? const <AccountWithBalance>[];
    final cats = [
      ...(ref.watch(categoriesProvider('gider')).valueOrNull ?? const <CategoryInfo>[]),
      ...(ref.watch(categoriesProvider('gelir')).valueOrNull ?? const <CategoryInfo>[]),
    ];
    String? accName;
    for (final a in accounts) {
      if (a.account.id == filter.accountId) accName = a.account.name;
    }
    String? catName;
    for (final c in cats) {
      if (c.id == filter.categoryId) catName = c.displayName;
    }
    return Wrap(spacing: Space.sm, runSpacing: Space.xs, children: [
      if (filter.direction != null)
        InputChip(
          label: Text(filter.direction!.label),
          onDeleted: () => n.setFilter(filter.copyWith(clearDirection: true)),
        ),
      if (filter.accountId != null)
        InputChip(
          avatar: const Icon(Icons.account_balance_wallet_outlined, size: 16),
          label: Text(accName ?? 'Hesap'),
          onDeleted: () => n.setFilter(filter.copyWith(clearAccount: true)),
        ),
      if (filter.categoryId != null)
        InputChip(
          avatar: const Icon(Icons.category_outlined, size: 16),
          label: Text(catName ?? 'Kategori'),
          onDeleted: () => n.setFilter(filter.copyWith(clearCategory: true)),
        ),
    ]);
  }
}

Future<void> showTxFilterSheet(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => const _FilterSheet(),
    );

class _FilterSheet extends ConsumerStatefulWidget {
  const _FilterSheet();

  @override
  ConsumerState<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends ConsumerState<_FilterSheet> {
  late TxFilter _f = ref.read(txViewProvider).filter;

  @override
  Widget build(BuildContext context) {
    final accounts = ref.watch(userAccountsProvider).valueOrNull ?? const <AccountWithBalance>[];
    final catType = _f.direction == TxDirection.income ? 'gelir' : 'gider';
    final cats = _f.direction == TxDirection.transfer
        ? const <CategoryInfo>[]
        : (ref.watch(categoriesProvider(catType)).valueOrNull ?? const <CategoryInfo>[]);
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Filtrele', style: context.text.headlineSmall),
            Space.gapLg,
            Text('İşlem türü', style: context.text.labelLarge),
            Space.gapSm,
            Wrap(spacing: Space.sm, children: [
              ChoiceChip(
                label: const Text('Tümü'),
                selected: _f.direction == null,
                onSelected: (_) => setState(() => _f = _f.copyWith(clearDirection: true)),
              ),
              for (final d in TxDirection.values)
                ChoiceChip(
                  label: Text(d.label),
                  selected: _f.direction == d,
                  onSelected: (_) => setState(() => _f = _f.copyWith(direction: d, clearCategory: true)),
                ),
            ]),
            Space.gapLg,
            DropdownButtonFormField<String?>(
              // ignore: deprecated_member_use
              value: accounts.any((a) => a.account.id == _f.accountId) ? _f.accountId : null,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Hesap'),
              items: [
                const DropdownMenuItem<String?>(value: null, child: Text('Tüm hesaplar')),
                for (final a in accounts)
                  DropdownMenuItem<String?>(
                    value: a.account.id,
                    child: Text('${a.account.name} · ${a.account.kind.label}', overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) => setState(() => _f = v == null ? _f.copyWith(clearAccount: true) : _f.copyWith(accountId: v)),
            ),
            if (_f.direction != TxDirection.transfer) ...[
              Space.gapMd,
              DropdownButtonFormField<String?>(
                // ignore: deprecated_member_use
                value: cats.any((c) => c.id == _f.categoryId) ? _f.categoryId : null,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: _f.direction == TxDirection.income ? 'Gelir kategorisi' : 'Gider kategorisi',
                  helperText: _f.direction == null ? 'Gelir kategorisi için türü “Gelir” seç.' : null,
                ),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('Tüm kategoriler')),
                  for (final c in cats)
                    DropdownMenuItem<String?>(value: c.id, child: Text(c.displayName, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) =>
                    setState(() => _f = v == null ? _f.copyWith(clearCategory: true) : _f.copyWith(categoryId: v)),
              ),
            ],
            Space.gapXl,
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {
                    ref.read(txViewProvider.notifier).setFilter(
                          _f.copyWith(clearDirection: true, clearAccount: true, clearCategory: true),
                        );
                    Navigator.pop(context);
                  },
                  child: const Text('Temizle'),
                ),
              ),
              Space.gapMd,
              Expanded(
                child: FilledButton(
                  onPressed: () {
                    ref.read(txViewProvider.notifier).setFilter(_f);
                    Navigator.pop(context);
                  },
                  child: const Text('Uygula'),
                ),
              ),
            ]),
          ],
        ),
      ),
    );
  }
}
