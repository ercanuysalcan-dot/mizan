import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../accounts/presentation/create_account_sheet.dart';
import '../application/quick_entry_service.dart';

Future<void> showQuickEntrySheet(BuildContext context, {QuickEntryKind initial = QuickEntryKind.expense}) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 600),
      builder: (_) => QuickEntrySheet(initial: initial),
    );

class QuickEntrySheet extends ConsumerStatefulWidget {
  const QuickEntrySheet({super.key, this.initial = QuickEntryKind.expense});
  final QuickEntryKind initial;

  @override
  ConsumerState<QuickEntrySheet> createState() => _QuickEntrySheetState();
}

class _QuickEntrySheetState extends ConsumerState<QuickEntrySheet> {
  late QuickEntryKind _kind = widget.initial;
  String? _sourceId;
  String? _targetId;
  String? _categoryId;
  late DateTime _date = ref.read(clockProvider).now();
  final _amount = TextEditingController();
  final _desc = TextEditingController();
  String? _error;
  bool _busy = false;

  /// Form açılışında sabitlenen anahtar: çift dokunma ikinci kayıt üretmez.
  final String _idempotencyKey = newId();

  @override
  void dispose() {
    _amount.dispose();
    _desc.dispose();
    super.dispose();
  }

  void _setKind(QuickEntryKind k) => setState(() {
        _kind = k;
        _sourceId = null;
        _targetId = null;
        _categoryId = null;
        _error = null;
      });

  Future<void> _submit(List<AccountWithBalance> all) async {
    if (_sourceId == null) {
      setState(() => _error = '${_kind.sourceLabel} seçin.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(quickEntryServiceProvider).submit(
            kind: _kind,
            businessId: ref.read(currentBusinessProvider).id,
            sourceAccountId: _sourceId!,
            targetAccountId: _targetId,
            categoryId: _categoryId,
            amountText: _amount.text,
            date: _date,
            description: _desc.text,
            idempotencyKey: _idempotencyKey,
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${_kind.label} kaydedildi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final accountsAsync = ref.watch(userAccountsProvider);
    final bottom = MediaQuery.viewInsetsOf(context).bottom;

    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: accountsAsync.when(
        loading: () => const SizedBox(height: 240, child: Center(child: CircularProgressIndicator())),
        error: (e, _) => Text('Hesaplar yüklenemedi: $e'),
        data: (all) => SingleChildScrollView(child: _form(context, all)),
      ),
    );
  }

  Widget _form(BuildContext context, List<AccountWithBalance> all) {
    final sources = all.where((a) => _kind.sourceKinds.contains(a.account.kind)).toList();
    final source = sources.where((a) => a.account.id == _sourceId).firstOrNull;
    final targets = all
        .where((a) =>
            _kind.targetKinds.contains(a.account.kind) &&
            a.account.id != _sourceId &&
            (source == null || a.account.currency == source.account.currency))
        .toList();

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Yeni işlem', style: context.text.headlineSmall),
        Space.gapLg,
        Wrap(
          spacing: Space.sm,
          runSpacing: Space.sm,
          children: [
            for (final k in QuickEntryKind.values)
              ChoiceChip(label: Text(k.label), selected: _kind == k, onSelected: (_) => _setKind(k)),
          ],
        ),
        Space.gapLg,
        if (sources.isEmpty)
          _NoAccounts(kind: _kind)
        else ...[
          _accountDropdown(_kind.sourceLabel, sources, _sourceId, (v) => setState(() {
                _sourceId = v;
                _targetId = null;
              })),
          Space.gapMd,
          if (_kind.usesCategory)
            _CategoryDropdown(
              type: _kind.categoryType!,
              value: _categoryId,
              onChanged: (v) => setState(() => _categoryId = v),
            )
          else
            _accountDropdown(_kind.targetLabel, targets, _targetId, (v) => setState(() => _targetId = v)),
          Space.gapMd,
          TextField(
            controller: _amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
            style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
            decoration: InputDecoration(
              labelText: 'Tutar',
              hintText: '0,00',
              helperText: 'Ondalık için virgül: 1.250,75',
              suffixText: source?.account.currency.code,
            ),
          ),
          Space.gapMd,
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.event_outlined, size: 18),
                label: Text(TrFormat.date(_date)),
                onPressed: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _date,
                    firstDate: DateTime(2000),
                    lastDate: DateTime(_date.year + 5),
                  );
                  if (picked != null) {
                    final now = ref.read(clockProvider).now();
                    setState(() => _date = DateTime(picked.year, picked.month, picked.day, now.hour, now.minute));
                  }
                },
              ),
            ),
          ]),
          Space.gapMd,
          TextField(
            controller: _desc,
            decoration: const InputDecoration(labelText: 'Açıklama (isteğe bağlı)'),
            textCapitalization: TextCapitalization.sentences,
          ),
          if (source != null) ...[
            Space.gapSm,
            Text('Güncel bakiye: ${MoneyFormat.format(source.balance)}', style: context.text.bodySmall),
          ],
          if (_error != null) ...[
            Space.gapMd,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapXl,
          FilledButton(
            onPressed: _busy ? null : () => _submit(all),
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : Text('${_kind.label} kaydet'),
          ),
        ],
      ],
    );
  }

  Widget _accountDropdown(
    String label,
    List<AccountWithBalance> items,
    String? value,
    ValueChanged<String?> onChanged,
  ) {
    return DropdownButtonFormField<String>(
      // ignore: deprecated_member_use
      value: items.any((a) => a.account.id == value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: [
        for (final a in items)
          DropdownMenuItem(
            value: a.account.id,
            child: Text(
              '${a.account.name}  ·  ${MoneyFormat.format(a.balance)}',
              overflow: TextOverflow.ellipsis,
            ),
          ),
      ],
      onChanged: onChanged,
      hint: items.isEmpty ? const Text('Uygun hesap yok') : null,
    );
  }
}

class _CategoryDropdown extends ConsumerWidget {
  const _CategoryDropdown({required this.type, required this.value, required this.onChanged});
  final String type;
  final String? value;
  final ValueChanged<String?> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final cats = ref.watch(categoriesProvider(type)).valueOrNull ?? const <CategoryInfo>[];
    return DropdownButtonFormField<String>(
      // ignore: deprecated_member_use
      value: cats.any((c) => c.id == value) ? value : null,
      isExpanded: true,
      decoration: InputDecoration(labelText: type == 'gelir' ? 'Gelir kategorisi' : 'Gider kategorisi'),
      items: [for (final c in cats) DropdownMenuItem(value: c.id, child: Text(c.name))],
      onChanged: onChanged,
    );
  }
}

class _NoAccounts extends StatelessWidget {
  const _NoAccounts({required this.kind});
  final QuickEntryKind kind;

  @override
  Widget build(BuildContext context) {
    final needsCari = kind == QuickEntryKind.collection || kind == QuickEntryKind.payment;
    return EmptyState(
      compact: true,
      icon: Icons.account_balance_wallet_outlined,
      title: needsCari ? 'Önce bir cari hesap ekle' : 'Önce bir kasa veya banka hesabı ekle',
      message: 'İşlemler bir hesaba bağlı olarak kaydedilir.',
      action: FilledButton.tonal(
        // İşlem formu açık kalır; yeni hesap oluşunca liste kendiliğinden yenilenir.
        onPressed: () => showCreateAccountSheet(context),
        child: const Text('Hesap oluştur'),
      ),
    );
  }
}
