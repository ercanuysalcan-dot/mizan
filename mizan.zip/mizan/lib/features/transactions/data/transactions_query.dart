import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/money/money.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../dashboard/domain/dashboard_models.dart';

/// İşlemin gelir / gider / transfer yönü (renk ve filtre için).
enum TxDirection {
  income('Gelir'),
  expense('Gider'),
  transfer('Transfer');

  const TxDirection(this.label);
  final String label;
}

/// İşlemler listesindeki bir satır.
class TxItem {
  const TxItem({
    required this.entry,
    required this.direction,
    required this.categoryName,
  });

  final RecentEntry entry;
  final TxDirection direction;

  /// Gelir/gider kategorisi (varsa).
  final String? categoryName;

  /// Başlık: kategori, yoksa açıklama ya da işlem türü.
  String get title => categoryName ?? entry.title;

  /// Başlık kategori ise açıklama ayrıca gösterilir.
  String? get note {
    final d = entry.description;
    if (categoryName == null || d == null || d.trim().isEmpty) return null;
    return d;
  }
}

/// İşlemler ekranı süzgeci.
class TxFilter {
  const TxFilter({
    required this.start,
    required this.end,
    this.direction,
    this.accountId,
    this.categoryId,
    this.search = '',
  });

  /// [start] dahil, [end] hariç; null = sınırsız.
  final DateTime? start;
  final DateTime? end;
  final TxDirection? direction;
  final String? accountId;

  /// Ana kategori seçilirse alt kategorileri de dahildir.
  final String? categoryId;
  final String search;

  TxFilter copyWith({
    DateTime? start,
    DateTime? end,
    bool clearRange = false,
    TxDirection? direction,
    bool clearDirection = false,
    String? accountId,
    bool clearAccount = false,
    String? categoryId,
    bool clearCategory = false,
    String? search,
  }) =>
      TxFilter(
        start: clearRange ? null : (start ?? this.start),
        end: clearRange ? null : (end ?? this.end),
        direction: clearDirection ? null : (direction ?? this.direction),
        accountId: clearAccount ? null : (accountId ?? this.accountId),
        categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
        search: search ?? this.search,
      );

  @override
  bool operator ==(Object other) =>
      other is TxFilter &&
      other.start == start &&
      other.end == end &&
      other.direction == direction &&
      other.accountId == accountId &&
      other.categoryId == categoryId &&
      other.search == search;

  @override
  int get hashCode => Object.hash(start, end, direction, accountId, categoryId, search);
}

/// Para birimi başına dönem toplamı.
class TxTotals {
  const TxTotals(this.currency, this.income, this.expense);
  final Currency currency;
  final Money income;
  final Money expense;
  Money get net => income - expense;
}

class TxPage {
  const TxPage({required this.items, required this.totals, required this.truncated});
  final List<TxItem> items;
  final List<TxTotals> totals;

  /// Sınırdan fazla işlem var; yalnızca en yeniler gösteriliyor.
  final bool truncated;
}

/// İşlemler listesi sorgusu (iptal edilmiş ve iptal kayıtları gizlenir).
class TransactionsQuery {
  TransactionsQuery(this._db);

  final AppDatabase _db;

  static const limit = 1500;

  Stream<TxPage> watch(String businessId, TxFilter f) => _db.watchAll(() => load(businessId, f));

  Future<TxPage> load(String businessId, TxFilter f) async {
    final where = <String>[
      'e.business_id = ?',
      "e.status = 'posted'",
      "e.entry_type <> 'iptal'",
    ];
    final vars = <Variable>[Variable.withString(businessId)];
    if (f.start != null) {
      where.add('e.entry_date >= ?');
      vars.add(Variable.withInt(f.start!.millisecondsSinceEpoch));
    }
    if (f.end != null) {
      where.add('e.entry_date < ?');
      vars.add(Variable.withInt(f.end!.millisecondsSinceEpoch));
    }
    if (f.accountId != null) {
      where.add('EXISTS (SELECT 1 FROM journal_lines x WHERE x.entry_id = e.id AND x.account_id = ?)');
      vars.add(Variable.withString(f.accountId!));
    }
    if (f.categoryId != null) {
      where.add('EXISTS (SELECT 1 FROM journal_lines x JOIN accounts xa ON xa.id = x.account_id '
          'JOIN categories xc ON xc.id = xa.category_id '
          'WHERE x.entry_id = e.id AND (xc.id = ? OR xc.parent_id = ?))');
      vars
        ..add(Variable.withString(f.categoryId!))
        ..add(Variable.withString(f.categoryId!));
    }
    const hasIncome = "EXISTS (SELECT 1 FROM journal_lines x JOIN accounts xa ON xa.id = x.account_id "
        "WHERE x.entry_id = e.id AND xa.kind = 'gelir')";
    const hasExpense = "EXISTS (SELECT 1 FROM journal_lines x JOIN accounts xa ON xa.id = x.account_id "
        "WHERE x.entry_id = e.id AND xa.kind = 'gider')";
    switch (f.direction) {
      case TxDirection.income:
        where.add(hasIncome);
      case TxDirection.expense:
        where.add(hasExpense);
      case TxDirection.transfer:
        where.add('NOT $hasIncome AND NOT $hasExpense');
      case null:
        break;
    }
    final q = f.search.trim();
    if (q.isNotEmpty) {
      where.add('(e.description LIKE ? OR EXISTS (SELECT 1 FROM journal_lines x JOIN accounts xa '
          'ON xa.id = x.account_id WHERE x.entry_id = e.id AND xa.name LIKE ?))');
      final like = '%${q.replaceAll('%', '').replaceAll('_', '')}%';
      vars
        ..add(Variable.withString(like))
        ..add(Variable.withString(like));
    }
    vars.add(Variable.withInt(limit + 1));

    final idRows = await _db.customSelect(
      'SELECT e.id FROM journal_entries e WHERE ${where.join(' AND ')} '
      'ORDER BY e.entry_date DESC, e.created_at DESC LIMIT ?',
      variables: vars,
    ).get();
    final truncated = idRows.length > limit;
    final ids = [for (final r in idRows.take(limit)) r.read<String>('id')];
    if (ids.isEmpty) return const TxPage(items: [], totals: [], truncated: false);

    // Satırlar 500'lük parçalar halinde okunur (SQLite değişken sınırı).
    final lines = <String, List<QueryRow>>{};
    final heads = <String, QueryRow>{};
    for (var i = 0; i < ids.length; i += 500) {
      final chunk = ids.sublist(i, i + 500 > ids.length ? ids.length : i + 500);
      final placeholders = List.filled(chunk.length, '?').join(',');
      final rows = await _db.customSelect(
        '''
        SELECT e.id, e.entry_type, e.entry_date, e.description,
          l.currency, l.debit_minor, l.credit_minor, a.name, a.kind
        FROM journal_entries e
        JOIN journal_lines l ON l.entry_id = e.id
        JOIN accounts a ON a.id = l.account_id
        WHERE e.id IN ($placeholders)
        ORDER BY l.line_no
        ''',
        variables: [for (final id in chunk) Variable.withString(id)],
      ).get();
      for (final r in rows) {
        final id = r.read<String>('id');
        heads.putIfAbsent(id, () => r);
        lines.putIfAbsent(id, () => []).add(r);
      }
    }

    final items = <TxItem>[];
    final income = <Currency, int>{};
    final expense = <Currency, int>{};
    for (final id in ids) {
      final ls = lines[id];
      final head = heads[id];
      if (ls == null || head == null) continue;
      final currency = Currency.fromCode(head.read<String>('currency'));
      var amount = 0;
      String? category;
      var dir = TxDirection.transfer;
      final from = <String>[], to = <String>[];
      for (final l in ls) {
        final d = l.read<int>('debit_minor');
        final c = l.read<int>('credit_minor');
        final name = l.read<String>('name');
        final kind = AccountKind.fromCode(l.read<String>('kind'));
        if (kind == AccountKind.gelir) {
          dir = TxDirection.income;
          category ??= name;
        } else if (kind == AccountKind.gider) {
          dir = TxDirection.expense;
          category ??= name;
        }
        if (d > 0) {
          if (l.read<String>('currency') == currency.code) amount += d;
          if (!to.contains(name)) to.add(name);
        } else if (c > 0 && !from.contains(name)) {
          from.add(name);
        }
      }
      // Gelir/gider tarafını akış satırında tekrar göstermeye gerek yok.
      if (category != null) {
        from.remove(category);
        to.remove(category);
      }
      final entry = RecentEntry(
        id: id,
        type: EntryType.fromCode(head.read<String>('entry_type')),
        date: DateTime.fromMillisecondsSinceEpoch(head.read<int>('entry_date')),
        description: head.readNullable<String>('description'),
        amount: Money.fromMinor(amount, currency),
        fromNames: from,
        toNames: to,
      );
      items.add(TxItem(entry: entry, direction: dir, categoryName: category));
      if (dir == TxDirection.income) income[currency] = (income[currency] ?? 0) + amount;
      if (dir == TxDirection.expense) expense[currency] = (expense[currency] ?? 0) + amount;
    }

    final currencies = {...income.keys, ...expense.keys}.toList()..sort((a, b) => a.index.compareTo(b.index));
    return TxPage(
      items: items,
      truncated: truncated,
      totals: [
        for (final c in currencies)
          TxTotals(c, Money.fromMinor(income[c] ?? 0, c), Money.fromMinor(expense[c] ?? 0, c)),
      ],
    );
  }
}
