import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/money/money.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../dashboard/domain/dashboard_models.dart';

/// Bir kaydın tek satırı (düzenleme ekranı için).
class EntryLineInfo {
  const EntryLineInfo({
    required this.accountId,
    required this.accountName,
    required this.kind,
    required this.side,
    required this.amount,
    this.categoryId,
  });

  final String accountId;
  final String accountName;
  final AccountKind kind;
  final EntrySide side;
  final Money amount;

  /// Gelir/gider satırlarında kategori kimliği.
  final String? categoryId;
}

class EntryDetail {
  const EntryDetail({
    required this.id,
    required this.businessId,
    required this.type,
    required this.date,
    required this.description,
    required this.status,
    required this.lines,
  });

  final String id;
  final String businessId;
  final EntryType type;
  final DateTime date;
  final String? description;
  final String status;
  final List<EntryLineInfo> lines;

  /// Para tarafındaki (kasa/banka/kart) satırın sırası; birden fazla ya da hiç
  /// yoksa null (örn. iki banka arası transfer).
  int? get moneyLineIndex {
    final idx = <int>[
      for (var i = 0; i < lines.length; i++)
        if ({AccountKind.kasa, AccountKind.banka, AccountKind.krediKarti}.contains(lines[i].kind)) i,
    ];
    return idx.length == 1 ? idx.first : null;
  }

  /// Gelir/gider kategorisi satırı.
  int? get categoryLineIndex {
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].categoryId != null) return i;
    }
    return null;
  }

  /// Basit (iki satırlı, tek para birimli) kayıtlar düzenlenebilir.
  bool get isEditable =>
      status == 'posted' &&
      type != EntryType.iptal &&
      lines.length == 2 &&
      lines[0].amount.currency == lines[1].amount.currency &&
      lines[0].amount == lines[1].amount;

  Money get amount => lines.first.amount;
}

/// Bir hesabın ekstresindeki satır: kayıt + bu hesaba etkisi.
class AccountEntry {
  const AccountEntry(this.entry, this.effect);
  final RecentEntry entry;

  /// Hesabın normal yönünde imzalı etki (kasa için + giriş, kart için + borç).
  final Money effect;
}

/// Düzeltme geçmişindeki bir önceki hal.
class EntryHistoryItem {
  const EntryHistoryItem({
    required this.changedAt,
    required this.previousAmount,
    required this.previousDate,
    required this.previousDescription,
    required this.previousAccounts,
  });

  final DateTime changedAt;
  final Money previousAmount;
  final DateTime previousDate;
  final String? previousDescription;
  final List<String> previousAccounts;
}

/// Kayıt okuma sorguları (listeler, ayrıntı, geçmiş).
class EntriesRepository {
  EntriesRepository(this._db);

  final AppDatabase _db;

  Future<EntryDetail?> detail(String entryId) async {
    final head = await _db.customSelect(
      'SELECT id, business_id, entry_type, entry_date, description, status '
      'FROM journal_entries WHERE id = ?',
      variables: [Variable.withString(entryId)],
    ).getSingleOrNull();
    if (head == null) return null;
    final rows = await _db.customSelect(
      'SELECT l.account_id, l.currency, l.debit_minor, l.credit_minor, a.name, a.kind, a.category_id '
      'FROM journal_lines l JOIN accounts a ON a.id = l.account_id '
      'WHERE l.entry_id = ? ORDER BY l.line_no',
      variables: [Variable.withString(entryId)],
    ).get();
    return EntryDetail(
      id: head.read<String>('id'),
      businessId: head.read<String>('business_id'),
      type: EntryType.fromCode(head.read<String>('entry_type')),
      date: DateTime.fromMillisecondsSinceEpoch(head.read<int>('entry_date')),
      description: head.readNullable<String>('description'),
      status: head.read<String>('status'),
      lines: [
        for (final r in rows)
          EntryLineInfo(
            accountId: r.read<String>('account_id'),
            accountName: r.read<String>('name'),
            kind: AccountKind.fromCode(r.read<String>('kind')),
            side: r.read<int>('debit_minor') > 0 ? EntrySide.debit : EntrySide.credit,
            amount: Money.fromMinor(
              r.read<int>('debit_minor') + r.read<int>('credit_minor'),
              Currency.fromCode(r.read<String>('currency')),
            ),
            categoryId: r.readNullable<String>('category_id'),
          ),
      ],
    );
  }

  /// Hesabın kesinleşmiş (iptal edilmemiş) hareketleri, yeniden eskiye.
  Stream<List<AccountEntry>> watchAccountEntries(String accountId, {int limit = 300}) =>
      _db.watchAll(() => accountEntries(accountId, limit: limit));

  Future<List<AccountEntry>> accountEntries(String accountId, {int limit = 300}) async {
    final rows = await _db.customSelect(
      '''
      SELECT e.id, a.kind, SUM(l.debit_minor) AS d, SUM(l.credit_minor) AS c, l.currency
      FROM journal_entries e
      JOIN journal_lines l ON l.entry_id = e.id
      JOIN accounts a ON a.id = l.account_id
      WHERE l.account_id = ? AND e.status = 'posted' AND e.entry_type <> 'iptal'
      GROUP BY e.id, a.kind, l.currency
      ORDER BY e.entry_date DESC, e.created_at DESC
      LIMIT ?
      ''',
      variables: [Variable.withString(accountId), Variable.withInt(limit)],
    ).get();
    final effects = <String, Money>{
      for (final r in rows)
        r.read<String>('id'): Money.fromMinor(
          AccountKind.fromCode(r.read<String>('kind')).signedBalance(r.read<int>('d'), r.read<int>('c')),
          Currency.fromCode(r.read<String>('currency')),
        ),
    };
    final entries = await entriesByIds(effects.keys.toList());
    return [for (final e in entries) AccountEntry(e, effects[e.id]!)];
  }

  /// Kimlikleri verilen kayıtları liste görünümüne çevirir (sıra korunur).
  Future<List<RecentEntry>> entriesByIds(List<String> ids) async {
    if (ids.isEmpty) return const [];
    final placeholders = List.filled(ids.length, '?').join(',');
    final rows = await _db.customSelect(
      '''
      SELECT e.id, e.entry_type, e.entry_date, e.description,
        l.currency, l.debit_minor, l.credit_minor, a.name
      FROM journal_entries e
      JOIN journal_lines l ON l.entry_id = e.id
      JOIN accounts a ON a.id = l.account_id
      WHERE e.id IN ($placeholders)
      ORDER BY l.line_no
      ''',
      variables: [for (final id in ids) Variable.withString(id)],
    ).get();
    final byId = <String, List<QueryRow>>{};
    for (final r in rows) {
      byId.putIfAbsent(r.read<String>('id'), () => []).add(r);
    }
    final result = <RecentEntry>[];
    for (final id in ids) {
      final lines = byId[id];
      if (lines == null || lines.isEmpty) continue;
      final first = lines.first;
      final currency = Currency.fromCode(first.read<String>('currency'));
      var amount = 0;
      final from = <String>[], to = <String>[];
      for (final l in lines) {
        final d = l.read<int>('debit_minor');
        final name = l.read<String>('name');
        if (d > 0) {
          if (l.read<String>('currency') == currency.code) amount += d;
          if (!to.contains(name)) to.add(name);
        } else if (!from.contains(name)) {
          from.add(name);
        }
      }
      result.add(RecentEntry(
        id: id,
        type: EntryType.fromCode(first.read<String>('entry_type')),
        date: DateTime.fromMillisecondsSinceEpoch(first.read<int>('entry_date')),
        description: first.readNullable<String>('description'),
        amount: Money.fromMinor(amount, currency),
        fromNames: from,
        toNames: to,
      ));
    }
    return result;
  }

  /// Kaydın düzeltme zinciri: en yeni değişiklik başta.
  Future<List<EntryHistoryItem>> history(String entryId) async {
    final items = <EntryHistoryItem>[];
    var current = entryId;
    for (var guard = 0; guard < 100; guard++) {
      final row = await _db.customSelect(
        "SELECT before_json, occurred_at FROM audit_log WHERE entity_table = 'journal_entries' "
        "AND record_id = ? AND audit_action = 'update' AND before_json IS NOT NULL "
        'ORDER BY occurred_at DESC LIMIT 1',
        variables: [Variable.withString(current)],
      ).getSingleOrNull();
      if (row == null) break;
      final Map<String, dynamic> before;
      try {
        before = jsonDecode(row.read<String>('before_json')) as Map<String, dynamic>;
      } catch (_) {
        break;
      }
      final previousId = before['entry_id'] as String?;
      final minor = before['amount_minor'] as int?;
      final currency = before['currency'] as String?;
      final dateMs = before['date_ms'] as int?;
      if (previousId == null || minor == null || currency == null || dateMs == null) break;
      items.add(EntryHistoryItem(
        changedAt: DateTime.fromMillisecondsSinceEpoch(row.read<int>('occurred_at')),
        previousAmount: Money.fromMinor(minor, Currency.fromCode(currency)),
        previousDate: DateTime.fromMillisecondsSinceEpoch(dateMs),
        previousDescription: before['description'] as String?,
        previousAccounts: [for (final a in (before['accounts'] as List<dynamic>? ?? const [])) '$a'],
      ));
      if (previousId == current) break;
      current = previousId;
    }
    return items;
  }
}
