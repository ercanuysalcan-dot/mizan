import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../data/transactions_query.dart';

/// İşlemler ekranındaki dönem seçimi.
enum TxPeriod {
  month('Bu ay'),
  lastMonth('Geçen ay'),
  year('Bu yıl'),
  all('Tümü'),
  custom('Tarih seç');

  const TxPeriod(this.label);
  final String label;
}

class TxView {
  const TxView(this.period, this.filter);
  final TxPeriod period;
  final TxFilter filter;
}

/// Seçili dönem + süzgeç. Şirket değişince sıfırlanır.
class TxViewNotifier extends Notifier<TxView> {
  @override
  TxView build() {
    ref.watch(currentBusinessProvider);
    return TxView(TxPeriod.month, _range(TxPeriod.month, const TxFilter(start: null, end: null)));
  }

  TxFilter _range(TxPeriod p, TxFilter f) {
    final now = ref.read(clockProvider).now();
    return switch (p) {
      TxPeriod.month => f.copyWith(start: DateTime(now.year, now.month), end: DateTime(now.year, now.month + 1)),
      TxPeriod.lastMonth => f.copyWith(start: DateTime(now.year, now.month - 1), end: DateTime(now.year, now.month)),
      TxPeriod.year => f.copyWith(start: DateTime(now.year), end: DateTime(now.year + 1)),
      TxPeriod.all => f.copyWith(clearRange: true),
      TxPeriod.custom => f,
    };
  }

  void selectPeriod(TxPeriod p) => state = TxView(p, _range(p, state.filter));

  /// [last] dahil.
  void selectCustom(DateTime first, DateTime last) => state = TxView(
        TxPeriod.custom,
        state.filter.copyWith(
          start: DateTime(first.year, first.month, first.day),
          end: DateTime(last.year, last.month, last.day + 1),
        ),
      );

  void setFilter(TxFilter f) => state = TxView(state.period, f);

  void setSearch(String q) => state = TxView(state.period, state.filter.copyWith(search: q));
}

final txViewProvider = NotifierProvider<TxViewNotifier, TxView>(TxViewNotifier.new);

final transactionsQueryProvider = Provider<TransactionsQuery>((ref) => TransactionsQuery(ref.watch(databaseProvider)));

final transactionsPageProvider = StreamProvider.autoDispose<TxPage>((ref) {
  final business = ref.watch(currentBusinessProvider);
  final view = ref.watch(txViewProvider);
  return ref.watch(transactionsQueryProvider).watch(business.id, view.filter);
});
