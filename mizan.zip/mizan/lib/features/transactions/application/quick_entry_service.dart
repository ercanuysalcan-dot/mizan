import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../accounting/domain/posting_rules.dart';

enum QuickEntryKind {
  income('Gelir'),
  expense('Gider'),
  transfer('Transfer'),
  collection('Tahsilat'),
  payment('Ödeme');

  const QuickEntryKind(this.label);
  final String label;

  /// Kaynak (sol) hesap olarak seçilebilecek türler.
  Set<AccountKind> get sourceKinds => switch (this) {
        QuickEntryKind.income => {AccountKind.kasa, AccountKind.banka},
        QuickEntryKind.expense => {AccountKind.kasa, AccountKind.banka, AccountKind.krediKarti},
        QuickEntryKind.transfer => {
            AccountKind.kasa,
            AccountKind.banka,
            AccountKind.birikim,
            AccountKind.krediKarti,
          },
        QuickEntryKind.collection || QuickEntryKind.payment => {AccountKind.cari},
      };

  /// Karşı hesap türleri (kategori kullanan türlerde boş).
  Set<AccountKind> get targetKinds => switch (this) {
        QuickEntryKind.income || QuickEntryKind.expense => const <AccountKind>{},
        QuickEntryKind.transfer => sourceKinds,
        QuickEntryKind.collection || QuickEntryKind.payment => {AccountKind.kasa, AccountKind.banka},
      };

  bool get usesCategory => this == income || this == expense;
  String? get categoryType => switch (this) {
        QuickEntryKind.income => 'gelir',
        QuickEntryKind.expense => 'gider',
        _ => null,
      };

  String get sourceLabel => switch (this) {
        QuickEntryKind.income => 'Yatırılan hesap',
        QuickEntryKind.expense => 'Ödeme hesabı',
        QuickEntryKind.transfer => 'Kaynak hesap',
        QuickEntryKind.collection => 'Tahsilat yapılan cari',
        QuickEntryKind.payment => 'Ödeme yapılan cari',
      };

  String get targetLabel => switch (this) {
        QuickEntryKind.transfer => 'Hedef hesap',
        QuickEntryKind.collection => 'Paranın girdiği hesap',
        QuickEntryKind.payment => 'Paranın çıktığı hesap',
        _ => '',
      };
}

/// Hızlı işlem formunun uygulama servisi: form verisini çift kayıt
/// kurallarına çevirip muhasebe motoruna gönderir.
class QuickEntryService {
  QuickEntryService(this._ledger, this._accounts);

  final LedgerRepository _ledger;
  final AccountsRepository _accounts;

  Future<String> submit({
    required QuickEntryKind kind,
    required String businessId,
    required String sourceAccountId,
    String? targetAccountId,
    String? categoryId,
    required String amountText,
    required DateTime date,
    String? description,
    required String idempotencyKey,
  }) async {
    final source = await _ledger.account(sourceAccountId);
    final Money amount;
    try {
      amount = Money.parse(amountText, source.currency);
    } on FormatException catch (e) {
      throw AppException('AMOUNT', 'Tutar geçersiz: ${e.message}');
    }
    if (!amount.isPositive) throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');

    final List<PostingLine> lines;
    final EntryType type;
    switch (kind) {
      case QuickEntryKind.income:
        final cat = await _category(businessId, categoryId, source.currency);
        lines = PostingRules.income(moneyAccount: source, incomeAccount: cat, amount: amount);
        type = EntryType.gelir;
      case QuickEntryKind.expense:
        final cat = await _category(businessId, categoryId, source.currency);
        lines = PostingRules.expense(paidFrom: source, expenseAccount: cat, amount: amount);
        type = source.kind == AccountKind.krediKarti ? EntryType.kartHarcama : EntryType.gider;
      case QuickEntryKind.transfer:
        final target = await _target(targetAccountId);
        lines = PostingRules.transfer(from: source, to: target, amount: amount);
        type = PostingRules.transferType(source, target);
      case QuickEntryKind.collection:
        final target = await _target(targetAccountId);
        lines = PostingRules.collection(cari: source, moneyAccount: target, amount: amount);
        type = EntryType.tahsilat;
      case QuickEntryKind.payment:
        final target = await _target(targetAccountId);
        lines = PostingRules.payment(cari: source, moneyAccount: target, amount: amount);
        type = EntryType.odeme;
    }

    return _ledger.post(PostingRequest(
      businessId: businessId,
      type: type,
      date: date,
      idempotencyKey: idempotencyKey,
      description: description?.trim().isEmpty ?? true ? null : description!.trim(),
      lines: lines,
    ));
  }

  Future<LedgerAccount> _category(String businessId, String? categoryId, Currency currency) {
    if (categoryId == null) throw const AppException('CATEGORY', 'Kategori seçin.');
    return _accounts.ensureCategoryAccount(businessId, categoryId, currency);
  }

  Future<LedgerAccount> _target(String? id) {
    if (id == null) throw const AppException('TARGET', 'Karşı hesabı seçin.');
    return _ledger.account(id);
  }
}

final quickEntryServiceProvider = Provider<QuickEntryService>(
  (ref) => QuickEntryService(ref.watch(ledgerRepositoryProvider), ref.watch(accountsRepositoryProvider)),
);
