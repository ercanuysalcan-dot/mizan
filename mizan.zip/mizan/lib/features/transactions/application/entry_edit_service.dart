import 'dart:convert';

import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounts/data/accounts_repository.dart';
import '../data/entries_repository.dart';

/// Kayıt düzeltme ve iptal.
///
/// Muhasebe defteri değiştirilemez olduğundan düzeltme her zaman
/// "orijinali ters kayıtla iptal et + doğru kaydı yaz" olarak, tek bir
/// veritabanı işleminde yapılır. Kayda bağlı kredi taksiti, kart ekstresi ve
/// ekler yeni kayda taşınır; eski hal denetim kaydına yazılır ve
/// "Değişiklik geçmişi"nde gösterilir.
class EntryEditService {
  EntryEditService(
    this._db,
    this._ledger,
    this._accounts,
    this._entries, {
    required this.deviceId,
    Clock clock = const Clock(),
  }) : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final AccountsRepository _accounts;
  final EntriesRepository _entries;
  final String deviceId;
  final Clock _clock;

  /// Kaydı düzeltir ve yeni kaydın kimliğini döner.
  ///
  /// [editKey] düzenleme formunun açılışında üretilir; aynı anahtarla ikinci
  /// çağrı yeni bir düzeltme yapmaz. Boş bırakılan alanlar değişmez.
  /// [description] her zaman formdaki son hali olarak verilir (boş = yok).
  Future<String> edit({
    required String entryId,
    required String editKey,
    Money? amount,
    String? amountText,
    DateTime? date,
    String? description,
    bool keepDescription = false,
    String? categoryId,
    String? moneyAccountId,
  }) async {
    final newKey = 'duzeltme:$editKey';
    return _db.transaction(() async {
      final done = await _findByKey(newKey);
      if (done != null) return done;

      final d = await _entries.detail(entryId);
      if (d == null) throw LedgerException.of('LEDGER_NOT_FOUND');
      if (d.status == 'reversed') {
        throw const AppException('EDIT', 'Bu kayıt daha önce iptal edilmiş ya da düzeltilmiş.');
      }
      if (!d.isEditable) {
        throw const AppException(
            'EDIT', 'Bu kayıt düzenlenemiyor. İşlemi iptal edip doğrusunu yeniden girin.');
      }

      final currency = d.amount.currency;
      var newAmount = amount ?? d.amount;
      if (amountText != null) {
        try {
          newAmount = Money.parse(amountText, currency);
        } on FormatException catch (e) {
          throw AppException('AMOUNT', 'Tutar geçersiz: ${e.message}');
        }
      }
      if (newAmount.currency != currency) {
        throw const AppException('AMOUNT', 'Tutarın para birimi kayıtla aynı olmalı.');
      }
      if (!newAmount.isPositive) throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');

      final newDate = date ?? d.date;
      final String? newDesc = keepDescription
          ? d.description
          : ((description == null || description.trim().isEmpty) ? null : description.trim());

      var type = d.type;
      final lineAccounts = [for (final l in d.lines) l.accountId];
      final lineNames = [for (final l in d.lines) l.accountName];

      // Kategori değişikliği
      final catIndex = d.categoryLineIndex;
      if (categoryId != null && catIndex != null && categoryId != d.lines[catIndex].categoryId) {
        final cat = await _accounts.ensureCategoryAccount(d.businessId, categoryId, currency);
        if (cat.kind != d.lines[catIndex].kind) {
          throw const AppException('CATEGORY', 'Gelir kaydına gider kategorisi seçilemez (ya da tersi).');
        }
        lineAccounts[catIndex] = cat.id;
        lineNames[catIndex] = cat.name;
      }

      // Hesap değişikliği (kasa/banka/kart tarafı)
      final moneyIndex = d.moneyLineIndex;
      if (moneyAccountId != null && moneyIndex != null && moneyAccountId != d.lines[moneyIndex].accountId) {
        final acc = await _ledger.account(moneyAccountId);
        if (acc.currency != currency) {
          throw const AppException('ACCOUNT', 'Yeni hesabın para birimi kayıtla aynı olmalı.');
        }
        final otherKind = d.lines[1 - moneyIndex].kind;
        final allowed = otherKind == AccountKind.gider
            ? {AccountKind.kasa, AccountKind.banka, AccountKind.krediKarti}
            : {AccountKind.kasa, AccountKind.banka};
        if (!allowed.contains(acc.kind)) {
          throw AppException('ACCOUNT', '"${acc.name}" bu kayıt için uygun bir hesap değil.');
        }
        if (acc.id == lineAccounts[1 - moneyIndex]) {
          throw const AppException('ACCOUNT', 'İki taraf aynı hesap olamaz.');
        }
        lineAccounts[moneyIndex] = acc.id;
        lineNames[moneyIndex] = acc.name;
        if (type == EntryType.gider || type == EntryType.kartHarcama) {
          type = acc.kind == AccountKind.krediKarti ? EntryType.kartHarcama : EntryType.gider;
        }
      }

      final changed = newAmount != d.amount ||
          newDate.millisecondsSinceEpoch != d.date.millisecondsSinceEpoch ||
          newDesc != d.description ||
          lineAccounts[0] != d.lines[0].accountId ||
          lineAccounts[1] != d.lines[1].accountId;
      if (!changed) throw const AppException('EDIT_NOCHANGE', 'Değişiklik yok.');

      await _ledger.reverse(entryId: entryId, idempotencyKey: 'duzeltme-iptal:$editKey', reason: 'Düzeltme');
      final replacementId = await _ledger.post(PostingRequest(
        businessId: d.businessId,
        type: type,
        date: newDate,
        idempotencyKey: newKey,
        description: newDesc,
        lines: [
          for (var i = 0; i < d.lines.length; i++)
            PostingLine(accountId: lineAccounts[i], side: d.lines[i].side, amount: newAmount),
        ],
      ));

      await _moveLinks(entryId, replacementId, newAmount.minor);
      await _audit(
        businessId: d.businessId,
        recordId: replacementId,
        before: {
          'entry_id': d.id,
          'amount_minor': d.amount.minor,
          'currency': currency.code,
          'date_ms': d.date.millisecondsSinceEpoch,
          'description': d.description,
          'accounts': [for (final l in d.lines) l.accountName],
        },
        after: {
          'entry_id': replacementId,
          'amount_minor': newAmount.minor,
          'currency': currency.code,
          'date_ms': newDate.millisecondsSinceEpoch,
          'description': newDesc,
          'accounts': lineNames,
        },
      );
      return replacementId;
    });
  }

  /// Kaydı ters kayıtla iptal eder ve bağlı taksit/ekstre bağlantısını çözer
  /// (iptal edilen taksit yeniden "ödenmedi" olur).
  Future<String> reverse({required String entryId, required String idempotencyKey, String? reason}) {
    return _db.transaction(() async {
      final id = await _ledger.reverse(entryId: entryId, idempotencyKey: idempotencyKey, reason: reason);
      await _unlink(entryId);
      return id;
    });
  }

  /// Kayda bağlı kredi taksiti var mı (iptal uyarısı için).
  Future<bool> isLoanPayment(String entryId) async {
    final row = await _db.customSelect(
      'SELECT 1 FROM loan_installments WHERE paid_entry_id = ?',
      variables: [Variable.withString(entryId)],
    ).getSingleOrNull();
    return row != null;
  }

  // ----------------------------------------------------------------------------

  Future<void> _moveLinks(String oldId, String toId, int newAmountMinor) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE loan_installments SET paid_entry_id = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE paid_entry_id = ?',
      variables: [Variable.withString(toId), Variable.withInt(now), Variable.withString(oldId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
    await _db.customUpdate(
      'UPDATE card_statements SET entry_id = ?, amount_minor = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE entry_id = ?',
      variables: [
        Variable.withString(toId),
        Variable.withInt(newAmountMinor),
        Variable.withInt(now),
        Variable.withString(oldId),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
    await _db.customUpdate(
      'UPDATE loan_details SET opening_entry_id = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE opening_entry_id = ?',
      variables: [Variable.withString(toId), Variable.withInt(now), Variable.withString(oldId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
    await _db.customUpdate(
      "UPDATE attachments SET owner_id = ?, updated_at = ?, sync_status = 0, version = version + 1 "
      "WHERE owner_table = 'journal_entries' AND owner_id = ?",
      variables: [Variable.withString(toId), Variable.withInt(now), Variable.withString(oldId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  Future<void> _unlink(String entryId) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE loan_installments SET paid_entry_id = NULL, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE paid_entry_id = ?',
      variables: [Variable.withInt(now), Variable.withString(entryId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
    await _db.customUpdate(
      'UPDATE card_statements SET entry_id = NULL, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE entry_id = ?',
      variables: [Variable.withInt(now), Variable.withString(entryId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  Future<String?> _findByKey(String key) async {
    final row = await _db.customSelect(
      'SELECT id FROM journal_entries WHERE idempotency_key = ?',
      variables: [Variable.withString(key)],
    ).getSingleOrNull();
    return row?.read<String>('id');
  }

  Future<void> _audit({
    required String businessId,
    required String recordId,
    required Map<String, Object?> before,
    required Map<String, Object?> after,
  }) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, '
      "after_json, reason, occurred_at, created_at, updated_at, device_id) "
      "VALUES (?, ?, 'journal_entries', ?, 'update', ?, ?, 'Düzeltme', ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(recordId),
        Variable.withString(jsonEncode(before)),
        Variable.withString(jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}

final entriesRepositoryProvider = Provider<EntriesRepository>((ref) => EntriesRepository(ref.watch(databaseProvider)));

final entryEditServiceProvider = Provider<EntryEditService>((ref) => EntryEditService(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(entriesRepositoryProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));
