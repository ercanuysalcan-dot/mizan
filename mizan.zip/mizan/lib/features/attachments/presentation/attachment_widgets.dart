import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../design_system/design_system.dart';
import '../application/attachments_providers.dart';
import '../data/attachments_repository.dart';

/// Galeriden ya da kameradan görüntü seçtirir (Android ve Web).
/// Görüntü küçültülüp sıkıştırılır; seçim iptal edilirse null döner.
Future<PendingAttachment?> pickImage(BuildContext context) async {
  final source = await showModalBottomSheet<ImageSource>(
    context: context,
    useSafeArea: true,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        ListTile(
          leading: const Icon(Icons.photo_library_outlined),
          title: const Text('Galeriden / ekran görüntüsü seç'),
          onTap: () => Navigator.pop(ctx, ImageSource.gallery),
        ),
        ListTile(
          leading: const Icon(Icons.photo_camera_outlined),
          title: const Text('Fotoğraf çek'),
          onTap: () => Navigator.pop(ctx, ImageSource.camera),
        ),
      ]),
    ),
  );
  if (source == null) return null;
  final XFile? file = await ImagePicker().pickImage(
    source: source,
    maxWidth: 2200,
    maxHeight: 2200,
    imageQuality: 82,
  );
  if (file == null) return null;
  final bytes = await file.readAsBytes();
  if (bytes.isEmpty) return null;
  return PendingAttachment(bytes: bytes, mimeType: file.mimeType ?? _guessMime(file.name), fileName: file.name);
}

String _guessMime(String name) {
  final n = name.toLowerCase();
  if (n.endsWith('.png')) return 'image/png';
  if (n.endsWith('.webp')) return 'image/webp';
  if (n.endsWith('.gif')) return 'image/gif';
  return 'image/jpeg';
}

/// Tam ekran görüntüleyici (yakınlaştırılabilir).
Future<void> showImageViewer(BuildContext context, Uint8List bytes) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => Dialog.fullscreen(
      backgroundColor: Colors.black,
      child: Stack(children: [
        Positioned.fill(
          child: InteractiveViewer(
            maxScale: 6,
            child: Center(child: Image.memory(bytes, fit: BoxFit.contain)),
          ),
        ),
        Positioned(
          top: Space.sm,
          right: Space.sm,
          child: SafeArea(
            child: IconButton.filledTonal(
              tooltip: 'Kapat',
              onPressed: () => Navigator.pop(ctx),
              icon: const Icon(Icons.close_rounded),
            ),
          ),
        ),
      ]),
    ),
  );
}

const double _thumb = 76;

/// Kayıtlı bir kayda bağlı ekler: küçük resimler + "Görüntü ekle".
class AttachmentStrip extends ConsumerWidget {
  const AttachmentStrip({super.key, required this.ownerTable, required this.ownerId, this.title = 'Ekler'});

  final String ownerTable;
  final String ownerId;
  final String title;

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final file = await pickImage(context);
      if (file == null) return;
      await ref.read(attachmentsRepositoryProvider).add(
            businessId: ref.read(currentBusinessProvider).id,
            ownerTable: ownerTable,
            ownerId: ownerId,
            file: file,
          );
      messenger.showSnackBar(const SnackBar(content: Text('Görüntü eklendi.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('Görüntü eklenemedi: $e')));
    }
  }

  Future<void> _remove(BuildContext context, WidgetRef ref, AttachmentInfo a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Görüntü silinsin mi?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil')),
        ],
      ),
    );
    if (ok == true) await ref.read(attachmentsRepositoryProvider).delete(a.id);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final list = ref.watch(attachmentsProvider((table: ownerTable, id: ownerId))).valueOrNull ??
        const <AttachmentInfo>[];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(title, style: context.text.labelLarge),
        Space.gapSm,
        Wrap(
          spacing: Space.sm,
          runSpacing: Space.sm,
          children: [
            for (final a in list)
              _SavedThumb(
                info: a,
                onDelete: () => _remove(context, ref, a),
              ),
            _AddTile(onTap: () => _add(context, ref)),
          ],
        ),
      ],
    );
  }
}

/// Henüz kaydedilmemiş formdaki ekler.
class PendingAttachmentStrip extends StatelessWidget {
  const PendingAttachmentStrip({
    super.key,
    required this.files,
    required this.onAdd,
    required this.onRemove,
    this.title = 'Ekler',
  });

  final List<PendingAttachment> files;
  final VoidCallback onAdd;
  final ValueChanged<int> onRemove;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(title, style: context.text.labelLarge),
        Space.gapSm,
        Wrap(
          spacing: Space.sm,
          runSpacing: Space.sm,
          children: [
            for (var i = 0; i < files.length; i++)
              _ThumbFrame(
                onTap: () => showImageViewer(context, files[i].bytes),
                onDelete: () => onRemove(i),
                child: Image.memory(files[i].bytes, fit: BoxFit.cover, cacheWidth: 240),
              ),
            _AddTile(onTap: onAdd),
          ],
        ),
      ],
    );
  }
}

class _SavedThumb extends ConsumerStatefulWidget {
  const _SavedThumb({required this.info, required this.onDelete});
  final AttachmentInfo info;
  final VoidCallback onDelete;

  @override
  ConsumerState<_SavedThumb> createState() => _SavedThumbState();
}

class _SavedThumbState extends ConsumerState<_SavedThumb> {
  late final Future<Uint8List> _bytes = ref.read(attachmentsRepositoryProvider).content(widget.info.id);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Uint8List>(
      future: _bytes,
      builder: (context, snap) {
        final data = snap.data;
        return _ThumbFrame(
          onTap: data == null ? null : () => showImageViewer(context, data),
          onDelete: widget.onDelete,
          child: data == null
              ? const Center(child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
              : Image.memory(data, fit: BoxFit.cover, cacheWidth: 240),
        );
      },
    );
  }
}

class _ThumbFrame extends StatelessWidget {
  const _ThumbFrame({required this.child, required this.onTap, required this.onDelete});
  final Widget child;
  final VoidCallback? onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _thumb,
      height: _thumb,
      child: Stack(children: [
        Positioned.fill(
          child: ClipRRect(
            borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
            child: Material(
              color: context.tokens.mutedSurface,
              child: InkWell(onTap: onTap, child: child),
            ),
          ),
        ),
        Positioned(
          top: 2,
          right: 2,
          child: InkWell(
            onTap: onDelete,
            customBorder: const CircleBorder(),
            child: Container(
              padding: const EdgeInsets.all(3),
              decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
              child: const Icon(Icons.close_rounded, size: 14, color: Colors.white),
            ),
          ),
        ),
      ]),
    );
  }
}

class _AddTile extends StatelessWidget {
  const _AddTile({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: _thumb,
      height: _thumb,
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          padding: EdgeInsets.zero,
          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(Radii.sm))),
        ),
        onPressed: onTap,
        child: const Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.add_photo_alternate_outlined, size: 22),
          SizedBox(height: 2),
          Text('Ekle', style: TextStyle(fontSize: 12)),
        ]),
      ),
    );
  }
}
