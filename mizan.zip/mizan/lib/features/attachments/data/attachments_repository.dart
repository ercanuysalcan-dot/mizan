import 'dart:typed_data';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';

/// Eklerin bağlanabildiği kayıt türleri.
abstract final class AttachmentOwner {
  static const statement = 'card_statements';
  static const entry = 'journal_entries';
}

class AttachmentInfo {
  const AttachmentInfo({
    required this.id,
    required this.mimeType,
    required this.fileName,
    required this.sizeBytes,
    required this.createdAt,
  });

  final String id;
  final String mimeType;
  final String? fileName;
  final int sizeBytes;
  final DateTime createdAt;

  bool get isImage => mimeType.startsWith('image/');
}

/// Seçilmiş ama henüz kaydedilmemiş görüntü.
class PendingAttachment {
  const PendingAttachment({required this.bytes, required this.mimeType, this.fileName});
  final Uint8List bytes;
  final String mimeType;
  final String? fileName;
}

/// Fotoğraf / ekran görüntüsü ekleri (veritabanında saklanır).
class AttachmentsRepository {
  AttachmentsRepository(this._db, {required this.deviceId, Clock clock = const Clock()}) : _clock = clock;

  final AppDatabase _db;
  final String deviceId;
  final Clock _clock;

  /// Tek ek için üst sınır (sıkıştırılmış görüntü).
  static const maxBytes = 8 * 1024 * 1024;

  Future<String> add({
    required String businessId,
    required String ownerTable,
    required String ownerId,
    required PendingAttachment file,
  }) async {
    if (file.bytes.isEmpty) throw const AppException('ATTACHMENT', 'Dosya boş.');
    if (file.bytes.length > maxBytes) {
      throw const AppException('ATTACHMENT', 'Görüntü çok büyük (en fazla 8 MB).');
    }
    final id = newId();
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO attachments (id, business_id, owner_table, owner_id, mime_type, file_name, size_bytes, '
      'content, created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(id),
        Variable.withString(businessId),
        Variable.withString(ownerTable),
        Variable.withString(ownerId),
        Variable.withString(file.mimeType),
        Variable<String>(file.fileName),
        Variable.withInt(file.bytes.length),
        Variable.withBlob(file.bytes),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    return id;
  }

  Stream<List<AttachmentInfo>> watch(String ownerTable, String ownerId) =>
      _db.watchAll(() => list(ownerTable, ownerId));

  Future<List<AttachmentInfo>> list(String ownerTable, String ownerId) async {
    final rows = await _db.customSelect(
      'SELECT id, mime_type, file_name, size_bytes, created_at FROM attachments '
      'WHERE owner_table = ? AND owner_id = ? AND deleted_at IS NULL ORDER BY created_at',
      variables: [Variable.withString(ownerTable), Variable.withString(ownerId)],
    ).get();
    return [
      for (final r in rows)
        AttachmentInfo(
          id: r.read<String>('id'),
          mimeType: r.read<String>('mime_type'),
          fileName: r.readNullable<String>('file_name'),
          sizeBytes: r.read<int>('size_bytes'),
          createdAt: DateTime.fromMillisecondsSinceEpoch(r.read<int>('created_at')),
        ),
    ];
  }

  Future<Uint8List> content(String id) async {
    final row = await _db.customSelect(
      'SELECT content FROM attachments WHERE id = ?',
      variables: [Variable.withString(id)],
    ).getSingleOrNull();
    if (row == null) throw const AppException('ATTACHMENT', 'Ek bulunamadı.');
    return row.read<Uint8List>('content');
  }

  Future<void> delete(String id) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE attachments SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 '
      'WHERE id = ?',
      variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  Future<void> deleteAllOf(String ownerTable, String ownerId) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE attachments SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 '
      'WHERE owner_table = ? AND owner_id = ? AND deleted_at IS NULL',
      variables: [
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(ownerTable),
        Variable.withString(ownerId),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }
}
