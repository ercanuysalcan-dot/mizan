import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../data/attachments_repository.dart';

final attachmentsRepositoryProvider = Provider<AttachmentsRepository>((ref) => AttachmentsRepository(
      ref.watch(databaseProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

/// (sahip tablo, sahip kimliği) için ek listesi.
final attachmentsProvider =
    StreamProvider.autoDispose.family<List<AttachmentInfo>, ({String table, String id})>((ref, owner) {
  return ref.watch(attachmentsRepositoryProvider).watch(owner.table, owner.id);
});
