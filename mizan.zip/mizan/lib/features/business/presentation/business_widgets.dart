import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/bootstrap.dart';
import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/ids.dart';
import '../../../design_system/design_system.dart';
import '../data/business_repository.dart';

final businessRepositoryProvider = Provider<BusinessRepository>((ref) => BusinessRepository(
      ref.watch(databaseProvider),
      ref.watch(settingsRepositoryProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final businessesProvider = StreamProvider.autoDispose<List<BusinessInfo>>(
  (ref) => ref.watch(businessRepositoryProvider).watchAll(),
);

/// Seçili şirketi değiştirir ve bir sonraki açılış için hatırlar.
Future<void> switchBusiness(WidgetRef ref, BusinessInfo b) async {
  await ref.read(businessRepositoryProvider).setActive(b.id);
  ref.read(currentBusinessProvider.notifier).select(b);
}

/// Şirket seçici: listele, geç, ekle, yeniden adlandır, sil.
Future<void> showBusinessSwitcher(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => const _BusinessSwitcher(),
    );

enum _BizAction { rename, delete }

class _BusinessSwitcher extends ConsumerWidget {
  const _BusinessSwitcher();

  Future<void> _rename(BuildContext context, WidgetRef ref, BusinessInfo b) async {
    final controller = TextEditingController(text: b.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Şirketi yeniden adlandır'),
        content: TextField(controller: controller, autofocus: true, textCapitalization: TextCapitalization.words),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text), child: const Text('Kaydet')),
        ],
      ),
    );
    controller.dispose();
    if (name == null || !context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      final updated = await ref.read(businessRepositoryProvider).rename(b.id, name);
      if (ref.read(currentBusinessProvider).id == b.id) {
        ref.read(currentBusinessProvider.notifier).select(updated);
      }
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  Future<void> _delete(BuildContext context, WidgetRef ref, BusinessInfo b, List<BusinessInfo> all) async {
    final repo = ref.read(businessRepositoryProvider);
    final messenger = ScaffoldMessenger.of(context);
    final count = await repo.accountCount(b.id);
    if (!context.mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('“${b.name}” silinsin mi?'),
        content: Text(count == 0
            ? 'Bu şirkette hesap yok. Şirket listeden kaldırılır.'
            : 'Bu şirkette $count hesap ve bunlara ait tüm kayıtlar var. Şirket silinince bunlar artık '
                'görünmez. Bu adım geri alınamaz.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: ctx.tokens.expense),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Şirketi sil'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await repo.delete(b.id);
      if (ref.read(currentBusinessProvider).id == b.id) {
        final next = all.firstWhere((x) => x.id != b.id);
        await switchBusiness(ref, next);
      }
      messenger.showSnackBar(SnackBar(content: Text('“${b.name}” silindi.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current = ref.watch(currentBusinessProvider);
    final all = ref.watch(businessesProvider).valueOrNull ?? const <BusinessInfo>[];
    final canAdd = all.length < BusinessRepository.maxBusinesses;
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.lg, 0, Space.lg, Space.xl),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: Space.sm),
              child: Row(children: [
                Expanded(child: Text('Şirketler', style: context.text.headlineSmall)),
                Text('${all.length}/${BusinessRepository.maxBusinesses}', style: context.text.labelLarge),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(Space.sm, Space.xs, Space.sm, Space.md),
              child: Text(
                'Her şirketin hesapları, kategorileri, işlemleri ve raporları ayrıdır.',
                style: context.text.bodySmall,
              ),
            ),
            for (final b in all)
              ListTile(
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(Radii.sm))),
                selected: b.id == current.id,
                leading: Icon(b.id == current.id ? Icons.radio_button_checked : Icons.radio_button_unchecked),
                title: Text(b.name, style: context.text.titleSmall),
                subtitle: Text('Ana para birimi: ${b.baseCurrency.code}', style: context.text.bodySmall),
                onTap: () async {
                  await switchBusiness(ref, b);
                  if (context.mounted) Navigator.pop(context);
                },
                trailing: PopupMenuButton<_BizAction>(
                  tooltip: 'Şirket işlemleri',
                  onSelected: (a) {
                    switch (a) {
                      case _BizAction.rename:
                        _rename(context, ref, b);
                      case _BizAction.delete:
                        _delete(context, ref, b, all);
                    }
                  },
                  itemBuilder: (_) => [
                    const PopupMenuItem(value: _BizAction.rename, child: Text('Adını değiştir')),
                    if (all.length > 1) const PopupMenuItem(value: _BizAction.delete, child: Text('Sil')),
                  ],
                ),
              ),
            Space.gapMd,
            FilledButton.tonalIcon(
              onPressed: canAdd ? () => showCreateBusinessSheet(context) : null,
              icon: const Icon(Icons.add_business_outlined),
              label: Text(canAdd
                  ? 'Yeni şirket ekle'
                  : 'En fazla ${BusinessRepository.maxBusinesses} şirket açılabilir'),
            ),
          ],
        ),
      ),
    );
  }
}

Future<void> showCreateBusinessSheet(BuildContext context) => showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => const _CreateBusinessSheet(),
    );

class _CreateBusinessSheet extends ConsumerStatefulWidget {
  const _CreateBusinessSheet();

  @override
  ConsumerState<_CreateBusinessSheet> createState() => _CreateBusinessSheetState();
}

class _CreateBusinessSheetState extends ConsumerState<_CreateBusinessSheet> {
  final _name = TextEditingController();
  Currency _currency = Currency.tryLira;
  final String _key = newId();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final b = await ref
          .read(businessRepositoryProvider)
          .create(name: _name.text, baseCurrency: _currency, formKey: _key);
      await switchBusiness(ref, b);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('“${b.name}” oluşturuldu ve seçildi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Yeni şirket', style: context.text.headlineSmall),
          Space.gapLg,
          TextField(
            controller: _name,
            autofocus: true,
            textCapitalization: TextCapitalization.words,
            decoration: const InputDecoration(labelText: 'Şirket adı', hintText: 'Uysal İnşaat Ltd.'),
          ),
          Space.gapLg,
          Text('Ana para birimi', style: context.text.labelLarge),
          Space.gapSm,
          SegmentedButton<Currency>(
            showSelectedIcon: false,
            segments: [
              for (final c in Currency.values) ButtonSegment(value: c, label: Text('${c.symbol} ${c.code}')),
            ],
            selected: {_currency},
            onSelectionChanged: (s) => setState(() => _currency = s.first),
          ),
          Space.gapSm,
          Text('Genel bakış bu para biriminde açılır; hesaplar yine istenen para biriminde açılabilir.',
              style: context.text.bodySmall),
          if (_error != null) ...[
            Space.gapMd,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapXl,
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Şirketi oluştur'),
          ),
        ],
      ),
    );
  }
}

/// Seçili şirketin adı; dokununca şirket seçici açılır.
class BusinessSwitchButton extends ConsumerWidget {
  const BusinessSwitchButton({super.key, this.style});
  final TextStyle? style;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final b = ref.watch(currentBusinessProvider);
    return InkWell(
      borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
      onTap: () => showBusinessSwitcher(context),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Flexible(
            child: Text(b.name,
                style: style ?? context.text.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
          ),
          const Icon(Icons.arrow_drop_down_rounded, size: 20),
        ]),
      ),
    );
  }
}
