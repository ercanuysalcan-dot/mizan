import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../app/bootstrap.dart';
import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../settings/data/settings_repository.dart';

/// Şirketler (işletmeler). Her şirketin hesapları, kategorileri, işlemleri ve
/// raporları tamamen ayrıdır; tüm sorgular business_id ile süzülür.
class BusinessRepository {
  BusinessRepository(this._db, this._settings, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final SettingsRepository _settings;
  final String deviceId;
  final Clock _clock;

  /// Bu cihazda açılabilecek en fazla şirket sayısı.
  static const maxBusinesses = 5;

  Stream<List<BusinessInfo>> watchAll() => _db.watchAll(list);

  Future<List<BusinessInfo>> list() async {
    final rows = await _db.customSelect(
      'SELECT id, name, base_currency FROM businesses WHERE deleted_at IS NULL ORDER BY created_at',
    ).get();
    return [
      for (final r in rows)
        BusinessInfo(
          id: r.read<String>('id'),
          name: r.read<String>('name'),
          baseCurrency: Currency.fromCode(r.read<String>('base_currency')),
        ),
    ];
  }

  Future<BusinessInfo> create({required String name, required Currency baseCurrency, required String formKey}) async {
    final trimmed = _checkName(name);
    return _db.transaction(() async {
      final existing = await _byId(formKey);
      if (existing != null) return existing;
      final all = await list();
      if (all.length >= maxBusinesses) {
        throw const AppException('BUSINESS_LIMIT', 'En fazla $maxBusinesses şirket açılabilir.');
      }
      _checkUnique(all, trimmed, null);
      final now = _clock.nowMs();
      await _db.customInsert(
        'INSERT INTO businesses (id, name, base_currency, created_at, updated_at, device_id) '
        'VALUES (?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(formKey),
          Variable.withString(trimmed),
          Variable.withString(baseCurrency.code),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      await seedDefaultCategories(_db, businessId: formKey, deviceId: deviceId, nowMs: now);
      await _audit(formKey, 'insert', after: {'name': trimmed, 'currency': baseCurrency.code});
      return BusinessInfo(id: formKey, name: trimmed, baseCurrency: baseCurrency);
    });
  }

  Future<BusinessInfo> rename(String id, String name) async {
    final trimmed = _checkName(name);
    final current = await _byId(id);
    if (current == null) throw const AppException('BUSINESS', 'Şirket bulunamadı.');
    _checkUnique(await list(), trimmed, id);
    await _db.transaction(() async {
      await _db.customUpdate(
        'UPDATE businesses SET name = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
        variables: [Variable.withString(trimmed), Variable.withInt(_clock.nowMs()), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(id, 'update', before: {'name': current.name}, after: {'name': trimmed});
    });
    return BusinessInfo(id: id, name: trimmed, baseCurrency: current.baseCurrency);
  }

  /// Şirketi siler (gizler). Defter kayıtları silinmez, yalnızca şirket
  /// listeden kaldırılır. Son kalan şirket silinemez.
  Future<void> delete(String id) async {
    final all = await list();
    if (all.length <= 1) throw const AppException('BUSINESS', 'Son kalan şirket silinemez.');
    final current = all.where((b) => b.id == id).firstOrNull;
    if (current == null) throw const AppException('BUSINESS', 'Şirket bulunamadı.');
    await _db.transaction(() async {
      final now = _clock.nowMs();
      await _db.customUpdate(
        'UPDATE businesses SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(id, 'delete', before: {'name': current.name});
    });
  }

  /// Uygulama açılışında hatırlanacak şirket.
  Future<void> setActive(String id) => _settings.set(SettingsRepository.activeBusinessKey, id);

  /// Bu şirketteki hesap sayısı (silme uyarısı için).
  Future<int> accountCount(String id) async {
    final r = await _db.customSelect(
      "SELECT COUNT(*) AS n FROM accounts WHERE business_id = ? AND deleted_at IS NULL "
      "AND kind NOT IN ('gelir','gider','ozkaynak','kur_farki')",
      variables: [Variable.withString(id)],
    ).getSingle();
    return r.read<int>('n');
  }

  // ----------------------------------------------------------------------------

  Future<BusinessInfo?> _byId(String id) async {
    final r = await _db.customSelect(
      'SELECT id, name, base_currency FROM businesses WHERE id = ? AND deleted_at IS NULL',
      variables: [Variable.withString(id)],
    ).getSingleOrNull();
    if (r == null) return null;
    return BusinessInfo(
      id: r.read<String>('id'),
      name: r.read<String>('name'),
      baseCurrency: Currency.fromCode(r.read<String>('base_currency')),
    );
  }

  String _checkName(String name) {
    final t = name.trim();
    if (t.isEmpty) throw const AppException('BUSINESS', 'Şirket adı boş olamaz.');
    if (t.length > 80) throw const AppException('BUSINESS', 'Şirket adı en fazla 80 karakter olabilir.');
    return t;
  }

  /// Türkçe büyük/küçük harf: İ→i, I→ı.
  static String _fold(String s) => s.replaceAll('İ', 'i').replaceAll('I', 'ı').toLowerCase();

  void _checkUnique(List<BusinessInfo> all, String name, String? selfId) {
    final lower = _fold(name);
    if (all.any((b) => b.id != selfId && _fold(b.name) == lower)) {
      throw AppException('BUSINESS', '"$name" adlı şirket zaten var.');
    }
  }

  Future<void> _audit(String businessId, String action,
      {Map<String, Object?>? before, Map<String, Object?>? after}) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, after_json, '
      "occurred_at, created_at, updated_at, device_id) VALUES (?, ?, 'businesses', ?, ?, ?, ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(businessId),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable<String>(after == null ? null : jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}
