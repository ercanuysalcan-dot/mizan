import 'dart:convert';
import 'dart:typed_data';

/// Bağımlılıksız, küçük bir Excel (.xlsx) yazıcısı.
///
/// Dosya, Office Open XML biçiminde ve sıkıştırmasız (stored) ZIP olarak
/// üretilir; Excel, Google E-Tablolar, LibreOffice ve Numbers açar.
/// Metinler satır içi (inlineStr), tarihler Excel seri sayısı olarak yazılır.

/// Hücre stilleri (styles.xml'deki cellXfs sırası).
abstract final class XStyle {
  static const normal = 0;
  static const header = 1;
  static const money = 2;
  static const date = 3;
  static const bold = 4;
  static const moneyBold = 5;
  static const title = 6;
  static const moneyIncome = 7;
  static const moneyExpense = 8;
  static const muted = 9;
  static const dateTime = 10;
}

/// Hücre değeri: String, num, DateTime ya da [XMoney].
class XCell {
  const XCell(this.value, [this.style = XStyle.normal]);
  final Object? value;
  final int style;
}

/// Kesin ondalık tutar (kuruş tamsayısı + basamak sayısı).
class XMoney {
  const XMoney(this.minor, this.decimals);
  final int minor;
  final int decimals;

  String get text {
    if (decimals == 0) return '$minor';
    final neg = minor < 0;
    final abs = minor.abs().toString().padLeft(decimals + 1, '0');
    final whole = abs.substring(0, abs.length - decimals);
    final frac = abs.substring(abs.length - decimals);
    return '${neg ? '-' : ''}$whole.$frac';
  }
}

class XSheet {
  XSheet(this.name);

  final String name;
  final List<List<XCell?>> rows = [];
  final Map<int, double> widths = {};

  /// Bu satıra kadar (dahil) üst kısım kaydırmada sabit kalır.
  int? freezeRows;

  /// Süzgeç aralığı, örn. "A3:K120".
  String? autoFilter;
  final List<String> merges = [];

  void add(List<XCell?> cells) => rows.add(cells);
  void blank() => rows.add(const []);

  /// 1 tabanlı sütun genişliği (karakter).
  void width(int col, double w) => widths[col] = w;
}

class XlsxWorkbook {
  final List<XSheet> sheets = [];

  XSheet sheet(String name) {
    final s = XSheet(_safeSheetName(name, sheets.length + 1));
    sheets.add(s);
    return s;
  }

  Uint8List encode() {
    if (sheets.isEmpty) sheet('Sayfa1');
    final files = <String, String>{
      '[Content_Types].xml': _contentTypes(),
      '_rels/.rels': _rootRels,
      'xl/workbook.xml': _workbook(),
      'xl/_rels/workbook.xml.rels': _workbookRels(),
      'xl/styles.xml': _styles,
      for (var i = 0; i < sheets.length; i++) 'xl/worksheets/sheet${i + 1}.xml': _sheetXml(sheets[i]),
    };
    return ZipWriter.store({for (final e in files.entries) e.key: utf8.encode(e.value)});
  }

  // ---------------------------------------------------------------------------

  static String _safeSheetName(String n, int index) {
    var s = n.replaceAll(RegExp(r'[\[\]:*?/\\]'), ' ').trim();
    if (s.isEmpty) s = 'Sayfa$index';
    return s.length > 31 ? s.substring(0, 31) : s;
  }

  String _contentTypes() {
    final b = StringBuffer()
      ..write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
      ..write('<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">')
      ..write('<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>')
      ..write('<Default Extension="xml" ContentType="application/xml"/>')
      ..write('<Override PartName="/xl/workbook.xml" '
          'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>')
      ..write('<Override PartName="/xl/styles.xml" '
          'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>');
    for (var i = 0; i < sheets.length; i++) {
      b.write('<Override PartName="/xl/worksheets/sheet${i + 1}.xml" '
          'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
    }
    b.write('</Types>');
    return b.toString();
  }

  static const _rootRels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
      '<Relationship Id="rId1" '
      'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
      'Target="xl/workbook.xml"/>'
      '</Relationships>';

  String _workbook() {
    final b = StringBuffer()
      ..write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
      ..write('<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">')
      ..write('<bookViews><workbookView/></bookViews><sheets>');
    for (var i = 0; i < sheets.length; i++) {
      b.write('<sheet name="${_esc(sheets[i].name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>');
    }
    b.write('</sheets>');
    final filters = [
      for (var i = 0; i < sheets.length; i++)
        if (sheets[i].autoFilter != null) i,
    ];
    if (filters.isNotEmpty) {
      b.write('<definedNames>');
      for (final i in filters) {
        final ref = sheets[i].autoFilter!.split(':').map(_absolute).join(':');
        final quoted = sheets[i].name.replaceAll("'", "''");
        b.write('<definedName name="_xlnm._FilterDatabase" localSheetId="$i" hidden="1">'
            "${_esc("'$quoted'!$ref")}</definedName>");
      }
      b.write('</definedNames>');
    }
    b.write('</workbook>');
    return b.toString();
  }

  /// "A3" → "\$A\$3"
  static String _absolute(String cell) {
    final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(cell);
    return m == null ? cell : '\$${m.group(1)}\$${m.group(2)}';
  }

  String _workbookRels() {
    final b = StringBuffer()
      ..write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
      ..write('<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">');
    for (var i = 0; i < sheets.length; i++) {
      b.write('<Relationship Id="rId${i + 1}" '
          'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
          'Target="worksheets/sheet${i + 1}.xml"/>');
    }
    b.write('<Relationship Id="rId${sheets.length + 1}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
        'Target="styles.xml"/>');
    b.write('</Relationships>');
    return b.toString();
  }

  static const _font = '<sz val="11"/><name val="Calibri"/><family val="2"/>';

  static const _styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
      '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
      '<numFmts count="2">'
      '<numFmt numFmtId="164" formatCode="dd.mm.yyyy"/>'
      '<numFmt numFmtId="165" formatCode="dd.mm.yyyy hh:mm"/>'
      '</numFmts>'
      '<fonts count="7">'
      '<font>$_font</font>'
      '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/><family val="2"/></font>'
      '<font><b/>$_font</font>'
      '<font><b/><sz val="14"/><name val="Calibri"/><family val="2"/></font>'
      '<font><sz val="11"/><color rgb="FF15803D"/><name val="Calibri"/><family val="2"/></font>'
      '<font><sz val="11"/><color rgb="FFB91C1C"/><name val="Calibri"/><family val="2"/></font>'
      '<font><i/><sz val="10"/><color rgb="FF64748B"/><name val="Calibri"/><family val="2"/></font>'
      '</fonts>'
      '<fills count="3">'
      '<fill><patternFill patternType="none"/></fill>'
      '<fill><patternFill patternType="gray125"/></fill>'
      '<fill><patternFill patternType="solid"><fgColor rgb="FF2F6B5E"/><bgColor indexed="64"/></patternFill></fill>'
      '</fills>'
      '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
      '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
      '<cellXfs count="11">'
      '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
      '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>'
      '<xf numFmtId="4" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
      '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
      '<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
      '<xf numFmtId="4" fontId="2" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>'
      '<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
      '<xf numFmtId="4" fontId="4" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>'
      '<xf numFmtId="4" fontId="5" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>'
      '<xf numFmtId="0" fontId="6" fillId="0" borderId="0" xfId="0" applyFont="1"/>'
      '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
      '</cellXfs>'
      '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
      '</styleSheet>';

  String _sheetXml(XSheet s) {
    final b = StringBuffer()
      ..write('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>')
      ..write('<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
          'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">');
    b.write('<sheetViews><sheetView workbookViewId="0">');
    final f = s.freezeRows;
    if (f != null && f > 0) {
      b.write('<pane ySplit="$f" topLeftCell="A${f + 1}" activePane="bottomLeft" state="frozen"/>');
    }
    b.write('</sheetView></sheetViews>');
    b.write('<sheetFormatPr defaultRowHeight="15"/>');
    if (s.widths.isNotEmpty) {
      b.write('<cols>');
      final keys = s.widths.keys.toList()..sort();
      for (final c in keys) {
        b.write('<col min="$c" max="$c" width="${s.widths[c]}" customWidth="1"/>');
      }
      b.write('</cols>');
    }
    b.write('<sheetData>');
    for (var r = 0; r < s.rows.length; r++) {
      final row = s.rows[r];
      b.write('<row r="${r + 1}">');
      for (var c = 0; c < row.length; c++) {
        final cell = row[c];
        if (cell == null || cell.value == null) continue;
        final ref = '${colName(c + 1)}${r + 1}';
        final v = cell.value;
        final st = cell.style == 0 ? '' : ' s="${cell.style}"';
        if (v is String) {
          b.write('<c r="$ref" t="inlineStr"$st><is><t xml:space="preserve">${_esc(v)}</t></is></c>');
        } else if (v is XMoney) {
          b.write('<c r="$ref"$st><v>${v.text}</v></c>');
        } else if (v is DateTime) {
          b.write('<c r="$ref"$st><v>${excelSerial(v)}</v></c>');
        } else if (v is num) {
          b.write('<c r="$ref"$st><v>$v</v></c>');
        } else {
          b.write('<c r="$ref" t="inlineStr"$st><is><t xml:space="preserve">${_esc('$v')}</t></is></c>');
        }
      }
      b.write('</row>');
    }
    b.write('</sheetData>');
    if (s.autoFilter != null) b.write('<autoFilter ref="${s.autoFilter}"/>');
    if (s.merges.isNotEmpty) {
      b.write('<mergeCells count="${s.merges.length}">');
      for (final m in s.merges) {
        b.write('<mergeCell ref="$m"/>');
      }
      b.write('</mergeCells>');
    }
    b.write('<pageMargins left="0.5" right="0.5" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>');
    b.write('</worksheet>');
    return b.toString();
  }

  /// 1 → A, 27 → AA
  static String colName(int n) {
    var s = '';
    var x = n;
    while (x > 0) {
      final m = (x - 1) % 26;
      s = String.fromCharCode(65 + m) + s;
      x = (x - 1) ~/ 26;
    }
    return s;
  }

  /// Yerel tarih → Excel seri sayısı (1900 sistemi).
  static String excelSerial(DateTime d) {
    final local = DateTime.utc(d.year, d.month, d.day, d.hour, d.minute, d.second);
    final ms = local.difference(DateTime.utc(1899, 12, 30)).inMilliseconds;
    final days = ms / 86400000;
    return days == days.roundToDouble() ? days.toInt().toString() : days.toStringAsFixed(6);
  }

  static String _esc(String s) {
    final b = StringBuffer();
    for (final r in s.runes) {
      if (r == 0x26) {
        b.write('&amp;');
      } else if (r == 0x3C) {
        b.write('&lt;');
      } else if (r == 0x3E) {
        b.write('&gt;');
      } else if (r == 0x22) {
        b.write('&quot;');
      } else if (r == 0x09 || r == 0x0A || r == 0x0D || (r >= 0x20 && r != 0xFFFE && r != 0xFFFF)) {
        b.writeCharCode(r);
      }
      // XML'de geçersiz denetim karakterleri atlanır.
    }
    return b.toString();
  }
}

/// Sıkıştırmasız (stored) ZIP yazıcısı.
abstract final class ZipWriter {
  static Uint8List store(Map<String, List<int>> files) {
    final out = BytesBuilder(copy: false);
    final central = BytesBuilder(copy: false);
    var offset = 0;
    const dosTime = 0; // 00:00:00
    const dosDate = (2026 - 1980) << 9 | 1 << 5 | 1; // 01.01.2026
    for (final e in files.entries) {
      final name = utf8.encode(e.key);
      final data = e.value is Uint8List ? e.value as Uint8List : Uint8List.fromList(e.value);
      final crc = crc32(data);

      final local = ByteData(30);
      local
        ..setUint32(0, 0x04034b50, Endian.little)
        ..setUint16(4, 20, Endian.little)
        ..setUint16(6, 0x0800, Endian.little)
        ..setUint16(8, 0, Endian.little)
        ..setUint16(10, dosTime, Endian.little)
        ..setUint16(12, dosDate, Endian.little)
        ..setUint32(14, crc, Endian.little)
        ..setUint32(18, data.length, Endian.little)
        ..setUint32(22, data.length, Endian.little)
        ..setUint16(26, name.length, Endian.little)
        ..setUint16(28, 0, Endian.little);
      out
        ..add(local.buffer.asUint8List())
        ..add(name)
        ..add(data);

      final cd = ByteData(46);
      cd
        ..setUint32(0, 0x02014b50, Endian.little)
        ..setUint16(4, 20, Endian.little)
        ..setUint16(6, 20, Endian.little)
        ..setUint16(8, 0x0800, Endian.little)
        ..setUint16(10, 0, Endian.little)
        ..setUint16(12, dosTime, Endian.little)
        ..setUint16(14, dosDate, Endian.little)
        ..setUint32(16, crc, Endian.little)
        ..setUint32(20, data.length, Endian.little)
        ..setUint32(24, data.length, Endian.little)
        ..setUint16(28, name.length, Endian.little)
        ..setUint16(30, 0, Endian.little)
        ..setUint16(32, 0, Endian.little)
        ..setUint16(34, 0, Endian.little)
        ..setUint16(36, 0, Endian.little)
        ..setUint32(38, 0, Endian.little)
        ..setUint32(42, offset, Endian.little);
      central
        ..add(cd.buffer.asUint8List())
        ..add(name);
      offset += 30 + name.length + data.length;
    }
    final cdBytes = central.takeBytes();
    final end = ByteData(22);
    end
      ..setUint32(0, 0x06054b50, Endian.little)
      ..setUint16(4, 0, Endian.little)
      ..setUint16(6, 0, Endian.little)
      ..setUint16(8, files.length, Endian.little)
      ..setUint16(10, files.length, Endian.little)
      ..setUint32(12, cdBytes.length, Endian.little)
      ..setUint32(16, offset, Endian.little)
      ..setUint16(20, 0, Endian.little);
    out
      ..add(cdBytes)
      ..add(end.buffer.asUint8List());
    return out.takeBytes();
  }

  static final List<int> _table = List<int>.generate(256, (n) {
    var c = n;
    for (var k = 0; k < 8; k++) {
      c = (c & 1) != 0 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    }
    return c;
  });

  static int crc32(List<int> data) {
    var c = 0xFFFFFFFF;
    for (final b in data) {
      c = _table[(c ^ b) & 0xFF] ^ (c >>> 8);
    }
    return (c ^ 0xFFFFFFFF) & 0xFFFFFFFF;
  }
}
