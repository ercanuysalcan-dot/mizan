import 'package:flutter/material.dart';

import '../../core/errors/app_exception.dart';
import '../../design_system/design_system.dart';
import 'file_saver.dart';
import 'reports.dart';

/// "Excel / PDF olarak dışa aktar" seçimi.
Future<void> showExportSheet(
  BuildContext context, {
  required String title,
  required String subtitle,
  required Future<ExportFile> Function() excel,
  required Future<ExportFile> Function() pdf,
}) =>
    showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _ExportSheet(title: title, subtitle: subtitle, excel: excel, pdf: pdf),
    );

class _ExportSheet extends StatefulWidget {
  const _ExportSheet({required this.title, required this.subtitle, required this.excel, required this.pdf});
  final String title;
  final String subtitle;
  final Future<ExportFile> Function() excel;
  final Future<ExportFile> Function() pdf;

  @override
  State<_ExportSheet> createState() => _ExportSheetState();
}

class _ExportSheetState extends State<_ExportSheet> {
  String? _busy; // 'xlsx' | 'pdf'
  String? _error;

  Future<void> _run(String kind) async {
    setState(() {
      _busy = kind;
      _error = null;
    });
    final messenger = ScaffoldMessenger.of(context);
    try {
      final file = await (kind == 'xlsx' ? widget.excel() : widget.pdf());
      await saveBytes(file.bytes, file.name, file.mime);
      if (!mounted) return;
      Navigator.pop(context);
      messenger.showSnackBar(SnackBar(
        content: Text(savesAsDownload ? '${file.name} indirildi (İndirilenler klasörü).' : '${file.name} hazır.'),
      ));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } catch (e) {
      setState(() => _error = 'Dosya oluşturulamadı: $e');
    } finally {
      if (mounted) setState(() => _busy = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget tile(String kind, IconData icon, Color color, String name, String desc) => Card(
          margin: const EdgeInsets.only(bottom: Space.sm),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.xs),
            leading: CircleAvatar(
              backgroundColor: color.withValues(alpha: 0.12),
              child: _busy == kind
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : Icon(icon, color: color),
            ),
            title: Text(name, style: context.text.titleMedium),
            subtitle: Text(desc, style: context.text.bodySmall),
            onTap: _busy == null ? () => _run(kind) : null,
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.title, style: context.text.headlineSmall),
          Space.gapXs,
          Text(widget.subtitle, style: context.text.bodySmall),
          Space.gapLg,
          tile('xlsx', Icons.grid_on_rounded, const Color(0xFF15803D), 'Excel (.xlsx)',
              'Süzülebilir tablo, tarih ve tutar sütunları, özet sayfası'),
          tile('pdf', Icons.picture_as_pdf_outlined, const Color(0xFFB91C1C), 'PDF',
              'Yazdırmaya ve paylaşmaya hazır, şirket başlıklı rapor'),
          if (_error != null) ...[
            Space.gapSm,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapSm,
          Text(
            savesAsDownload
                ? 'Dosya telefonun İndirilenler klasörüne iner; oradan WhatsApp, e-posta ya da Drive ile paylaşabilirsin.'
                : 'Dosya hazır olunca paylaşım menüsü açılır: Drive, WhatsApp, e-posta ya da Dosyalar.',
            style: context.text.bodySmall,
          ),
        ],
      ),
    );
  }
}
