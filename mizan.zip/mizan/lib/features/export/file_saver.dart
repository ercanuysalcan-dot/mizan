/// Dosyayı kullanıcıya verir: Web'de tarayıcı indirmesi, Android'de
/// paylaşım menüsü (Drive, WhatsApp, Dosyalar'a kaydet …).
library;

export 'file_saver_io.dart' if (dart.library.js_interop) 'file_saver_web.dart';
