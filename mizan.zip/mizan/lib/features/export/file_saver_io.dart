import 'dart:typed_data';

import 'package:share_plus/share_plus.dart';

/// Android / masaüstü: paylaşım menüsünü açar.
Future<void> saveBytes(Uint8List bytes, String fileName, String mimeType) async {
  await Share.shareXFiles(
    [XFile.fromData(bytes, mimeType: mimeType, name: fileName)],
    subject: fileName,
  );
}

/// Kaydetme yöntemi (kullanıcıya gösterilecek açıklama için).
const bool savesAsDownload = false;
