import 'dart:typed_data';

import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../core/money/money.dart';
import '../../core/money/money_format.dart';
import '../../core/utils/tr_format.dart';
import '../accounting/domain/account_kind.dart';
import '../dashboard/domain/dashboard_models.dart';
import '../transactions/data/entries_repository.dart';
import '../transactions/data/transactions_query.dart';
import 'xlsx_writer.dart';

/// Kullanıcıya verilecek hazır dosya.
class ExportFile {
  const ExportFile(this.bytes, this.name, this.mime);
  final Uint8List bytes;
  final String name;
  final String mime;
}

/// Rapor başlığı bilgileri.
class ReportMeta {
  const ReportMeta({
    required this.businessName,
    required this.title,
    required this.periodLabel,
    required this.generatedAt,
  });
  final String businessName;
  final String title;
  final String periodLabel;
  final DateTime generatedAt;
}

const _xlsxMime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const _pdfMime = 'application/pdf';

/// Dosya adı: Türkçe karakterler sadeleştirilir, boşluk → _.
String exportFileName(String base, DateTime at, String ext) {
  const map = {'ç': 'c', 'Ç': 'C', 'ğ': 'g', 'Ğ': 'G', 'ı': 'i', 'İ': 'I', 'ö': 'o', 'Ö': 'O', 'ş': 's', 'Ş': 'S', 'ü': 'u', 'Ü': 'U'};
  final b = StringBuffer();
  for (final ch in base.split('')) {
    b.write(map[ch] ?? ch);
  }
  final safe = b.toString().replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_').replaceAll(RegExp(r'_+'), '_');
  final stamp = '${at.year}${TrFormat.two(at.month)}${TrFormat.two(at.day)}_${TrFormat.two(at.hour)}${TrFormat.two(at.minute)}';
  return 'Mizan_${safe}_$stamp.$ext';
}

XMoney _x(Money m) => XMoney(m.minor, m.currency.decimals);

String _flow(RecentEntry e) {
  final from = e.fromNames.join(', ');
  final to = e.toNames.join(', ');
  if (from.isEmpty) return to;
  if (to.isEmpty) return from;
  return '$from → $to';
}

// =============================================================================
// İŞLEMLER RAPORU
// =============================================================================

/// Kategori özeti satırı.
class _CatRow {
  _CatRow(this.name, this.direction, this.currency);
  final String name;
  final TxDirection direction;
  final Currency currency;
  int minor = 0;
  int count = 0;
}

List<_CatRow> _categorySummary(TxPage page) {
  final map = <String, _CatRow>{};
  for (final it in page.items) {
    if (it.direction == TxDirection.transfer) continue;
    final name = it.categoryName ?? it.entry.type.label;
    final c = it.entry.amount.currency;
    final key = '${it.direction.name}|$name|${c.code}';
    final row = map.putIfAbsent(key, () => _CatRow(name, it.direction, c));
    row
      ..minor += it.entry.amount.minor
      ..count += 1;
  }
  final list = map.values.toList()
    ..sort((a, b) {
      final d = a.direction.index.compareTo(b.direction.index);
      return d != 0 ? d : b.minor.compareTo(a.minor);
    });
  return list;
}

ExportFile transactionsXlsx(TxPage page, ReportMeta meta) {
  final wb = XlsxWorkbook();
  final s = wb.sheet('İşlemler');
  s
    ..add([XCell('${meta.businessName} — ${meta.title}', XStyle.title)])
    ..add([XCell('Dönem: ${meta.periodLabel} · Oluşturma: ${TrFormat.dateTime(meta.generatedAt)}', XStyle.muted)])
    ..add([
      for (final h in const [
        'Tarih', 'Saat', 'Yön', 'İşlem türü', 'Kategori', 'Açıklama', 'Çıkış hesabı', 'Giriş hesabı',
        'Gelir', 'Gider', 'Tutar (±)', 'Para birimi',
      ])
        XCell(h, XStyle.header),
    ]);
  s
    ..merges.add('A1:L1')
    ..merges.add('A2:L2')
    ..freezeRows = 3;
  for (final it in page.items) {
    final e = it.entry;
    final m = e.amount;
    final signed = switch (it.direction) {
      TxDirection.income => m,
      TxDirection.expense => -m,
      TxDirection.transfer => m,
    };
    s.add([
      XCell(DateTime(e.date.year, e.date.month, e.date.day), XStyle.date),
      XCell('${TrFormat.two(e.date.hour)}:${TrFormat.two(e.date.minute)}'),
      XCell(it.direction.label),
      XCell(e.type.label),
      XCell(it.categoryName ?? ''),
      XCell(e.description ?? ''),
      XCell(e.fromNames.join(', ')),
      XCell(e.toNames.join(', ')),
      it.direction == TxDirection.income ? XCell(_x(m), XStyle.moneyIncome) : null,
      it.direction == TxDirection.expense ? XCell(_x(m), XStyle.moneyExpense) : null,
      XCell(
        _x(signed),
        switch (it.direction) {
          TxDirection.income => XStyle.moneyIncome,
          TxDirection.expense => XStyle.moneyExpense,
          TxDirection.transfer => XStyle.money,
        },
      ),
      XCell(m.currency.code),
    ]);
  }
  final last = 3 + page.items.length;
  s.autoFilter = 'A3:L${last < 4 ? 4 : last}';
  const widths = [11.0, 7.0, 9.0, 15.0, 20.0, 32.0, 22.0, 22.0, 14.0, 14.0, 14.0, 9.0];
  for (var i = 0; i < widths.length; i++) {
    s.width(i + 1, widths[i]);
  }

  // Özet sayfası
  final o = wb.sheet('Özet');
  o
    ..add([XCell('${meta.businessName} — Özet', XStyle.title)])
    ..add([XCell('Dönem: ${meta.periodLabel}', XStyle.muted)])
    ..blank()
    ..add([for (final h in const ['Para birimi', 'Gelir', 'Gider', 'Net', 'İşlem sayısı']) XCell(h, XStyle.header)]);
  for (final t in page.totals) {
    o.add([
      XCell(t.currency.code, XStyle.bold),
      XCell(_x(t.income), XStyle.moneyIncome),
      XCell(_x(t.expense), XStyle.moneyExpense),
      XCell(_x(t.net), XStyle.moneyBold),
      XCell(page.items.where((i) => i.entry.amount.currency == t.currency).length),
    ]);
  }
  o
    ..blank()
    ..add([for (final h in const ['Kategori', 'Yön', 'Tutar', 'Para birimi', 'İşlem sayısı', 'Pay %']) XCell(h, XStyle.header)]);
  final cats = _categorySummary(page);
  for (final c in cats) {
    final total = c.direction == TxDirection.income
        ? page.totals.where((t) => t.currency == c.currency).fold<int>(0, (a, t) => a + t.income.minor)
        : page.totals.where((t) => t.currency == c.currency).fold<int>(0, (a, t) => a + t.expense.minor);
    o.add([
      XCell(c.name),
      XCell(c.direction.label),
      XCell(XMoney(c.minor, c.currency.decimals),
          c.direction == TxDirection.income ? XStyle.moneyIncome : XStyle.moneyExpense),
      XCell(c.currency.code),
      XCell(c.count),
      XCell(total == 0 ? 0 : double.parse((c.minor * 100 / total).toStringAsFixed(1))),
    ]);
  }
  for (final (i, w) in const [28.0, 10.0, 16.0, 12.0, 13.0, 9.0].indexed) {
    o.width(i + 1, w);
  }
  o.merges.add('A1:F1');

  return ExportFile(wb.encode(), exportFileName(meta.title, meta.generatedAt, 'xlsx'), _xlsxMime);
}

Future<ExportFile> transactionsPdf(TxPage page, ReportMeta meta) async {
  final k = await _PdfKit.load();
  final cats = _categorySummary(page);
  final doc = pw.Document(title: '${meta.businessName} — ${meta.title}', author: meta.businessName, creator: 'Mizan');
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.fromLTRB(28, 28, 28, 32),
    theme: k.theme,
    maxPages: 1000,
    header: (ctx) => k.header(meta, ctx),
    footer: (ctx) => k.footer(meta, ctx),
    build: (ctx) => [
      if (page.totals.isEmpty)
        pw.Text('${page.items.length} işlem · bu dönemde gelir/gider yok', style: k.muted)
      else
        for (final t in page.totals) ...[
          pw.Row(children: [
            k.kpi('Gelir', MoneyFormat.format(t.income), k.green),
            pw.SizedBox(width: 8),
            k.kpi('Gider', MoneyFormat.format(t.expense), k.red),
            pw.SizedBox(width: 8),
            k.kpi('Net', MoneyFormat.format(t.net), t.net.isNegative ? k.red : k.ink),
          ]),
          pw.SizedBox(height: 8),
        ],
      pw.Text('${page.items.length} işlem${page.truncated ? ' (en yeniler)' : ''}', style: k.muted),
      pw.SizedBox(height: 10),
      k.table(
        headers: const ['Tarih', 'Tür', 'Kategori / Açıklama', 'Hesap', 'Tutar'],
        widths: const {
          0: pw.FixedColumnWidth(58),
          1: pw.FixedColumnWidth(62),
          2: pw.FlexColumnWidth(3),
          3: pw.FlexColumnWidth(2.6),
          4: pw.FixedColumnWidth(78),
        },
        rightAligned: const {4},
        rows: [
          for (final it in page.items)
            _PdfRow([
              '${TrFormat.date(it.entry.date)}\n${TrFormat.two(it.entry.date.hour)}:${TrFormat.two(it.entry.date.minute)}',
              it.entry.type.label,
              it.note == null ? it.title : '${it.title}\n${it.note}',
              _flow(it.entry),
              '${switch (it.direction) {
                TxDirection.income => '+',
                TxDirection.expense => '−',
                TxDirection.transfer => '',
              }}${MoneyFormat.format(it.entry.amount)}',
            ], amountColor: switch (it.direction) {
              TxDirection.income => k.green,
              TxDirection.expense => k.red,
              TxDirection.transfer => k.ink,
            }),
        ],
      ),
      if (cats.isNotEmpty) ...[
        pw.SizedBox(height: 18),
        pw.Text('Kategori özeti', style: k.h2),
        pw.SizedBox(height: 6),
        k.table(
          headers: const ['Kategori', 'Yön', 'İşlem', 'Tutar'],
          widths: const {
            0: pw.FlexColumnWidth(3),
            1: pw.FixedColumnWidth(60),
            2: pw.FixedColumnWidth(44),
            3: pw.FixedColumnWidth(90),
          },
          rightAligned: const {2, 3},
          rows: [
            for (final c in cats)
              _PdfRow(
                [c.name, c.direction.label, '${c.count}', MoneyFormat.format(Money.fromMinor(c.minor, c.currency))],
                amountColor: c.direction == TxDirection.income ? k.green : k.red,
              ),
          ],
        ),
      ],
    ],
  ));
  return ExportFile(await doc.save(), exportFileName(meta.title, meta.generatedAt, 'pdf'), _pdfMime);
}

// =============================================================================
// HESAP EKSTRESİ
// =============================================================================

class StatementRow {
  const StatementRow(this.entry, this.change, this.balance);
  final RecentEntry entry;

  /// Hesabın normal yönünde değişim (+ artış).
  final Money change;
  final Money balance;
}

class AccountStatementData {
  AccountStatementData({
    required this.accountName,
    required this.kind,
    required this.currency,
    required this.closing,
    required List<AccountEntry> newestFirst,
  }) {
    var sum = 0;
    for (final e in newestFirst) {
      sum += e.effect.minor;
    }
    opening = Money.fromMinor(closing.minor - sum, currency);
    var running = opening.minor;
    for (final e in newestFirst.reversed) {
      running += e.effect.minor;
      rows.add(StatementRow(e.entry, e.effect, Money.fromMinor(running, currency)));
    }
  }

  final String accountName;
  final AccountKind kind;
  final Currency currency;
  final Money closing;
  late final Money opening;

  /// Eskiden yeniye.
  final List<StatementRow> rows = [];

  bool get isLiability => kind.normalSide == EntrySide.credit;
  String get inLabel => isLiability ? 'Borç artışı' : 'Giriş';
  String get outLabel => isLiability ? 'Ödeme / azalış' : 'Çıkış';
  String get balanceLabel => isLiability ? 'Kalan borç' : 'Bakiye';
}

ExportFile accountXlsx(AccountStatementData d, ReportMeta meta) {
  final wb = XlsxWorkbook();
  final s = wb.sheet('Ekstre');
  s
    ..add([XCell('${meta.businessName} — ${d.accountName} hesap ekstresi', XStyle.title)])
    ..add([XCell('${d.kind.label} · ${d.currency.code} · Oluşturma: ${TrFormat.dateTime(meta.generatedAt)}', XStyle.muted)])
    ..add([XCell('Devreden ${d.balanceLabel.toLowerCase()}', XStyle.bold), null, null, null, null, null, XCell(_x(d.opening), XStyle.moneyBold)])
    ..add([
      for (final h in ['Tarih', 'İşlem türü', 'Açıklama / kategori', 'Karşı hesap', d.inLabel, d.outLabel, d.balanceLabel])
        XCell(h, XStyle.header),
    ]);
  s
    ..merges.add('A1:G1')
    ..merges.add('A2:G2')
    ..freezeRows = 4;
  for (final r in d.rows) {
    final e = r.entry;
    s.add([
      XCell(e.date, XStyle.dateTime),
      XCell(e.type.label),
      XCell(e.title),
      XCell(_flow(e)),
      r.change.isNegative ? null : XCell(_x(r.change), d.isLiability ? XStyle.moneyExpense : XStyle.moneyIncome),
      r.change.isNegative ? XCell(_x(-r.change), d.isLiability ? XStyle.moneyIncome : XStyle.moneyExpense) : null,
      XCell(_x(r.balance), XStyle.money),
    ]);
  }
  s.add([XCell('Kapanış ${d.balanceLabel.toLowerCase()}', XStyle.bold), null, null, null, null, null, XCell(_x(d.closing), XStyle.moneyBold)]);
  s.autoFilter = 'A4:G${4 + (d.rows.isEmpty ? 1 : d.rows.length)}';
  for (final (i, w) in const [17.0, 15.0, 32.0, 30.0, 15.0, 15.0, 16.0].indexed) {
    s.width(i + 1, w);
  }
  return ExportFile(wb.encode(), exportFileName('${d.accountName}_ekstre', meta.generatedAt, 'xlsx'), _xlsxMime);
}

Future<ExportFile> accountPdf(AccountStatementData d, ReportMeta meta) async {
  final k = await _PdfKit.load();
  final doc = pw.Document(title: '${d.accountName} hesap ekstresi', author: meta.businessName, creator: 'Mizan');
  doc.addPage(pw.MultiPage(
    pageFormat: PdfPageFormat.a4,
    margin: const pw.EdgeInsets.fromLTRB(28, 28, 28, 32),
    theme: k.theme,
    maxPages: 1000,
    header: (ctx) => k.header(meta, ctx),
    footer: (ctx) => k.footer(meta, ctx),
    build: (ctx) => [
      pw.Row(children: [
        k.kpi('Devreden', MoneyFormat.format(d.opening), k.ink),
        pw.SizedBox(width: 8),
        k.kpi(d.balanceLabel, MoneyFormat.format(d.closing), d.isLiability && d.closing.isPositive ? k.red : k.ink),
        pw.SizedBox(width: 8),
        k.kpi('Hareket', '${d.rows.length}', k.ink),
      ]),
      pw.SizedBox(height: 12),
      k.table(
        headers: ['Tarih', 'Tür', 'Açıklama / karşı hesap', d.inLabel, d.outLabel, d.balanceLabel],
        widths: const {
          0: pw.FixedColumnWidth(58),
          1: pw.FixedColumnWidth(60),
          2: pw.FlexColumnWidth(3),
          3: pw.FixedColumnWidth(66),
          4: pw.FixedColumnWidth(66),
          5: pw.FixedColumnWidth(72),
        },
        rightAligned: const {3, 4, 5},
        rows: [
          for (final r in d.rows)
            _PdfRow([
              '${TrFormat.date(r.entry.date)}\n${TrFormat.two(r.entry.date.hour)}:${TrFormat.two(r.entry.date.minute)}',
              r.entry.type.label,
              '${r.entry.title}\n${_flow(r.entry)}',
              r.change.isNegative ? '' : MoneyFormat.format(r.change),
              r.change.isNegative ? MoneyFormat.format(-r.change) : '',
              MoneyFormat.format(r.balance),
            ]),
        ],
      ),
    ],
  ));
  return ExportFile(
      await doc.save(), exportFileName('${d.accountName}_ekstre', meta.generatedAt, 'pdf'), _pdfMime);
}

// =============================================================================
// PDF ortak parçaları
// =============================================================================

class _PdfRow {
  const _PdfRow(this.cells, {this.amountColor});
  final List<String> cells;
  final PdfColor? amountColor;
}

class _PdfKit {
  _PdfKit(this.base, this.bold);

  final pw.Font base;
  final pw.Font bold;

  static _PdfKit? _cache;

  static Future<_PdfKit> load() async {
    final cached = _cache;
    if (cached != null) return cached;
    final regular = await rootBundle.load('assets/fonts/Roboto-Regular.ttf');
    final boldData = await rootBundle.load('assets/fonts/Roboto-Bold.ttf');
    return _cache = _PdfKit(pw.Font.ttf(regular), pw.Font.ttf(boldData));
  }

  final brand = PdfColor.fromInt(0xFF2F6B5E);
  final ink = PdfColor.fromInt(0xFF101418);
  final grey = PdfColor.fromInt(0xFF64748B);
  final line = PdfColor.fromInt(0xFFE2E8F0);
  final zebra = PdfColor.fromInt(0xFFF6F8FA);
  final green = PdfColor.fromInt(0xFF15803D);
  final red = PdfColor.fromInt(0xFFB91C1C);

  pw.ThemeData get theme => pw.ThemeData.withFont(base: base, bold: bold);

  pw.TextStyle get muted => pw.TextStyle(fontSize: 8.5, color: grey);
  pw.TextStyle get h2 => pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold, color: ink);

  pw.Widget header(ReportMeta meta, pw.Context ctx) => pw.Container(
        margin: const pw.EdgeInsets.only(bottom: 14),
        padding: const pw.EdgeInsets.only(bottom: 8),
        decoration: pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: brand, width: 1.5))),
        child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
          pw.Expanded(
            child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text(meta.businessName, style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: ink)),
              pw.SizedBox(height: 2),
              pw.Text(meta.title, style: pw.TextStyle(fontSize: 11, color: brand)),
            ]),
          ),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
            pw.Text(meta.periodLabel, style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold, color: ink)),
            pw.Text('Oluşturma: ${TrFormat.dateTime(meta.generatedAt)}', style: muted),
          ]),
        ]),
      );

  pw.Widget footer(ReportMeta meta, pw.Context ctx) => pw.Container(
        margin: const pw.EdgeInsets.only(top: 10),
        child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Text('Mizan · ${meta.businessName}', style: muted),
          pw.Text('Sayfa ${ctx.pageNumber} / ${ctx.pagesCount}', style: muted),
        ]),
      );

  pw.Widget kpi(String label, String value, PdfColor color) => pw.Expanded(
        child: pw.Container(
          padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: pw.BoxDecoration(
            color: zebra,
            borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
          ),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text(label.toUpperCase(), style: pw.TextStyle(fontSize: 7.5, color: grey)),
            pw.SizedBox(height: 2),
            pw.Text(value, style: pw.TextStyle(fontSize: 12.5, fontWeight: pw.FontWeight.bold, color: color)),
          ]),
        ),
      );

  pw.Widget table({
    required List<String> headers,
    required Map<int, pw.TableColumnWidth> widths,
    required Set<int> rightAligned,
    required List<_PdfRow> rows,
  }) {
    final last = headers.length - 1;
    pw.Widget cell(String text, int col, {bool head = false, PdfColor? color}) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          child: pw.Text(
            text,
            textAlign: rightAligned.contains(col) ? pw.TextAlign.right : pw.TextAlign.left,
            style: head
                ? pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.white)
                : pw.TextStyle(
                    fontSize: 8,
                    color: col == last ? (color ?? ink) : ink,
                    fontWeight: col == last ? pw.FontWeight.bold : pw.FontWeight.normal,
                  ),
          ),
        );
    return pw.Table(
      columnWidths: widths,
      border: pw.TableBorder(horizontalInside: pw.BorderSide(color: line, width: 0.5)),
      children: [
        pw.TableRow(
          decoration: pw.BoxDecoration(color: brand),
          children: [for (var i = 0; i < headers.length; i++) cell(headers[i], i, head: true)],
        ),
        for (var r = 0; r < rows.length; r++)
          pw.TableRow(
            decoration: r.isOdd ? pw.BoxDecoration(color: zebra) : null,
            children: [
              for (var i = 0; i < rows[r].cells.length; i++) cell(rows[r].cells[i], i, color: rows[r].amountColor),
            ],
          ),
      ],
    );
  }
}
