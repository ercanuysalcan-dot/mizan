import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounting/domain/posting_rules.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../attachments/data/attachments_repository.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../../transactions/data/entries_repository.dart';

class CardStatement {
  const CardStatement({
    required this.id,
    required this.cardAccountId,
    required this.statementDate,
    required this.dueDate,
    required this.amount,
    required this.minPayment,
    required this.entryId,
    required this.note,
    required this.attachmentCount,
  });

  final String id;
  final String cardAccountId;
  final DateTime statementDate;
  final DateTime? dueDate;
  final Money amount;
  final Money? minPayment;

  /// Doluysa ekstre tutarı kart borcuna da işlenmiştir.
  final String? entryId;
  final String? note;
  final int attachmentCount;

  bool get addedToDebt => entryId != null;
}

/// Kredi kartı dönem borcu (ekstre) kayıtları ve ekleri.
class CardStatementsRepository {
  CardStatementsRepository(
    this._db,
    this._ledger,
    this._accounts,
    this._entries,
    this._edit,
    this._attachments, {
    required this.deviceId,
    Clock clock = const Clock(),
  }) : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final AccountsRepository _accounts;
  final EntriesRepository _entries;
  final EntryEditService _edit;
  final AttachmentsRepository _attachments;
  final String deviceId;
  final Clock _clock;

  Stream<List<CardStatement>> watch(String cardAccountId) => _db.watchAll(() => list(cardAccountId));

  Future<List<CardStatement>> list(String cardAccountId) async {
    final card = await _ledger.account(cardAccountId);
    final rows = await _db.customSelect(
      '''
      SELECT s.id, s.statement_date, s.due_date, s.amount_minor, s.min_payment_minor, s.entry_id, s.note,
        (SELECT COUNT(*) FROM attachments a
          WHERE a.owner_table = 'card_statements' AND a.owner_id = s.id AND a.deleted_at IS NULL) AS files
      FROM card_statements s
      WHERE s.card_account_id = ? AND s.deleted_at IS NULL
      ORDER BY s.statement_date DESC, s.created_at DESC
      ''',
      variables: [Variable.withString(cardAccountId)],
    ).get();
    return [for (final r in rows) _map(r, cardAccountId, card.currency)];
  }

  Future<CardStatement?> byId(String id) async {
    final r = await _db.customSelect(
      '''
      SELECT s.id, s.card_account_id, s.statement_date, s.due_date, s.amount_minor, s.min_payment_minor,
        s.entry_id, s.note,
        (SELECT COUNT(*) FROM attachments a
          WHERE a.owner_table = 'card_statements' AND a.owner_id = s.id AND a.deleted_at IS NULL) AS files
      FROM card_statements s WHERE s.id = ? AND s.deleted_at IS NULL
      ''',
      variables: [Variable.withString(id)],
    ).getSingleOrNull();
    if (r == null) return null;
    final cardId = r.read<String>('card_account_id');
    final card = await _ledger.account(cardId);
    return _map(r, cardId, card.currency);
  }

  /// Ekstre kaydının kart borcuna işlenmiş kategorisi (düzenleme formu için).
  Future<String?> categoryOf(CardStatement s) async {
    if (s.entryId == null) return null;
    final d = await _entries.detail(s.entryId!);
    final i = d?.categoryLineIndex;
    return i == null ? null : d!.lines[i].categoryId;
  }

  /// Yeni ekstre. [addToDebt] ise tutar kart borcuna gider olarak işlenir
  /// (D gider kategorisi / C kart). Harcamaları tek tek giriyorsanız kapalı
  /// bırakın, yoksa aynı harcama iki kez borca eklenir.
  Future<String> add({
    required String businessId,
    required String cardAccountId,
    required DateTime statementDate,
    DateTime? dueDate,
    required String amountText,
    String? minPaymentText,
    String? note,
    required bool addToDebt,
    String? categoryId,
    List<PendingAttachment> files = const [],
    required String formKey,
  }) async {
    final card = await _ledger.account(cardAccountId);
    if (card.kind != AccountKind.krediKarti) {
      throw const AppException('CARD', 'Dönem borcu yalnızca kredi kartına girilebilir.');
    }
    final amount = _parse(amountText, card.currency, allowZero: !addToDebt);
    final minPay = _parseOptional(minPaymentText, card.currency);
    if (addToDebt && categoryId == null) throw const AppException('CATEGORY', 'Gider kategorisi seçin.');

    return _db.transaction(() async {
      final exists = await _db.customSelect(
        'SELECT 1 FROM card_statements WHERE id = ?',
        variables: [Variable.withString(formKey)],
      ).getSingleOrNull();
      if (exists != null) return formKey;

      String? entryId;
      if (addToDebt) {
        entryId = await _postDebt(card, categoryId!, amount, statementDate, 'ekstre:$formKey');
      }
      final now = _clock.nowMs();
      await _db.customInsert(
        'INSERT INTO card_statements (id, business_id, card_account_id, statement_date, due_date, amount_minor, '
        'min_payment_minor, entry_id, note, created_at, updated_at, device_id) '
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(formKey),
          Variable.withString(businessId),
          Variable.withString(cardAccountId),
          Variable.withInt(_ms(statementDate)),
          Variable<int>(dueDate == null ? null : _ms(dueDate)),
          Variable.withInt(amount.minor),
          Variable<int>(minPay?.minor),
          Variable<String>(entryId),
          Variable<String>(_clean(note)),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      for (final f in files) {
        await _attachments.add(
          businessId: businessId,
          ownerTable: AttachmentOwner.statement,
          ownerId: formKey,
          file: f,
        );
      }
      await _audit(businessId, formKey, 'insert', after: {
        'card': cardAccountId,
        'amount_minor': amount.minor,
        'date_ms': _ms(statementDate),
        'added_to_debt': addToDebt,
      });
      return formKey;
    });
  }

  /// Ekstreyi düzeltir. Borca işlenmişse kart borcu da "iptal + yeni kayıt"
  /// ile düzeltilir.
  Future<void> update({
    required String id,
    required DateTime statementDate,
    DateTime? dueDate,
    required String amountText,
    String? minPaymentText,
    String? note,
    required bool addToDebt,
    String? categoryId,
    required String editKey,
  }) async {
    final s = await byId(id);
    if (s == null) throw const AppException('CARD', 'Ekstre bulunamadı.');
    final card = await _ledger.account(s.cardAccountId);
    final amount = _parse(amountText, card.currency, allowZero: !addToDebt);
    final minPay = _parseOptional(minPaymentText, card.currency);
    if (addToDebt && categoryId == null) throw const AppException('CATEGORY', 'Gider kategorisi seçin.');

    await _db.transaction(() async {
      var entryId = s.entryId;
      if (entryId != null && !addToDebt) {
        await _edit.reverse(entryId: entryId, idempotencyKey: 'ekstre-iptal:$editKey', reason: 'Ekstre borçtan çıkarıldı');
        entryId = null;
      } else if (entryId != null && addToDebt) {
        final currentCategory = await categoryOf(s);
        final changed = amount != s.amount ||
            _ms(statementDate) != _ms(s.statementDate) ||
            (categoryId != null && categoryId != currentCategory);
        if (changed) {
          entryId = await _edit.edit(
            entryId: entryId,
            editKey: 'ekstre:$editKey',
            amount: amount,
            date: DateTime(statementDate.year, statementDate.month, statementDate.day, 12),
            categoryId: categoryId,
            keepDescription: true,
          );
        }
      } else if (entryId == null && addToDebt) {
        entryId = await _postDebt(card, categoryId!, amount, statementDate, 'ekstre:$editKey');
      }

      await _db.customUpdate(
        'UPDATE card_statements SET statement_date = ?, due_date = ?, amount_minor = ?, min_payment_minor = ?, '
        'entry_id = ?, note = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
        variables: [
          Variable.withInt(_ms(statementDate)),
          Variable<int>(dueDate == null ? null : _ms(dueDate)),
          Variable.withInt(amount.minor),
          Variable<int>(minPay?.minor),
          Variable<String>(entryId),
          Variable<String>(_clean(note)),
          Variable.withInt(_clock.nowMs()),
          Variable.withString(id),
        ],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(card.businessId, id, 'update', before: {
        'amount_minor': s.amount.minor,
        'date_ms': s.statementDate.millisecondsSinceEpoch,
        'added_to_debt': s.addedToDebt,
      }, after: {
        'amount_minor': amount.minor,
        'date_ms': _ms(statementDate),
        'added_to_debt': addToDebt,
      });
    });
  }

  /// Ekstreyi siler (borca işlenmişse o kayıt iptal edilir).
  Future<void> delete({required String id, required String opKey}) async {
    final s = await byId(id);
    if (s == null) return;
    final card = await _ledger.account(s.cardAccountId);
    await _db.transaction(() async {
      if (s.entryId != null) {
        await _edit.reverse(entryId: s.entryId!, idempotencyKey: 'ekstre-sil:$opKey', reason: 'Ekstre silindi');
      }
      final now = _clock.nowMs();
      await _db.customUpdate(
        'UPDATE card_statements SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE id = ?',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _attachments.deleteAllOf(AttachmentOwner.statement, id);
      await _audit(card.businessId, id, 'delete', before: {'amount_minor': s.amount.minor});
    });
  }

  // ----------------------------------------------------------------------------

  Future<String> _postDebt(LedgerAccount card, String categoryId, Money amount, DateTime date, String key) async {
    final cat = await _accounts.ensureCategoryAccount(card.businessId, categoryId, card.currency);
    if (cat.kind != AccountKind.gider) throw const AppException('CATEGORY', 'Gider kategorisi seçin.');
    return _ledger.post(PostingRequest(
      businessId: card.businessId,
      type: EntryType.kartHarcama,
      date: DateTime(date.year, date.month, date.day, 12),
      idempotencyKey: key,
      description: '${card.name} — ${TrFormat.monthYear(date)} dönem borcu',
      lines: PostingRules.expense(paidFrom: card, expenseAccount: cat, amount: amount),
    ));
  }

  CardStatement _map(QueryRow r, String cardId, Currency c) => CardStatement(
        id: r.read<String>('id'),
        cardAccountId: cardId,
        statementDate: DateTime.fromMillisecondsSinceEpoch(r.read<int>('statement_date')),
        dueDate: r.readNullable<int>('due_date') == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(r.read<int>('due_date')),
        amount: Money.fromMinor(r.read<int>('amount_minor'), c),
        minPayment: r.readNullable<int>('min_payment_minor') == null
            ? null
            : Money.fromMinor(r.read<int>('min_payment_minor'), c),
        entryId: r.readNullable<String>('entry_id'),
        note: r.readNullable<String>('note'),
        attachmentCount: r.read<int>('files'),
      );

  Money _parse(String text, Currency c, {required bool allowZero}) {
    final Money m;
    try {
      m = Money.parse(text, c);
    } on FormatException catch (e) {
      throw AppException('AMOUNT', 'Tutar geçersiz: ${e.message}');
    }
    if (m.isNegative || (!allowZero && m.isZero)) {
      throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');
    }
    return m;
  }

  Money? _parseOptional(String? text, Currency c) {
    if (text == null || text.trim().isEmpty) return null;
    return _parse(text, c, allowZero: true);
  }

  static String? _clean(String? s) => s == null || s.trim().isEmpty ? null : s.trim();

  static int _ms(DateTime d) => DateTime(d.year, d.month, d.day, 12).millisecondsSinceEpoch;

  Future<void> _audit(String businessId, String id, String action,
      {Map<String, Object?>? before, Map<String, Object?>? after}) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, after_json, '
      "occurred_at, created_at, updated_at, device_id) VALUES (?, ?, 'card_statements', ?, ?, ?, ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(id),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable<String>(after == null ? null : jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}
