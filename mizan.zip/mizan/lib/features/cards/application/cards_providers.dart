import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../attachments/application/attachments_providers.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../data/card_statements_repository.dart';

final cardStatementsRepositoryProvider = Provider<CardStatementsRepository>((ref) => CardStatementsRepository(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(entriesRepositoryProvider),
      ref.watch(entryEditServiceProvider),
      ref.watch(attachmentsRepositoryProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final cardStatementsProvider = StreamProvider.autoDispose.family<List<CardStatement>, String>((ref, cardId) {
  return ref.watch(cardStatementsRepositoryProvider).watch(cardId);
});
