import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../attachments/data/attachments_repository.dart';
import '../../attachments/presentation/attachment_widgets.dart';
import '../../categories/application/categories_providers.dart';
import '../../transactions/application/quick_entry_service.dart';
import '../../transactions/presentation/quick_entry_sheet.dart';
import '../application/cards_providers.dart';
import '../data/card_statements_repository.dart';

/// Kart detay sayfası: Harcama / Dönem borcu / Ödeme ve ekstre arşivi.
class CardSection extends ConsumerWidget {
  const CardSection({super.key, required this.card});
  final LedgerAccount card;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statements = ref.watch(cardStatementsProvider(card.id));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(children: [
          Expanded(
            child: _ActionButton(
              icon: Icons.shopping_bag_outlined,
              label: 'Harcama',
              onTap: () => showQuickEntrySheet(context, initial: QuickEntryKind.expense, sourceId: card.id),
            ),
          ),
          Space.gapSm,
          Expanded(
            child: _ActionButton(
              icon: Icons.receipt_long_outlined,
              label: 'Dönem borcu',
              onTap: () => showStatementSheet(context, card: card),
            ),
          ),
          Space.gapSm,
          Expanded(
            child: _ActionButton(
              icon: Icons.payments_outlined,
              label: 'Ödeme',
              onTap: () => showQuickEntrySheet(context, initial: QuickEntryKind.transfer, targetId: card.id),
            ),
          ),
        ]),
        Space.gapLg,
        const SectionHeader('Ekstreler (dönem borçları)'),
        statements.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Text('Ekstreler yüklenemedi: $e'),
          data: (list) => list.isEmpty
              ? MizanCard(
                  child: EmptyState(
                    compact: true,
                    icon: Icons.receipt_long_outlined,
                    title: 'Henüz ekstre yok',
                    message: 'Dönem borcunu ve ekstrenin ekran görüntüsünü ekle; geçmiş ekstreler burada saklanır.',
                    action: FilledButton.tonal(
                      onPressed: () => showStatementSheet(context, card: card),
                      child: const Text('Dönem borcu ekle'),
                    ),
                  ),
                )
              : MizanCard(
                  padding: const EdgeInsets.symmetric(vertical: Space.xs),
                  child: Column(children: [
                    for (var i = 0; i < list.length; i++) ...[
                      if (i > 0) const Divider(height: 1),
                      _StatementTile(card: card, s: list[i]),
                    ],
                  ]),
                ),
        ),
      ],
    );
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FilledButton.tonal(
      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: Space.md)),
      onPressed: onTap,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon),
        Space.gapXs,
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
      ]),
    );
  }
}

class _StatementTile extends StatelessWidget {
  const _StatementTile({required this.card, required this.s});
  final LedgerAccount card;
  final CardStatement s;

  @override
  Widget build(BuildContext context) {
    final parts = <String>[
      TrFormat.date(s.statementDate),
      if (s.dueDate != null) 'Son ödeme ${TrFormat.date(s.dueDate!)}',
      if (!s.addedToDebt) 'Borca eklenmedi',
    ];
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg),
      leading: Icon(s.attachmentCount > 0 ? Icons.image_outlined : Icons.receipt_long_outlined,
          color: context.colors.secondary),
      title: Text('${TrFormat.monthYear(s.statementDate)} ekstresi', style: context.text.titleSmall),
      subtitle: Text(
        parts.join(' · ') + (s.attachmentCount > 0 ? ' · ${s.attachmentCount} görüntü' : ''),
        style: context.text.bodySmall,
      ),
      trailing: MoneyText(s.amount, style: context.text.titleSmall, animate: false),
      onTap: () => showStatementSheet(context, card: card, existing: s),
    );
  }
}

Future<void> showStatementSheet(BuildContext context, {required LedgerAccount card, CardStatement? existing}) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 600),
      builder: (_) => _StatementSheet(card: card, existing: existing),
    );

const _defaultCardCategory = 'Kredi Kartı Harcamaları';

class _StatementSheet extends ConsumerStatefulWidget {
  const _StatementSheet({required this.card, this.existing});
  final LedgerAccount card;
  final CardStatement? existing;

  @override
  ConsumerState<_StatementSheet> createState() => _StatementSheetState();
}

class _StatementSheetState extends ConsumerState<_StatementSheet> {
  late final CardStatement? _s = widget.existing;
  late DateTime _date = _s?.statementDate ?? ref.read(clockProvider).now();
  late DateTime? _due = _s?.dueDate;
  late final _amount =
      TextEditingController(text: _s == null ? '' : MoneyFormat.format(_s!.amount, symbol: false));
  late final _minPay = TextEditingController(
      text: _s?.minPayment == null ? '' : MoneyFormat.format(_s!.minPayment!, symbol: false));
  late final _note = TextEditingController(text: _s?.note ?? '');
  late bool _addToDebt = _s?.addedToDebt ?? true;
  String? _categoryId;
  final List<PendingAttachment> _files = [];
  final String _key = newId();
  bool _busy = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadCategory();
  }

  Future<void> _loadCategory() async {
    final s = widget.existing;
    String? id;
    if (s != null && s.entryId != null) {
      id = await ref.read(cardStatementsRepositoryProvider).categoryOf(s);
    }
    id ??= await ref
        .read(categoriesRepositoryProvider)
        .ensureByName(ref.read(currentBusinessProvider).id, 'gider', _defaultCardCategory);
    if (mounted) setState(() => _categoryId = id);
  }

  @override
  void dispose() {
    _amount.dispose();
    _minPay.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _addFile() async {
    try {
      final f = await pickImage(context);
      if (f != null && mounted) setState(() => _files.add(f));
    } catch (e) {
      if (mounted) setState(() => _error = 'Görüntü seçilemedi: $e');
    }
  }

  Future<DateTime?> _pick(DateTime initial) => showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(2000),
        lastDate: DateTime(initial.year + 5),
      );

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = ref.read(cardStatementsRepositoryProvider);
    try {
      if (_s == null) {
        await repo.add(
          businessId: ref.read(currentBusinessProvider).id,
          cardAccountId: widget.card.id,
          statementDate: _date,
          dueDate: _due,
          amountText: _amount.text,
          minPaymentText: _minPay.text,
          note: _note.text,
          addToDebt: _addToDebt,
          categoryId: _categoryId,
          files: _files,
          formKey: _key,
        );
      } else {
        await repo.update(
          id: _s!.id,
          statementDate: _date,
          dueDate: _due,
          amountText: _amount.text,
          minPaymentText: _minPay.text,
          note: _note.text,
          addToDebt: _addToDebt,
          categoryId: _categoryId,
          editKey: _key,
        );
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_s == null ? 'Dönem borcu kaydedildi.' : 'Ekstre güncellendi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ekstre silinsin mi?'),
        content: Text(_s!.addedToDebt
            ? 'Ekstre ve görüntüleri silinir; kart borcuna eklenen tutar ters kayıtla geri alınır.'
            : 'Ekstre ve görüntüleri silinir.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(cardStatementsRepositoryProvider).delete(id: _s!.id, opKey: _key);
      if (mounted) Navigator.pop(context);
      messenger.showSnackBar(const SnackBar(content: Text('Ekstre silindi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final c = widget.card.currency;
    final cats = ref.watch(categoriesProvider('gider')).valueOrNull ?? const <CategoryInfo>[];
    final amountFormatter = FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'));
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_s == null ? 'Dönem borcu (ekstre)' : 'Ekstre', style: context.text.headlineSmall),
            Space.gapXs,
            Text(widget.card.name, style: context.text.bodySmall),
            Space.gapLg,
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [amountFormatter],
              style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
              decoration: InputDecoration(labelText: 'Dönem borcu', hintText: '0,00', suffixText: c.code),
            ),
            Space.gapMd,
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    final p = await _pick(_date);
                    if (p != null) setState(() => _date = p);
                  },
                  child: Text('Ekstre: ${TrFormat.date(_date)}', overflow: TextOverflow.ellipsis),
                ),
              ),
              Space.gapSm,
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    final p = await _pick(_due ?? _date);
                    if (p != null) setState(() => _due = p);
                  },
                  onLongPress: () => setState(() => _due = null),
                  child: Text(_due == null ? 'Son ödeme: —' : 'Son ödeme: ${TrFormat.date(_due!)}',
                      overflow: TextOverflow.ellipsis),
                ),
              ),
            ]),
            Space.gapMd,
            TextField(
              controller: _minPay,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [amountFormatter],
              decoration: InputDecoration(labelText: 'Asgari ödeme (isteğe bağlı)', suffixText: c.code),
            ),
            Space.gapMd,
            TextField(
              controller: _note,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Not (isteğe bağlı)'),
            ),
            Space.gapMd,
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _addToDebt,
              onChanged: (v) => setState(() => _addToDebt = v),
              title: const Text('Kart borcuna ekle'),
              subtitle: const Text(
                  'Harcamaları tek tek giriyorsan kapat; yoksa aynı harcama borca iki kez eklenir.'),
            ),
            if (_addToDebt)
              DropdownButtonFormField<String>(
                // ignore: deprecated_member_use
                value: cats.any((x) => x.id == _categoryId) ? _categoryId : null,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Gider kategorisi'),
                items: [
                  for (final x in cats)
                    DropdownMenuItem(value: x.id, child: Text(x.displayName, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _categoryId = v),
              ),
            Space.gapLg,
            if (_s == null)
              PendingAttachmentStrip(
                title: 'Ekstre görüntüsü',
                files: _files,
                onAdd: _addFile,
                onRemove: (i) => setState(() => _files.removeAt(i)),
              )
            else
              AttachmentStrip(
                title: 'Ekstre görüntüsü',
                ownerTable: AttachmentOwner.statement,
                ownerId: _s!.id,
              ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Kaydet'),
            ),
            if (_s != null) ...[
              Space.gapSm,
              TextButton.icon(
                onPressed: _busy ? null : _delete,
                icon: Icon(Icons.delete_outline_rounded, color: context.tokens.expense),
                label: Text('Ekstreyi sil', style: TextStyle(color: context.tokens.expense)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
