import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../data/categories_repository.dart';

final categoriesRepositoryProvider = Provider<CategoriesRepository>((ref) => CategoriesRepository(
      ref.watch(databaseProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(entryEditServiceProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

/// 'gelir' / 'gider' kategorileri, kayıt sayısı ve bu ayki toplamla (canlı).
final categoryUsageProvider = StreamProvider.autoDispose.family<List<CategoryUsage>, String>((ref, type) {
  final business = ref.watch(currentBusinessProvider);
  return ref.watch(categoriesRepositoryProvider).watchUsage(business.id, type, business.baseCurrency);
});
