import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/date_range.dart';
import '../../../core/utils/ids.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../transactions/application/entry_edit_service.dart';

/// Kategori + kullanım bilgisi (yönetim ekranı için).
class CategoryUsage {
  const CategoryUsage(this.category, {required this.entryCount, required this.monthTotal});
  final CategoryInfo category;

  /// Bu kategoriye bağlı kesinleşmiş (iptal edilmemiş) kayıt sayısı.
  final int entryCount;

  /// Bu ayki toplam (işletmenin ana para biriminde).
  final Money monthTotal;
}

/// Kullanıcı kategorileri: ekleme, düzenleme, silme (kayıtları taşıyarak).
class CategoriesRepository {
  CategoriesRepository(
    this._db,
    this._accounts,
    this._edit, {
    required this.deviceId,
    Clock clock = const Clock(),
  }) : _clock = clock;

  final AppDatabase _db;
  final AccountsRepository _accounts;
  final EntryEditService _edit;
  final String deviceId;
  final Clock _clock;

  Stream<List<CategoryUsage>> watchUsage(String businessId, String type, Currency currency) =>
      _db.watchAll(() => usage(businessId, type, currency));

  Future<List<CategoryUsage>> usage(String businessId, String type, Currency currency) async {
    final cats = await _accounts.categories(businessId, type);
    final month = DateRange.forPreset(PeriodPreset.month, _clock.now());
    final rows = await _db.customSelect(
      '''
      SELECT a.category_id AS cid,
        COUNT(DISTINCT CASE WHEN e.entry_type <> 'iptal' AND e.status = 'posted' THEN e.id END) AS n,
        COALESCE(SUM(CASE WHEN l.currency = ? AND e.entry_date >= ? AND e.entry_date < ?
          THEN l.debit_minor - l.credit_minor END), 0) AS net
      FROM accounts a
      JOIN journal_lines l ON l.account_id = a.id
      JOIN journal_entries e ON e.id = l.entry_id AND e.status <> 'draft'
      WHERE a.business_id = ? AND a.category_id IS NOT NULL
      GROUP BY a.category_id
      ''',
      variables: [
        Variable.withString(currency.code),
        Variable.withInt(month.startMs),
        Variable.withInt(month.endMs),
        Variable.withString(businessId),
      ],
    ).get();
    final byId = {for (final r in rows) r.read<String>('cid'): r};
    return [
      for (final c in cats)
        () {
          final r = byId[c.id];
          final net = r?.read<int>('net') ?? 0;
          // Gider borç yönlü, gelir alacak yönlü.
          final signed = type == 'gider' ? net : -net;
          return CategoryUsage(
            c,
            entryCount: r?.read<int>('n') ?? 0,
            monthTotal: Money.fromMinor(signed, currency),
          );
        }(),
    ];
  }

  Future<String> create({
    required String businessId,
    required String type,
    required String name,
    String? parentId,
    String? icon,
    int? color,
  }) async {
    if (type != 'gelir' && type != 'gider') throw const AppException('CATEGORY', 'Geçersiz kategori türü.');
    final trimmed = _checkName(name);
    await _checkParent(businessId, type, parentId, null);
    await _checkDuplicate(businessId, type, trimmed, parentId, null);
    final id = newId();
    final now = _clock.nowMs();
    final order = await _db.customSelect(
      'SELECT COALESCE(MAX(sort_order), 0) + 1 AS n FROM categories WHERE business_id = ?',
      variables: [Variable.withString(businessId)],
    ).getSingle();
    await _db.transaction(() async {
      await _db.customInsert(
        'INSERT INTO categories (id, business_id, category_type, name, parent_id, color, icon, sort_order, '
        'created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(id),
          Variable.withString(businessId),
          Variable.withString(type),
          Variable.withString(trimmed),
          Variable<String>(parentId),
          Variable<int>(color),
          Variable<String>(icon),
          Variable.withInt(order.read<int>('n')),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      await _audit(businessId, id, 'insert', after: {'type': type, 'name': trimmed, 'parent': parentId});
    });
    return id;
  }

  /// Ad, üst kategori, ikon ve rengi günceller. Ad değişince defterdeki
  /// kategori hesaplarının adı da güncellenir; eski kayıtlar yeni adla görünür.
  Future<void> update({
    required String id,
    required String name,
    String? parentId,
    String? icon,
    int? color,
  }) async {
    final current = await _load(id);
    final businessId = current.read<String>('business_id');
    final type = current.read<String>('category_type');
    final trimmed = _checkName(name);
    await _checkParent(businessId, type, parentId, id);
    await _checkDuplicate(businessId, type, trimmed, parentId, id);
    final now = _clock.nowMs();
    await _db.transaction(() async {
      await _db.customUpdate(
        'UPDATE categories SET name = ?, parent_id = ?, icon = ?, color = ?, updated_at = ?, '
        'sync_status = 0, version = version + 1 WHERE id = ?',
        variables: [
          Variable.withString(trimmed),
          Variable<String>(parentId),
          Variable<String>(icon),
          Variable<int>(color),
          Variable.withInt(now),
          Variable.withString(id),
        ],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _db.customUpdate(
        'UPDATE accounts SET name = ?, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE category_id = ?',
        variables: [Variable.withString(trimmed), Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(businessId, id, 'update',
          before: {'name': current.read<String>('name'), 'parent': current.readNullable<String>('parent_id')},
          after: {'name': trimmed, 'parent': parentId, 'icon': icon, 'color': color});
    });
  }

  /// Kategoriyi siler. Kayıtları varsa [moveToId] zorunludur: her kayıt
  /// "iptal + yeni kayıt" ile yeni kategoriye taşınır, hiçbir kayıt
  /// kategorisiz kalmaz. Alt kategoriler ana kategori olur.
  Future<int> delete({required String id, String? moveToId, required String opKey}) async {
    final current = await _load(id);
    final businessId = current.read<String>('business_id');
    final type = current.read<String>('category_type');
    if (moveToId == id) throw const AppException('CATEGORY', 'Kayıtlar aynı kategoriye taşınamaz.');
    if (moveToId != null) {
      final target = await _load(moveToId);
      if (target.read<String>('category_type') != type) {
        throw const AppException('CATEGORY', 'Kayıtlar yalnızca aynı türdeki kategoriye taşınabilir.');
      }
    }

    return _db.transaction(() async {
      final entryRows = await _db.customSelect(
        '''
        SELECT DISTINCT e.id FROM journal_entries e
        JOIN journal_lines l ON l.entry_id = e.id
        JOIN accounts a ON a.id = l.account_id
        WHERE a.category_id = ? AND e.status = 'posted' AND e.entry_type <> 'iptal'
        ORDER BY e.entry_date
        ''',
        variables: [Variable.withString(id)],
      ).get();
      if (entryRows.isNotEmpty && moveToId == null) {
        throw AppException('CATEGORY_IN_USE',
            'Bu kategoride ${entryRows.length} kayıt var. Silmeden önce taşınacağı kategoriyi seçin.');
      }
      var moved = 0;
      for (final r in entryRows) {
        final entryId = r.read<String>('id');
        await _edit.edit(
          entryId: entryId,
          editKey: 'kategori-tasi:$opKey:$entryId',
          categoryId: moveToId,
          keepDescription: true,
        );
        moved++;
      }
      final now = _clock.nowMs();
      await _db.customUpdate(
        'UPDATE categories SET parent_id = NULL, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE parent_id = ?',
        variables: [Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _db.customUpdate(
        'UPDATE categories SET deleted_at = ?, archived = 1, updated_at = ?, sync_status = 0, '
        'version = version + 1 WHERE id = ?',
        variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      // Kategorinin defter hesapları: taşımadan sonra bakiyesi sıfırdır, arşivlenir.
      await _db.customUpdate(
        'UPDATE accounts SET archived = 1, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE category_id = ?',
        variables: [Variable.withInt(now), Variable.withString(id)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _audit(businessId, id, 'delete',
          before: {'name': current.read<String>('name')}, after: {'moved_to': moveToId, 'moved_entries': moved});
      return moved;
    });
  }

  /// Adı verilen gider/gelir kategorisini bulur, yoksa oluşturur.
  Future<String> ensureByName(String businessId, String type, String name) async {
    final row = await _db.customSelect(
      'SELECT id FROM categories WHERE business_id = ? AND category_type = ? AND name = ? '
      'AND deleted_at IS NULL ORDER BY archived LIMIT 1',
      variables: [Variable.withString(businessId), Variable.withString(type), Variable.withString(name)],
    ).getSingleOrNull();
    if (row != null) return row.read<String>('id');
    return create(businessId: businessId, type: type, name: name);
  }

  // ----------------------------------------------------------------------------

  String _checkName(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) throw const AppException('CATEGORY', 'Kategori adı boş olamaz.');
    if (trimmed.length > 60) throw const AppException('CATEGORY', 'Kategori adı en fazla 60 karakter olabilir.');
    return trimmed;
  }

  Future<QueryRow> _load(String id) async {
    final row = await _db.customSelect(
      'SELECT id, business_id, category_type, name, parent_id FROM categories '
      'WHERE id = ? AND deleted_at IS NULL',
      variables: [Variable.withString(id)],
    ).getSingleOrNull();
    if (row == null) throw const AppException('CATEGORY', 'Kategori bulunamadı.');
    return row;
  }

  Future<void> _checkParent(String businessId, String type, String? parentId, String? selfId) async {
    if (parentId == null) return;
    if (parentId == selfId) throw const AppException('CATEGORY', 'Kategori kendi alt kategorisi olamaz.');
    final p = await _load(parentId);
    if (p.read<String>('business_id') != businessId || p.read<String>('category_type') != type) {
      throw const AppException('CATEGORY', 'Üst kategori aynı türde olmalı.');
    }
    if (p.readNullable<String>('parent_id') != null) {
      throw const AppException('CATEGORY', 'Yalnızca bir seviye alt kategori desteklenir.');
    }
    if (selfId != null) {
      final children = await _db.customSelect(
        'SELECT 1 FROM categories WHERE parent_id = ? AND deleted_at IS NULL LIMIT 1',
        variables: [Variable.withString(selfId)],
      ).getSingleOrNull();
      if (children != null) {
        throw const AppException('CATEGORY', 'Alt kategorisi olan bir kategori başka kategorinin altına taşınamaz.');
      }
    }
  }

  Future<void> _checkDuplicate(String businessId, String type, String name, String? parentId, String? selfId) async {
    final rows = await _db.customSelect(
      'SELECT id, parent_id FROM categories WHERE business_id = ? AND category_type = ? '
      'AND lower(name) = lower(?) AND deleted_at IS NULL',
      variables: [Variable.withString(businessId), Variable.withString(type), Variable.withString(name)],
    ).get();
    for (final r in rows) {
      if (r.read<String>('id') != selfId && r.readNullable<String>('parent_id') == parentId) {
        throw AppException('CATEGORY', '"$name" adlı kategori zaten var.');
      }
    }
  }

  Future<void> _audit(String businessId, String id, String action,
      {Map<String, Object?>? before, Map<String, Object?>? after}) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, after_json, '
      "occurred_at, created_at, updated_at, device_id) VALUES (?, ?, 'categories', ?, ?, ?, ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(id),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable<String>(after == null ? null : jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}
