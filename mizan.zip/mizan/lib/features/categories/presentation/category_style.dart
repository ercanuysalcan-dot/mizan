import 'package:flutter/material.dart';

/// Kategori ikonları: veritabanında anahtar (metin) olarak saklanır.
const categoryIcons = <String, IconData>{
  'genel': Icons.label_outline_rounded,
  'market': Icons.shopping_cart_outlined,
  'yemek': Icons.restaurant_outlined,
  'kahve': Icons.local_cafe_outlined,
  'telefon': Icons.smartphone_outlined,
  'internet': Icons.wifi_rounded,
  'elektrik': Icons.bolt_outlined,
  'su': Icons.water_drop_outlined,
  'dogalgaz': Icons.local_fire_department_outlined,
  'fatura': Icons.receipt_long_outlined,
  'kira': Icons.home_outlined,
  'arac': Icons.directions_car_outlined,
  'yakit': Icons.local_gas_station_outlined,
  'ulasim': Icons.directions_bus_outlined,
  'saglik': Icons.medical_services_outlined,
  'egitim': Icons.school_outlined,
  'giyim': Icons.checkroom_outlined,
  'eglence': Icons.movie_outlined,
  'abonelik': Icons.subscriptions_outlined,
  'tatil': Icons.flight_outlined,
  'hediye': Icons.card_giftcard_outlined,
  'cocuk': Icons.child_care_outlined,
  'evcil': Icons.pets_outlined,
  'vergi': Icons.account_balance_outlined,
  'maas': Icons.badge_outlined,
  'kart': Icons.credit_card_rounded,
  'kredi': Icons.request_quote_outlined,
  'satis': Icons.storefront_outlined,
  'hizmet': Icons.handyman_outlined,
  'faiz': Icons.trending_up_rounded,
};

/// Seçilebilir kategori renkleri (ARGB).
const categoryColors = <int>[
  0xFF2F6B5E,
  0xFF3B6FB6,
  0xFF7A5AC8,
  0xFFC2410C,
  0xFFB91C1C,
  0xFFBE185D,
  0xFFB7791F,
  0xFF15803D,
  0xFF0E7490,
  0xFF475569,
];

IconData categoryIcon(String? key) => categoryIcons[key] ?? _guessIcon(key);

IconData _guessIcon(String? key) => Icons.label_outline_rounded;

/// Ada göre ikon önerisi (yeni kategori formunda).
String? suggestIconKey(String name) {
  final n = name.toLowerCase();
  const hints = <String, String>{
    'telefon': 'telefon',
    'gsm': 'telefon',
    'internet': 'internet',
    'elektrik': 'elektrik',
    'su ': 'su',
    'doğalgaz': 'dogalgaz',
    'dogalgaz': 'dogalgaz',
    'fatura': 'fatura',
    'kira': 'kira',
    'market': 'market',
    'yemek': 'yemek',
    'yakıt': 'yakit',
    'benzin': 'yakit',
    'ulaşım': 'ulasim',
    'sağlık': 'saglik',
    'eğitim': 'egitim',
    'okul': 'egitim',
    'giyim': 'giyim',
    'kart': 'kart',
    'kredi': 'kredi',
    'maaş': 'maas',
    'vergi': 'vergi',
    'satış': 'satis',
    'hizmet': 'hizmet',
    'faiz': 'faiz',
  };
  for (final e in hints.entries) {
    if (n.contains(e.key)) return e.value;
  }
  return null;
}
