import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/errors/app_exception.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../design_system/design_system.dart';
import '../../accounts/data/accounts_repository.dart';
import '../application/categories_providers.dart';
import '../data/categories_repository.dart';
import '../../../app/providers.dart';
import 'category_style.dart';

/// Gelir / gider kategorileri: ekle, düzenle, alt kategori, sil (taşıyarak).
class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Builder(builder: (context) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Kategoriler'),
            bottom: const TabBar(tabs: [Tab(text: 'Gider'), Tab(text: 'Gelir')]),
          ),
          floatingActionButton: FloatingActionButton.extended(
            heroTag: 'add-category',
            onPressed: () {
              final type = DefaultTabController.of(context).index == 0 ? 'gider' : 'gelir';
              showCategoryForm(context, type: type);
            },
            icon: const Icon(Icons.add_rounded),
            label: const Text('Kategori ekle'),
          ),
          body: const TabBarView(children: [_CategoryList(type: 'gider'), _CategoryList(type: 'gelir')]),
        );
      }),
    );
  }
}

class _CategoryList extends ConsumerWidget {
  const _CategoryList({required this.type});
  final String type;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(categoryUsageProvider(type));
    return async.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Kategoriler yüklenemedi: $e')),
      data: (items) {
        if (items.isEmpty) {
          return Center(
            child: EmptyState(
              icon: Icons.category_outlined,
              title: 'Kategori yok',
              message: 'Örneğin “Telefon” ya da “İnternet” gibi kendi kategorini ekle.',
              action: FilledButton(
                onPressed: () => showCategoryForm(context, type: type),
                child: const Text('Kategori ekle'),
              ),
            ),
          );
        }
        return Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(Space.lg, Space.md, Space.lg, 120),
              children: [
                Text(
                  'Bir kategoriye dokunarak adını, ikonunu, rengini ya da üst kategorisini değiştirebilirsin. '
                  'Tutarlar bu ayın toplamıdır.',
                  style: context.text.bodySmall,
                ),
                Space.gapMd,
                MizanCard(
                  padding: const EdgeInsets.symmetric(vertical: Space.xs),
                  child: Column(children: [
                    for (var i = 0; i < items.length; i++) ...[
                      if (i > 0) const Divider(height: 1),
                      _CategoryTile(usage: items[i], all: items),
                    ],
                  ]),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CategoryTile extends StatelessWidget {
  const _CategoryTile({required this.usage, required this.all});
  final CategoryUsage usage;
  final List<CategoryUsage> all;

  @override
  Widget build(BuildContext context) {
    final c = usage.category;
    final color = c.color == null ? context.colors.secondary : Color(c.color!);
    final isChild = c.parentId != null;
    return ListTile(
      contentPadding: EdgeInsets.only(left: isChild ? Space.xxxl : Space.lg, right: Space.lg),
      leading: CircleAvatar(
        radius: isChild ? 16 : 20,
        backgroundColor: color.withValues(alpha: 0.15),
        child: Icon(categoryIcon(c.icon), size: isChild ? 16 : 20, color: color),
      ),
      title: Text(c.name, style: context.text.titleSmall),
      subtitle: Text(
        usage.entryCount == 0 ? 'Kayıt yok' : '${usage.entryCount} kayıt',
        style: context.text.bodySmall,
      ),
      trailing: usage.monthTotal.isZero
          ? null
          : Text(MoneyFormat.format(usage.monthTotal),
              style: context.text.titleSmall!.copyWith(fontFeatures: MizanTheme.tabular)),
      onTap: () => showCategoryForm(context, type: c.type, existing: usage, all: all),
    );
  }
}

Future<void> showCategoryForm(
  BuildContext context, {
  required String type,
  CategoryUsage? existing,
  List<CategoryUsage> all = const [],
}) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 600),
      builder: (_) => _CategoryForm(type: type, existing: existing),
    );

class _CategoryForm extends ConsumerStatefulWidget {
  const _CategoryForm({required this.type, this.existing});
  final String type;
  final CategoryUsage? existing;

  @override
  ConsumerState<_CategoryForm> createState() => _CategoryFormState();
}

class _CategoryFormState extends ConsumerState<_CategoryForm> {
  late final CategoryInfo? _c = widget.existing?.category;
  late final _name = TextEditingController(text: _c?.name ?? '');
  late String? _parentId = _c?.parentId;
  late String? _icon = _c?.icon;
  late int? _color = _c?.color;
  bool _iconTouched = false;
  bool _busy = false;
  String? _error;
  final String _opKey = newId();

  @override
  void initState() {
    super.initState();
    _iconTouched = widget.existing != null;
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = ref.read(categoriesRepositoryProvider);
    try {
      if (_c == null) {
        await repo.create(
          businessId: ref.read(currentBusinessProvider).id,
          type: widget.type,
          name: _name.text,
          parentId: _parentId,
          icon: _icon,
          color: _color,
        );
      } else {
        await repo.update(id: _c!.id, name: _name.text, parentId: _parentId, icon: _icon, color: _color);
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_c == null ? '“${_name.text.trim()}” eklendi.' : 'Kategori güncellendi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete(List<CategoryInfo> candidates) async {
    final usage = widget.existing!;
    String? moveTo;
    if (usage.entryCount > 0) {
      final targets = candidates.where((x) => x.id != _c!.id && x.parentId != _c!.id).toList();
      if (targets.isEmpty) {
        setState(() => _error = 'Kayıtların taşınabileceği başka bir kategori yok. Önce yeni bir kategori ekle.');
        return;
      }
      moveTo = await showDialog<String>(
        context: context,
        builder: (ctx) => SimpleDialog(
          title: Text('${usage.entryCount} kayıt hangi kategoriye taşınsın?'),
          children: [
            for (final t in targets)
              SimpleDialogOption(
                onPressed: () => Navigator.pop(ctx, t.id),
                child: Text(t.displayName),
              ),
          ],
        ),
      );
      if (moveTo == null) return;
    } else {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text('“${_c!.name}” silinsin mi?'),
          content: const Text('Bu kategoride kayıt yok. Alt kategorileri varsa ana kategori olur.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil')),
          ],
        ),
      );
      if (ok != true) return;
    }
    if (!mounted) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final messenger = ScaffoldMessenger.of(context);
    try {
      final moved = await ref.read(categoriesRepositoryProvider).delete(id: _c!.id, moveToId: moveTo, opKey: _opKey);
      if (mounted) Navigator.pop(context);
      messenger.showSnackBar(SnackBar(
          content: Text(moved == 0 ? 'Kategori silindi.' : 'Kategori silindi, $moved kayıt taşındı.')));
    } on AppException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final all = ref.watch(categoryUsageProvider(widget.type)).valueOrNull ?? const <CategoryUsage>[];
    final infos = [for (final u in all) u.category];
    final hasChildren = _c != null && infos.any((x) => x.parentId == _c!.id);
    final parents = infos.where((x) => x.parentId == null && x.id != _c?.id).toList();
    final color = _color == null ? context.colors.secondary : Color(_color!);

    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              _c == null ? (widget.type == 'gider' ? 'Yeni gider kategorisi' : 'Yeni gelir kategorisi') : 'Kategori',
              style: context.text.headlineSmall,
            ),
            Space.gapLg,
            TextField(
              controller: _name,
              autofocus: _c == null,
              textCapitalization: TextCapitalization.sentences,
              onChanged: (v) {
                if (_iconTouched) return;
                final s = suggestIconKey(v);
                if (s != null && s != _icon) setState(() => _icon = s);
              },
              decoration: const InputDecoration(labelText: 'Kategori adı', hintText: 'İnternet'),
            ),
            Space.gapMd,
            if (!hasChildren)
              DropdownButtonFormField<String?>(
                // ignore: deprecated_member_use
                value: parents.any((p) => p.id == _parentId) ? _parentId : null,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Üst kategori (isteğe bağlı)'),
                items: [
                  const DropdownMenuItem<String?>(value: null, child: Text('— Ana kategori —')),
                  for (final p in parents) DropdownMenuItem<String?>(value: p.id, child: Text(p.name)),
                ],
                onChanged: (v) => setState(() => _parentId = v),
              )
            else
              Text('Bu kategorinin alt kategorileri var; ana kategori olarak kalır.', style: context.text.bodySmall),
            Space.gapLg,
            Text('İkon', style: context.text.labelLarge),
            Space.gapSm,
            Wrap(
              spacing: Space.xs,
              runSpacing: Space.xs,
              children: [
                for (final e in categoryIcons.entries)
                  InkWell(
                    borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                    onTap: () => setState(() {
                      _icon = e.key;
                      _iconTouched = true;
                    }),
                    child: Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _icon == e.key ? color.withValues(alpha: 0.18) : null,
                        border: Border.all(color: _icon == e.key ? color : context.tokens.border),
                        borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                      ),
                      child: Icon(e.value, size: 20, color: _icon == e.key ? color : context.colors.onSurfaceVariant),
                    ),
                  ),
              ],
            ),
            Space.gapLg,
            Text('Renk', style: context.text.labelLarge),
            Space.gapSm,
            Wrap(
              spacing: Space.sm,
              runSpacing: Space.sm,
              children: [
                for (final c in categoryColors)
                  InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => setState(() => _color = c),
                    child: Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: Color(c),
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _color == c ? context.colors.onSurface : Colors.transparent,
                          width: 3,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text(_c == null ? 'Kategoriyi ekle' : 'Kaydet'),
            ),
            if (_c != null) ...[
              Space.gapSm,
              TextButton.icon(
                onPressed: _busy ? null : () => _delete(infos),
                icon: Icon(Icons.delete_outline_rounded, color: context.tokens.expense),
                label: Text(
                  widget.existing!.entryCount > 0
                      ? 'Sil (${widget.existing!.entryCount} kayıt başka kategoriye taşınır)'
                      : 'Kategoriyi sil',
                  style: TextStyle(color: context.tokens.expense),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
