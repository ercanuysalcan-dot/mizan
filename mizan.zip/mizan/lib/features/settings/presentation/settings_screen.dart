import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../design_system/design_system.dart';
import '../application/settings_providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(themeModeProvider).valueOrNull ?? ThemeMode.system;
    final business = ref.watch(currentBusinessProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(Space.lg, Space.sm, Space.lg, Space.xxxl),
            children: [
              const SectionHeader('Görünüm'),
              MizanCard(
                title: 'Tema',
                child: SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Sistem'), icon: Icon(Icons.brightness_auto_outlined)),
                    ButtonSegment(value: ThemeMode.light, label: Text('Açık'), icon: Icon(Icons.light_mode_outlined)),
                    ButtonSegment(value: ThemeMode.dark, label: Text('Koyu'), icon: Icon(Icons.dark_mode_outlined)),
                  ],
                  selected: {mode},
                  onSelectionChanged: (s) => setThemeMode(ref, s.first),
                ),
              ),
              Space.gapLg,
              const SectionHeader('Veri'),
              const _DemoCard(),
              Space.gapMd,
              const _IntegrityCard(),
              Space.gapLg,
              const SectionHeader('Bu cihaz'),
              MizanCard(
                child: Column(children: [
                  _InfoRow('İşletme', business.name),
                  _InfoRow('Ana para birimi', business.baseCurrency.code),
                  _InfoRow('Depolama', 'Yalnızca bu cihazda (çevrimdışı)'),
                  _InfoRow('Cihaz kimliği', ref.watch(deviceIdProvider)),
                ]),
              ),
              Space.gapLg,
              Text(
                'Bulut yedekleme, senkronizasyon, biyometrik kilit ve çoklu işletme sonraki aşamalarda '
                'bu ekrana eklenecek.',
                style: context.text.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow(this.label, this.value);
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          SizedBox(width: 140, child: Text(label, style: context.text.bodySmall)),
          Expanded(child: SelectableText(value, style: context.text.bodyMedium)),
        ]),
      );
}

class _DemoCard extends ConsumerStatefulWidget {
  const _DemoCard();
  @override
  ConsumerState<_DemoCard> createState() => _DemoCardState();
}

class _DemoCardState extends ConsumerState<_DemoCard> {
  bool _busy = false;

  Future<void> _run(bool loaded) async {
    final messenger = ScaffoldMessenger.of(context);
    if (loaded) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Örnek veriler kaldırılsın mı?'),
          content: const Text(
            'Tüm örnek işlemler ters kayıtla iptal edilir ve örnek hesaplar arşivlenir. '
            'Kendi girdiğin kayıtlar etkilenmez.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Kaldır')),
          ],
        ),
      );
      if (ok != true) return;
    }
    setState(() => _busy = true);
    try {
      final seeder = ref.read(demoSeederProvider);
      final businessId = ref.read(currentBusinessProvider).id;
      if (loaded) {
        final n = await seeder.remove(businessId);
        messenger.showSnackBar(SnackBar(content: Text('$n örnek işlem iptal edildi.')));
      } else {
        await seeder.load(businessId);
        messenger.showSnackBar(const SnackBar(content: Text('Örnek veriler yüklendi.')));
      }
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final loaded = ref.watch(demoLoadedProvider).valueOrNull ?? false;
    return MizanCard(
      title: 'Örnek veriler',
      subtitle: loaded
          ? 'Yüklü. Kaldırınca işlemler ters kayıtla iptal edilir.'
          : '6 aylık örnek işletme verisi (yalnızca hiç hesap yokken).',
      trailing: _busy
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
          : (loaded
              ? OutlinedButton(onPressed: () => _run(true), child: const Text('Kaldır'))
              : FilledButton.tonal(onPressed: () => _run(false), child: const Text('Yükle'))),
      child: const SizedBox.shrink(),
    );
  }
}

class _IntegrityCard extends ConsumerStatefulWidget {
  const _IntegrityCard();
  @override
  ConsumerState<_IntegrityCard> createState() => _IntegrityCardState();
}

class _IntegrityCardState extends ConsumerState<_IntegrityCard> {
  String? _result;
  bool _ok = true;
  bool _busy = false;

  Future<void> _check() async {
    setState(() => _busy = true);
    final issues = await ref.read(ledgerRepositoryProvider).verifyIntegrity(ref.read(currentBusinessProvider).id);
    if (!mounted) return;
    setState(() {
      _busy = false;
      _ok = issues.isEmpty;
      _result = issues.isEmpty
          ? 'Defter dengede. Tüm kayıtlarda borç = alacak.'
          : '${issues.length} sorun bulundu:\n${issues.take(5).join('\n')}';
    });
  }

  @override
  Widget build(BuildContext context) {
    return MizanCard(
      title: 'Defter bütünlüğü',
      subtitle: 'Tüm işlemleri baştan doğrular',
      trailing: _busy
          ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
          : OutlinedButton(onPressed: _check, child: const Text('Doğrula')),
      child: _result == null
          ? const SizedBox.shrink()
          : Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(_ok ? Icons.verified_outlined : Icons.warning_amber_rounded,
                  color: _ok ? context.tokens.income : context.tokens.warning, size: 20),
              Space.gapSm,
              Expanded(child: Text(_result!, style: context.text.bodyMedium)),
            ]),
    );
  }
}
