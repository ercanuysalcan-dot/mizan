import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../demo/demo_seeder.dart';
import '../data/settings_repository.dart';

final themeModeProvider = StreamProvider<ThemeMode>((ref) {
  return ref.watch(settingsRepositoryProvider).watch(SettingsRepository.themeModeKey).map(
        (v) => switch (v) {
          'light' => ThemeMode.light,
          'dark' => ThemeMode.dark,
          _ => ThemeMode.system,
        },
      );
});

Future<void> setThemeMode(WidgetRef ref, ThemeMode mode) => ref.read(settingsRepositoryProvider).set(
      SettingsRepository.themeModeKey,
      switch (mode) {
        ThemeMode.light => 'light',
        ThemeMode.dark => 'dark',
        ThemeMode.system => 'system',
      },
    );

final demoSeederProvider = Provider<DemoSeeder>((ref) => DemoSeeder(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(settingsRepositoryProvider),
      clock: ref.watch(clockProvider),
    ));

final demoLoadedProvider = StreamProvider<bool>(
  (ref) => ref.watch(settingsRepositoryProvider).watch(DemoSeeder.stateKey).map((v) => v != null),
);
