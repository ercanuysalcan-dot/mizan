import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/utils/clock.dart';

/// Yalnızca bu cihaza ait anahtar-değer ayarları (senkronlanmaz).
class SettingsRepository {
  SettingsRepository(this._db, {Clock clock = const Clock()}) : _clock = clock;

  final AppDatabase _db;
  final Clock _clock;

  static const deviceIdKey = 'device_id';
  static const themeModeKey = 'ui.theme_mode';
  static const dashboardKpisKey = 'dashboard.kpis';
  static const activeBusinessKey = 'business.active';

  Future<String?> get(String key) async {
    final row = await _db.customSelect(
      'SELECT setting_value FROM app_settings WHERE setting_key = ?',
      variables: [Variable.withString(key)],
    ).getSingleOrNull();
    return row?.read<String>('setting_value');
  }

  Future<void> set(String key, String value) async {
    await _db.customInsert(
      'INSERT INTO app_settings (setting_key, setting_value, updated_at) VALUES (?, ?, ?) '
      'ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value, '
      'updated_at = excluded.updated_at',
      variables: [Variable.withString(key), Variable.withString(value), Variable.withInt(_clock.nowMs())],
      updates: _db.everyTable,
    );
  }

  Stream<String?> watch(String key) => _db.watchAll(() => get(key)).distinct();
}
