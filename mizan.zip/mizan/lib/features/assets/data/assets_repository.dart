import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../categories/data/categories_repository.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../domain/asset_type.dart';
import '../domain/quantity.dart';

class AssetMove {
  const AssetMove({
    required this.id,
    required this.type,
    required this.quantityE8,
    required this.amount,
    required this.cost,
    required this.entryId,
    required this.date,
    required this.note,
  });

  final String id;
  final AssetMoveType type;
  final int quantityE8;

  /// Alışta ödenen, satışta alınan, eklemede verilen değer.
  final Money amount;

  /// Satış/çıkışta düşülen maliyet.
  final Money cost;
  final String? entryId;
  final DateTime date;
  final String? note;

  /// Satışta gerçekleşen kâr (−: zarar).
  Money get realized => type == AssetMoveType.satis ? amount - cost : Money.zero(amount.currency);

  /// İşlemdeki birim fiyat (alış/satış).
  Money? get unitPrice => amount.isZero
      ? null
      : Money.fromMinor(
          divideRounded(BigInt.from(amount.minor) * BigInt.from(Qty.scale), BigInt.from(quantityE8), RoundingMode.halfUp)
              .toInt(),
          amount.currency);
}

class AssetInfo {
  const AssetInfo({
    required this.account,
    required this.type,
    required this.unit,
    required this.quantityE8,
    required this.cost,
    required this.price,
    required this.priceAt,
    required this.moves,
  });

  final LedgerAccount account;
  final AssetType type;
  final String unit;

  /// Eldeki miktar.
  final int quantityE8;

  /// Defterdeki maliyet (bakiye).
  final Money cost;

  /// Elle girilen güncel birim fiyat.
  final Money? price;
  final DateTime? priceAt;

  /// Yeniden eskiye.
  final List<AssetMove> moves;

  Currency get currency => account.currency;

  /// Ortalama birim maliyet.
  Money? get averageCost => quantityE8 <= 0
      ? null
      : Money.fromMinor(
          divideRounded(BigInt.from(cost.minor) * BigInt.from(Qty.scale), BigInt.from(quantityE8), RoundingMode.halfUp)
              .toInt(),
          currency);

  /// Güncel fiyatla piyasa değeri.
  Money? get marketValue => price == null
      ? null
      : Money.fromMinor(
          divideRounded(BigInt.from(price!.minor) * BigInt.from(quantityE8), BigInt.from(Qty.scale), RoundingMode.halfUp)
              .toInt(),
          currency);

  /// Elde tutulanın kâr/zararı (piyasa değeri − maliyet).
  Money? get unrealized => marketValue == null ? null : marketValue! - cost;

  /// Satışlardan gerçekleşen toplam kâr/zarar.
  Money get realized => moves.fold(Money.zero(currency), (a, m) => a + m.realized);

  double? get unrealizedPercent =>
      unrealized == null || cost.minor == 0 ? null : unrealized!.minor * 100 / cost.minor;
}

/// Altın, gümüş, kripto, döviz gibi miktarlı birikimler.
///
/// Defter: birikim hesabının bakiyesi maliyettir.
///  * Alış  : D birikim / C kasa|banka (ödenen tutar)
///  * Satış : D kasa|banka (alınan) / C birikim (ortalama maliyet) / farkı
///            C "Varlık satış kârı" ya da D "Varlık satış zararı"
///  * Ekle  : (değer girildiyse) D birikim / C Açılış Bakiyeleri
///  * Çıkar : (maliyeti varsa) D Açılış Bakiyeleri / C birikim
class AssetsRepository {
  AssetsRepository(
    this._db,
    this._ledger,
    this._accounts,
    this._categories,
    this._edit, {
    required this.deviceId,
    Clock clock = const Clock(),
  }) : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final AccountsRepository _accounts;
  final CategoriesRepository _categories;
  final EntryEditService _edit;
  final String deviceId;
  final Clock _clock;

  static const profitCategory = 'Varlık satış kârı';
  static const lossCategory = 'Varlık satış zararı';

  Stream<AssetInfo?> watch(String accountId) => _db.watchAll(() => load(accountId));

  Future<AssetInfo?> load(String accountId) async {
    final LedgerAccount account;
    try {
      account = await _ledger.account(accountId);
    } on LedgerException {
      return null;
    }
    if (account.kind != AccountKind.birikim) return null;
    final c = account.currency;
    final d = await _db.customSelect(
      'SELECT asset_type, unit_label, price_minor, price_at FROM savings_details WHERE account_id = ?',
      variables: [Variable.withString(accountId)],
    ).getSingleOrNull();
    final rows = await _db.customSelect(
      "SELECT id, movement_type, quantity_e8, amount_minor, cost_minor, journal_entry_id, movement_date, note "
      "FROM asset_movements WHERE account_id = ? AND status = 'active' "
      'ORDER BY movement_date DESC, created_at DESC',
      variables: [Variable.withString(accountId)],
    ).get();
    final moves = [
      for (final r in rows)
        AssetMove(
          id: r.read<String>('id'),
          type: AssetMoveType.fromCode(r.read<String>('movement_type')),
          quantityE8: r.read<int>('quantity_e8'),
          amount: Money.fromMinor(r.read<int>('amount_minor'), c),
          cost: Money.fromMinor(r.read<int>('cost_minor'), c),
          entryId: r.readNullable<String>('journal_entry_id'),
          date: DateTime.fromMillisecondsSinceEpoch(r.read<int>('movement_date')),
          note: r.readNullable<String>('note'),
        ),
    ];
    var qty = 0;
    for (final m in moves) {
      qty += m.type.isIn ? m.quantityE8 : -m.quantityE8;
    }
    final balance = await _ledger.balanceOf(accountId);
    final priceMinor = d?.readNullable<int>('price_minor');
    final priceAt = d?.readNullable<int>('price_at');
    final type = AssetType.fromCode(d?.readNullable<String>('asset_type'));
    return AssetInfo(
      account: account,
      type: type,
      unit: d?.readNullable<String>('unit_label') ?? type.defaultUnit,
      quantityE8: qty,
      cost: balance.balance,
      price: priceMinor == null ? null : Money.fromMinor(priceMinor, c),
      priceAt: priceAt == null ? null : DateTime.fromMillisecondsSinceEpoch(priceAt),
      moves: moves,
    );
  }

  /// Yeni varlık hesabı (+ isteğe bağlı başlangıç miktarı ve maliyeti).
  Future<LedgerAccount> create({
    required String businessId,
    required String name,
    required AssetType type,
    required String unit,
    required Currency currency,
    String? openingQtyText,
    String? openingCostText,
    String? priceText,
    required String formKey,
  }) async {
    final qty = _optionalQty(openingQtyText);
    final openingCost = _optionalMoney(openingCostText, currency);
    final price = _optionalMoney(priceText, currency);
    return _db.transaction(() async {
      final account = await _accounts.createAccount(
        businessId: businessId,
        kind: AccountKind.birikim,
        name: name,
        currency: currency,
        formKey: formKey,
      );
      final exists = await _db.customSelect(
        'SELECT 1 FROM savings_details WHERE account_id = ?',
        variables: [Variable.withString(account.id)],
      ).getSingleOrNull();
      if (exists == null) {
        final now = _clock.nowMs();
        await _db.customInsert(
          'INSERT INTO savings_details (account_id, asset_type, unit_label, price_minor, price_at, created_at, '
          'updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
          variables: [
            Variable.withString(account.id),
            Variable.withString(type.code),
            Variable.withString(unit.trim().isEmpty ? type.defaultUnit : unit.trim()),
            Variable<int>(price?.minor),
            Variable<int>(price == null ? null : now),
            Variable.withInt(now),
            Variable.withInt(now),
            Variable.withString(deviceId),
          ],
          updates: _db.everyTable,
        );
      }
      if (qty != null) {
        await _addOrRemove(
          account: account,
          type: AssetMoveType.ekle,
          qtyE8: qty,
          value: openingCost,
          date: _clock.now(),
          note: 'Başlangıç miktarı',
          key: 'varlik-acilis:$formKey',
        );
      }
      return account;
    });
  }

  Future<void> updateDetails({
    required String accountId,
    required AssetType type,
    required String unit,
  }) async {
    final now = _clock.nowMs();
    final exists = await _db.customSelect(
      'SELECT 1 FROM savings_details WHERE account_id = ?',
      variables: [Variable.withString(accountId)],
    ).getSingleOrNull();
    if (exists == null) {
      await _db.customInsert(
        'INSERT INTO savings_details (account_id, asset_type, unit_label, created_at, updated_at, device_id) '
        'VALUES (?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(accountId),
          Variable.withString(type.code),
          Variable.withString(unit.trim().isEmpty ? type.defaultUnit : unit.trim()),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      return;
    }
    await _db.customUpdate(
      'UPDATE savings_details SET asset_type = ?, unit_label = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE account_id = ?',
      variables: [
        Variable.withString(type.code),
        Variable.withString(unit.trim().isEmpty ? type.defaultUnit : unit.trim()),
        Variable.withInt(now),
        Variable.withString(accountId),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  /// Güncel birim fiyatı kaydeder (piyasa değeri ve kâr/zarar için).
  Future<void> setPrice(String accountId, String priceText) async {
    final account = await _ledger.account(accountId);
    final price = _optionalMoney(priceText, account.currency);
    if (price == null) throw const AppException('ASSET', 'Birim fiyatı girin.');
    final info = await load(accountId);
    if (info == null) throw const AppException('ASSET', 'Bu hesap bir birikim hesabı değil.');
    final now = _clock.nowMs();
    final exists = await _db.customSelect(
      'SELECT 1 FROM savings_details WHERE account_id = ?',
      variables: [Variable.withString(accountId)],
    ).getSingleOrNull();
    if (exists == null) await updateDetails(accountId: accountId, type: info.type, unit: info.unit);
    await _db.customUpdate(
      'UPDATE savings_details SET price_minor = ?, price_at = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE account_id = ?',
      variables: [Variable.withInt(price.minor), Variable.withInt(now), Variable.withInt(now), Variable.withString(accountId)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  /// Alış: [totalText] ödenen toplam tutar, [moneyAccountId] ödemenin çıktığı hesap.
  Future<String> buy({
    required String accountId,
    required String qtyText,
    required String totalText,
    required String moneyAccountId,
    required DateTime date,
    String? note,
    required String key,
  }) async {
    final qty = _qty(qtyText);
    return _db.transaction(() async {
      final done = await _moveByKey(accountId, key);
      if (done != null) return done;
      final asset = await _ledger.account(accountId);
      final money = await _moneyAccount(moneyAccountId, asset);
      final total = _money(totalText, asset.currency);
      final entryId = await _ledger.post(PostingRequest(
        businessId: asset.businessId,
        type: EntryType.stok,
        date: date,
        idempotencyKey: 'varlik:$key',
        description: '${asset.name} alış — ${Qty.format(qty)}',
        lines: [
          PostingLine.debit(asset, total),
          PostingLine.credit(money, total),
        ],
      ));
      return _insertMove(asset, AssetMoveType.alis, qty, total.minor, 0, entryId, date, note, key);
    });
  }

  /// Satış: [totalText] alınan toplam tutar, [moneyAccountId] paranın girdiği hesap.
  Future<String> sell({
    required String accountId,
    required String qtyText,
    required String totalText,
    required String moneyAccountId,
    required DateTime date,
    String? note,
    required String key,
  }) async {
    final qty = _qty(qtyText);
    return _db.transaction(() async {
      final done = await _moveByKey(accountId, key);
      if (done != null) return done;
      final info = await load(accountId);
      if (info == null) throw const AppException('ASSET', 'Birikim hesabı bulunamadı.');
      if (qty > info.quantityE8) {
        throw AppException('ASSET', 'Elde ${Qty.format(info.quantityE8)} ${info.unit} var; daha fazlası satılamaz.');
      }
      final asset = info.account;
      final money = await _moneyAccount(moneyAccountId, asset);
      final proceeds = _money(totalText, asset.currency);
      final cost = _costPortion(info, qty);
      final lines = <PostingLine>[
        PostingLine.debit(money, proceeds),
        if (cost > 0) PostingLine.credit(asset, Money.fromMinor(cost, asset.currency)),
      ];
      final diff = proceeds.minor - cost;
      if (diff > 0) {
        final cat = await _categories.ensureByName(asset.businessId, 'gelir', profitCategory);
        final acc = await _accounts.ensureCategoryAccount(asset.businessId, cat, asset.currency);
        lines.add(PostingLine.credit(acc, Money.fromMinor(diff, asset.currency)));
      } else if (diff < 0) {
        final cat = await _categories.ensureByName(asset.businessId, 'gider', lossCategory);
        final acc = await _accounts.ensureCategoryAccount(asset.businessId, cat, asset.currency);
        lines.add(PostingLine.debit(acc, Money.fromMinor(-diff, asset.currency)));
      }
      final entryId = await _ledger.post(PostingRequest(
        businessId: asset.businessId,
        type: EntryType.stok,
        date: date,
        idempotencyKey: 'varlik:$key',
        description: '${asset.name} satış — ${Qty.format(qty)} ${info.unit}',
        lines: lines,
      ));
      return _insertMove(asset, AssetMoveType.satis, qty, proceeds.minor, cost, entryId, date, note, key);
    });
  }

  /// Parasız miktar girişi (hediye, devir, başlangıç). [valueText] verilirse maliyete eklenir.
  Future<String> add({
    required String accountId,
    required String qtyText,
    String? valueText,
    required DateTime date,
    String? note,
    required String key,
  }) async {
    final qty = _qty(qtyText);
    return _db.transaction(() async {
      final done = await _moveByKey(accountId, key);
      if (done != null) return done;
      final asset = await _ledger.account(accountId);
      return _addOrRemove(
        account: asset,
        type: AssetMoveType.ekle,
        qtyE8: qty,
        value: _optionalMoney(valueText, asset.currency),
        date: date,
        note: note,
        key: key,
      );
    });
  }

  /// Parasız miktar çıkışı (hediye, kayıp). Ortalama maliyet kadar maliyet düşülür.
  Future<String> remove({
    required String accountId,
    required String qtyText,
    required DateTime date,
    String? note,
    required String key,
  }) async {
    final qty = _qty(qtyText);
    return _db.transaction(() async {
      final done = await _moveByKey(accountId, key);
      if (done != null) return done;
      final info = await load(accountId);
      if (info == null) throw const AppException('ASSET', 'Birikim hesabı bulunamadı.');
      if (qty > info.quantityE8) {
        throw AppException('ASSET', 'Elde ${Qty.format(info.quantityE8)} ${info.unit} var.');
      }
      return _addOrRemove(
        account: info.account,
        type: AssetMoveType.cikar,
        qtyE8: qty,
        value: Money.fromMinor(_costPortion(info, qty), info.currency),
        date: date,
        note: note,
        key: key,
      );
    });
  }

  /// Hareketi geri alır (bağlı kayıt ters kayıtla iptal edilir).
  Future<void> undo(String moveId, String key) async {
    final r = await _db.customSelect(
      'SELECT journal_entry_id FROM asset_movements WHERE id = ?',
      variables: [Variable.withString(moveId)],
    ).getSingleOrNull();
    if (r == null) return;
    final entryId = r.readNullable<String>('journal_entry_id');
    await _db.transaction(() async {
      if (entryId != null) {
        // EntryEditService.reverse, hareketi de 'reversed' yapar.
        await _edit.reverse(entryId: entryId, idempotencyKey: 'varlik-geri:$key', reason: 'Varlık hareketi geri alındı');
      }
      await _db.customUpdate(
        "UPDATE asset_movements SET status = 'reversed', updated_at = ?, sync_status = 0, version = version + 1 "
        'WHERE id = ?',
        variables: [Variable.withInt(_clock.nowMs()), Variable.withString(moveId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
    });
  }

  // ---------------------------------------------------------------------------

  int _costPortion(AssetInfo info, int qty) {
    if (qty >= info.quantityE8) return info.cost.minor < 0 ? 0 : info.cost.minor;
    if (info.cost.minor <= 0 || info.quantityE8 <= 0) return 0;
    return divideRounded(BigInt.from(info.cost.minor) * BigInt.from(qty), BigInt.from(info.quantityE8),
            RoundingMode.halfUp)
        .toInt();
  }

  Future<String> _addOrRemove({
    required LedgerAccount account,
    required AssetMoveType type,
    required int qtyE8,
    Money? value,
    required DateTime date,
    String? note,
    required String key,
  }) async {
    String? entryId;
    if (value != null && value.isPositive) {
      final equity = await _accounts.ensureSystemAccount(account.businessId, 'acilis_ozkaynak', account.currency);
      entryId = await _ledger.post(PostingRequest(
        businessId: account.businessId,
        type: EntryType.stok,
        date: date,
        idempotencyKey: 'varlik:$key',
        description: '${account.name} ${type == AssetMoveType.ekle ? 'ekleme' : 'çıkış'} — ${Qty.format(qtyE8)}',
        lines: type == AssetMoveType.ekle
            ? [PostingLine.debit(account, value), PostingLine.credit(equity, value)]
            : [PostingLine.debit(equity, value), PostingLine.credit(account, value)],
      ));
    }
    return _insertMove(
      account,
      type,
      qtyE8,
      type == AssetMoveType.ekle ? (value?.minor ?? 0) : 0,
      type == AssetMoveType.cikar ? (value?.minor ?? 0) : 0,
      entryId,
      date,
      note,
      key,
    );
  }

  Future<String> _insertMove(LedgerAccount account, AssetMoveType type, int qty, int amount, int cost,
      String? entryId, DateTime date, String? note, String key) async {
    final id = newId();
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO asset_movements (id, business_id, account_id, movement_type, quantity_e8, amount_minor, cost_minor, '
      'journal_entry_id, movement_date, note, idempotency_key, created_at, updated_at, device_id) '
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(id),
        Variable.withString(account.businessId),
        Variable.withString(account.id),
        Variable.withString(type.code),
        Variable.withInt(qty),
        Variable.withInt(amount),
        Variable.withInt(cost),
        Variable<String>(entryId),
        Variable.withInt(date.millisecondsSinceEpoch),
        Variable<String>(note == null || note.trim().isEmpty ? null : note.trim()),
        Variable.withString(key),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, after_json, occurred_at, '
      "created_at, updated_at, device_id) VALUES (?, ?, 'asset_movements', ?, 'insert', ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(account.businessId),
        Variable.withString(id),
        Variable.withString(jsonEncode({'type': type.code, 'qty_e8': qty, 'amount': amount, 'cost': cost})),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
    return id;
  }

  Future<String?> _moveByKey(String accountId, String key) async {
    final r = await _db.customSelect(
      'SELECT id FROM asset_movements WHERE account_id = ? AND idempotency_key = ?',
      variables: [Variable.withString(accountId), Variable.withString(key)],
    ).getSingleOrNull();
    return r?.read<String>('id');
  }

  Future<LedgerAccount> _moneyAccount(String id, LedgerAccount asset) async {
    final m = await _ledger.account(id);
    if (m.kind != AccountKind.kasa && m.kind != AccountKind.banka) {
      throw const AppException('ASSET', 'Ödeme hesabı kasa ya da banka olmalı.');
    }
    if (m.currency != asset.currency) {
      throw AppException('ASSET', 'Hesap ${m.currency.code}, varlık ${asset.currency.code}. Aynı para birimini seçin.');
    }
    return m;
  }

  static int _qty(String text) {
    try {
      return Qty.parse(text);
    } on FormatException catch (e) {
      throw AppException('QTY', 'Miktar geçersiz: ${e.message}');
    }
  }

  static int? _optionalQty(String? text) => text == null || text.trim().isEmpty ? null : _qty(text);

  static Money _money(String text, Currency c) {
    final Money m;
    try {
      m = Money.parse(text, c);
    } on FormatException catch (e) {
      throw AppException('AMOUNT', 'Tutar geçersiz: ${e.message}');
    }
    if (!m.isPositive) throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');
    return m;
  }

  static Money? _optionalMoney(String? text, Currency c) =>
      text == null || text.trim().isEmpty ? null : _money(text, c);
}
