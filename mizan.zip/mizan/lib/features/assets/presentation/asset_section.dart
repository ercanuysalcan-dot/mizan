import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../application/assets_providers.dart';
import '../data/assets_repository.dart';
import '../domain/asset_type.dart';
import '../domain/quantity.dart';

final _qtyFormatter = FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'));

String _pct(double v) => '${v >= 0 ? '+' : ''}%${v.toStringAsFixed(1).replaceAll('.', ',')}';

/// Birikim hesabı ayrıntısı: miktar, maliyet, değer, kâr/zarar ve
/// Alış / Satış / Ekle / Çıkar hareketleri.
class AssetSection extends ConsumerWidget {
  const AssetSection({super.key, required this.accountId});
  final String accountId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(assetProvider(accountId));
    return async.when(
      loading: () => const Padding(padding: EdgeInsets.all(Space.xl), child: Center(child: CircularProgressIndicator())),
      error: (e, _) => Text('Birikim yüklenemedi: $e'),
      data: (a) => a == null ? const SizedBox.shrink() : _Body(a: a),
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.a});
  final AssetInfo a;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final un = a.unrealized;
    final pct = a.unrealizedPercent;
    Widget stat(String label, String value, {Color? color}) => Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: context.text.labelSmall),
            Text(value,
                style: context.text.titleSmall!.copyWith(color: color, fontFeatures: MizanTheme.tabular),
                maxLines: 1,
                overflow: TextOverflow.ellipsis),
          ]),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      MizanCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('ELDEKİ MİKTAR · ${a.type.label.toUpperCase()}', style: context.text.labelSmall),
          Space.gapXs,
          Text('${Qty.format(a.quantityE8)} ${a.unit}',
              style: context.text.displaySmall!.copyWith(fontFeatures: MizanTheme.tabular)),
          Space.gapMd,
          Row(children: [
            stat('MALİYET', MoneyFormat.format(a.cost)),
            stat('ORT. MALİYET', a.averageCost == null ? '—' : '${MoneyFormat.format(a.averageCost!)}/${a.unit}'),
          ]),
          Space.gapMd,
          Row(children: [
            stat('GÜNCEL DEĞER', a.marketValue == null ? 'Fiyat gir' : MoneyFormat.format(a.marketValue!)),
            stat(
              'KÂR / ZARAR',
              un == null ? '—' : '${MoneyFormat.format(un)}${pct == null ? '' : '  ${_pct(pct)}'}',
              color: un == null ? null : (un.isNegative ? t.expense : t.income),
            ),
          ]),
          Space.gapSm,
          Text(
            a.price == null
                ? 'Güncel birim fiyatı girersen değer ve kâr/zarar hesaplanır.'
                : 'Birim fiyat ${MoneyFormat.format(a.price!)}/${a.unit}'
                    '${a.priceAt == null ? '' : ' · ${TrFormat.dateTime(a.priceAt!)}'}'
                    '${a.realized.isZero ? '' : ' · Satışlardan gerçekleşen: ${MoneyFormat.format(a.realized)}'}',
            style: context.text.bodySmall,
          ),
          Space.gapSm,
          OutlinedButton.icon(
            onPressed: () => showAssetPriceSheet(context, a),
            icon: const Icon(Icons.price_change_outlined, size: 18),
            label: const Text('Güncel fiyatı gir'),
          ),
        ]),
      ),
      Space.gapMd,
      Row(children: [
        for (final type in AssetMoveType.values) ...[
          if (type != AssetMoveType.alis) Space.gapSm,
          Expanded(
            child: FilledButton.tonal(
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: Space.md)),
              onPressed: () => showAssetMoveSheet(context, a, type),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(switch (type) {
                  AssetMoveType.alis => Icons.add_shopping_cart_rounded,
                  AssetMoveType.satis => Icons.sell_outlined,
                  AssetMoveType.ekle => Icons.add_circle_outline_rounded,
                  AssetMoveType.cikar => Icons.remove_circle_outline_rounded,
                }),
                Space.gapXs,
                Text(type.label, maxLines: 1),
              ]),
            ),
          ),
        ],
      ]),
      Space.gapLg,
      const SectionHeader('Alış / satış hareketleri'),
      if (a.moves.isEmpty)
        const MizanCard(
          child: EmptyState(
            compact: true,
            icon: Icons.swap_vert_rounded,
            title: 'Henüz hareket yok',
            message: 'Alış ile miktar ve maliyet eklenir; satışta kâr/zarar kendiliğinden hesaplanır.',
          ),
        )
      else
        MizanCard(
          padding: const EdgeInsets.symmetric(vertical: Space.xs),
          child: Column(children: [
            for (var i = 0; i < a.moves.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              _MoveTile(a: a, m: a.moves[i]),
            ],
          ]),
        ),
    ]);
  }
}

class _MoveTile extends ConsumerWidget {
  const _MoveTile({required this.a, required this.m});
  final AssetInfo a;
  final AssetMove m;

  Future<void> _undo(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${m.type.label} geri alınsın mı?'),
        content: const Text('Miktar ve bağlı kayıt (ters kayıtla) geri alınır; bakiyeler eski haline döner.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Geri al')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref.read(assetsRepositoryProvider).undo(m.id, newId());
      messenger.showSnackBar(SnackBar(content: Text('${m.type.label} geri alındı.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.tokens;
    final sign = m.type.isIn ? '+' : '−';
    final parts = <String>[
      TrFormat.date(m.date),
      if (m.unitPrice != null && (m.type == AssetMoveType.alis || m.type == AssetMoveType.satis))
        '${MoneyFormat.format(m.unitPrice!)}/${a.unit}',
      if (m.type == AssetMoveType.satis)
        '${m.realized.isNegative ? 'Zarar' : 'Kâr'} ${MoneyFormat.format(m.realized)}',
      if (m.note != null) m.note!,
    ];
    return ListTile(
      contentPadding: const EdgeInsets.only(left: Space.lg),
      leading: CircleAvatar(
        radius: 16,
        backgroundColor: (m.type.isIn ? t.income : t.expense).withValues(alpha: 0.12),
        child: Icon(m.type.isIn ? Icons.south_west_rounded : Icons.north_east_rounded,
            size: 16, color: m.type.isIn ? t.income : t.expense),
      ),
      title: Text('${m.type.label}  $sign${Qty.format(m.quantityE8)} ${a.unit}', style: context.text.titleSmall),
      subtitle: Text(parts.join(' · '), style: context.text.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        if (!m.amount.isZero || !m.cost.isZero)
          Text(MoneyFormat.format(m.type == AssetMoveType.cikar ? m.cost : m.amount),
              style: context.text.titleSmall!.copyWith(fontFeatures: MizanTheme.tabular)),
        PopupMenuButton<String>(
          tooltip: 'Hareket',
          onSelected: (_) => _undo(context, ref),
          itemBuilder: (_) => const [PopupMenuItem(value: 'undo', child: Text('Geri al'))],
        ),
      ]),
    );
  }
}

// ---------------------------------------------------------------------------

Future<void> showAssetMoveSheet(BuildContext context, AssetInfo a, AssetMoveType type) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _MoveSheet(a: a, type: type),
    );

class _MoveSheet extends ConsumerStatefulWidget {
  const _MoveSheet({required this.a, required this.type});
  final AssetInfo a;
  final AssetMoveType type;

  @override
  ConsumerState<_MoveSheet> createState() => _MoveSheetState();
}

class _MoveSheetState extends ConsumerState<_MoveSheet> {
  final _qty = TextEditingController();
  final _total = TextEditingController();
  final _note = TextEditingController();
  late DateTime _date = ref.read(clockProvider).now();
  String? _moneyId;
  final String _key = newId();
  bool _busy = false;
  String? _error;

  bool get _needsMoney => widget.type == AssetMoveType.alis || widget.type == AssetMoveType.satis;

  @override
  void dispose() {
    _qty.dispose();
    _total.dispose();
    _note.dispose();
    super.dispose();
  }

  /// Girilen miktar ve tutardan birim fiyat (bilgi amaçlı).
  String? _unitHint() {
    try {
      final q = Qty.parse(_qty.text);
      final m = Money.parse(_total.text, widget.a.currency);
      if (!m.isPositive) return null;
      final unit = divideRounded(BigInt.from(m.minor) * BigInt.from(Qty.scale), BigInt.from(q), RoundingMode.halfUp);
      return 'Birim fiyat: ${MoneyFormat.format(Money.fromMinor(unit.toInt(), widget.a.currency))}/${widget.a.unit}';
    } catch (_) {
      return null;
    }
  }

  Future<void> _save() async {
    if (_needsMoney && _moneyId == null) {
      setState(() => _error = widget.type == AssetMoveType.alis ? 'Ödemeyi yaptığın hesabı seç.' : 'Paranın girdiği hesabı seç.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = ref.read(assetsRepositoryProvider);
    final id = widget.a.account.id;
    try {
      switch (widget.type) {
        case AssetMoveType.alis:
          await repo.buy(accountId: id, qtyText: _qty.text, totalText: _total.text, moneyAccountId: _moneyId!,
              date: _date, note: _note.text, key: _key);
        case AssetMoveType.satis:
          await repo.sell(accountId: id, qtyText: _qty.text, totalText: _total.text, moneyAccountId: _moneyId!,
              date: _date, note: _note.text, key: _key);
        case AssetMoveType.ekle:
          await repo.add(accountId: id, qtyText: _qty.text, valueText: _total.text, date: _date, note: _note.text, key: _key);
        case AssetMoveType.cikar:
          await repo.remove(accountId: id, qtyText: _qty.text, date: _date, note: _note.text, key: _key);
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${widget.type.label} kaydedildi.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final a = widget.a;
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final accounts = (ref.watch(userAccountsProvider).valueOrNull ?? const <AccountWithBalance>[])
        .where((x) =>
            (x.account.kind == AccountKind.kasa || x.account.kind == AccountKind.banka) &&
            x.account.currency == a.currency)
        .toList();
    final hint = _needsMoney ? _unitHint() : null;
    final totalLabel = switch (widget.type) {
      AssetMoveType.alis => 'Ödenen toplam tutar',
      AssetMoveType.satis => 'Alınan toplam tutar',
      AssetMoveType.ekle => 'Değeri / maliyeti (isteğe bağlı)',
      AssetMoveType.cikar => '',
    };
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${a.account.name} · ${widget.type.label}', style: context.text.headlineSmall),
            Space.gapXs,
            Text('Eldeki: ${Qty.format(a.quantityE8)} ${a.unit}', style: context.text.bodySmall),
            Space.gapLg,
            TextField(
              controller: _qty,
              autofocus: true,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [_qtyFormatter],
              onChanged: (_) => setState(() {}),
              style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
              decoration: InputDecoration(labelText: 'Miktar', hintText: '10,5', suffixText: a.unit),
            ),
            if (widget.type != AssetMoveType.cikar) ...[
              Space.gapMd,
              TextField(
                controller: _total,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [_qtyFormatter],
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: totalLabel,
                  suffixText: a.currency.code,
                  helperText: hint ??
                      (widget.type == AssetMoveType.ekle ? 'Hediye ya da devirde maliyet yoksa boş bırak.' : null),
                ),
              ),
            ] else ...[
              Space.gapSm,
              Text('Çıkan miktarın ortalama maliyeti kadar maliyet düşülür (hediye, kayıp vb.).',
                  style: context.text.bodySmall),
            ],
            if (_needsMoney) ...[
              Space.gapMd,
              if (accounts.isEmpty)
                Text('Önce ${a.currency.code} para biriminde bir kasa ya da banka hesabı ekle.',
                    style: context.text.bodyMedium!.copyWith(color: context.tokens.expense))
              else
                DropdownButtonFormField<String>(
                  // ignore: deprecated_member_use
                  value: accounts.any((x) => x.account.id == _moneyId) ? _moneyId : null,
                  isExpanded: true,
                  decoration: InputDecoration(
                    labelText: widget.type == AssetMoveType.alis ? 'Paranın çıktığı hesap' : 'Paranın girdiği hesap',
                  ),
                  items: [
                    for (final x in accounts)
                      DropdownMenuItem(
                        value: x.account.id,
                        child: Text('${x.account.name} · ${MoneyFormat.format(x.balance)}', overflow: TextOverflow.ellipsis),
                      ),
                  ],
                  onChanged: (v) => setState(() => _moneyId = v),
                ),
            ],
            Space.gapMd,
            OutlinedButton.icon(
              icon: const Icon(Icons.event_outlined, size: 18),
              label: Text('Tarih: ${TrFormat.date(_date)}'),
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(_date.year + 1),
                );
                if (picked != null) {
                  final now = ref.read(clockProvider).now();
                  setState(() => _date = DateTime(picked.year, picked.month, picked.day, now.hour, now.minute));
                }
              },
            ),
            Space.gapMd,
            TextField(
              controller: _note,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Not (isteğe bağlı)', hintText: 'Kuyumcu, borsa …'),
            ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : Text('${widget.type.label} kaydet'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

Future<void> showAssetPriceSheet(BuildContext context, AssetInfo a) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 520),
      builder: (_) => _PriceSheet(a: a),
    );

class _PriceSheet extends ConsumerStatefulWidget {
  const _PriceSheet({required this.a});
  final AssetInfo a;

  @override
  ConsumerState<_PriceSheet> createState() => _PriceSheetState();
}

class _PriceSheetState extends ConsumerState<_PriceSheet> {
  late final _price = TextEditingController(
      text: widget.a.price == null ? '' : MoneyFormat.format(widget.a.price!, symbol: false));
  String? _error;

  @override
  void dispose() {
    _price.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    try {
      await ref.read(assetsRepositoryProvider).setPrice(widget.a.account.id, _price.text);
      if (mounted) Navigator.pop(context);
    } on AppException catch (e) {
      setState(() => _error = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final a = widget.a;
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Güncel fiyat', style: context.text.headlineSmall),
          Space.gapXs,
          Text('${a.account.name} · 1 ${a.unit} kaç ${a.currency.code}?', style: context.text.bodySmall),
          Space.gapLg,
          TextField(
            controller: _price,
            autofocus: true,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [_qtyFormatter],
            style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
            decoration: InputDecoration(labelText: 'Birim fiyat', suffixText: '${a.currency.code}/${a.unit}'),
          ),
          if (_error != null) ...[
            Space.gapMd,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapXl,
          FilledButton(onPressed: _save, child: const Text('Kaydet')),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------

/// Yeni birikim (altın, gümüş, kripto, döviz) hesabı formu.
class AssetCreateForm extends ConsumerStatefulWidget {
  const AssetCreateForm({super.key, this.onBack});
  final VoidCallback? onBack;

  @override
  ConsumerState<AssetCreateForm> createState() => _AssetCreateFormState();
}

class _AssetCreateFormState extends ConsumerState<AssetCreateForm> {
  AssetType _type = AssetType.gramAltin;
  late Currency _currency = ref.read(currentBusinessProvider).baseCurrency;
  final _name = TextEditingController(text: AssetType.gramAltin.defaultName);
  final _unit = TextEditingController(text: AssetType.gramAltin.defaultUnit);
  final _qty = TextEditingController();
  final _cost = TextEditingController();
  final _price = TextEditingController();
  final String _key = newId();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _unit.dispose();
    _qty.dispose();
    _cost.dispose();
    _price.dispose();
    super.dispose();
  }

  void _pickType(AssetType t) {
    setState(() {
      final nameWasDefault = _name.text.trim().isEmpty || _name.text == _type.defaultName;
      final unitWasDefault = _unit.text.trim().isEmpty || _unit.text == _type.defaultUnit;
      _type = t;
      if (nameWasDefault) _name.text = t.defaultName;
      if (unitWasDefault) _unit.text = t.defaultUnit;
    });
  }

  Future<void> _save() async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(assetsRepositoryProvider).create(
            businessId: ref.read(currentBusinessProvider).id,
            name: _name.text,
            type: _type,
            unit: _unit.text,
            currency: _currency,
            openingQtyText: _qty.text,
            openingCostText: _cost.text,
            priceText: _price.text,
            formKey: _key,
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('“${_name.text.trim()}” oluşturuldu.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(children: [
          if (widget.onBack != null)
            IconButton(tooltip: 'Tür seçimine dön', onPressed: widget.onBack, icon: const Icon(Icons.arrow_back_rounded)),
          Icon(Icons.savings_outlined, color: context.colors.secondary),
          Space.gapSm,
          Expanded(child: Text('Altın, döviz, kripto', style: context.text.titleLarge)),
        ]),
        Space.gapLg,
        Wrap(spacing: Space.sm, runSpacing: Space.xs, children: [
          for (final t in AssetType.values)
            ChoiceChip(label: Text(t.label), selected: _type == t, onSelected: (_) => _pickType(t)),
        ]),
        Space.gapLg,
        Row(children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: _name,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'Hesap adı', hintText: 'Ak Gümüş'),
            ),
          ),
          Space.gapMd,
          Expanded(
            child: TextField(controller: _unit, decoration: const InputDecoration(labelText: 'Birim')),
          ),
        ]),
        Space.gapLg,
        Text('Değer para birimi', style: context.text.labelLarge),
        Space.gapSm,
        SegmentedButton<Currency>(
          showSelectedIcon: false,
          segments: [for (final c in Currency.values) ButtonSegment(value: c, label: Text('${c.symbol} ${c.code}'))],
          selected: {_currency},
          onSelectionChanged: (s) => setState(() => _currency = s.first),
        ),
        Space.gapLg,
        Text('Elinde zaten varsa (isteğe bağlı)', style: context.text.labelLarge),
        Space.gapSm,
        Row(children: [
          Expanded(
            child: TextField(
              controller: _qty,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [_qtyFormatter],
              decoration: InputDecoration(labelText: 'Miktar', suffixText: _unit.text),
            ),
          ),
          Space.gapMd,
          Expanded(
            child: TextField(
              controller: _cost,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [_qtyFormatter],
              decoration: InputDecoration(labelText: 'Toplam maliyet', suffixText: _currency.code),
            ),
          ),
        ]),
        Space.gapMd,
        TextField(
          controller: _price,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [_qtyFormatter],
          decoration: InputDecoration(
            labelText: 'Güncel birim fiyat (isteğe bağlı)',
            suffixText: '${_currency.code}/${_unit.text}',
          ),
        ),
        Space.gapSm,
        Text('Sonra Alış / Satış ile işlem ekleyebilirsin; satışta kâr/zarar kendiliğinden hesaplanır.',
            style: context.text.bodySmall),
        if (_error != null) ...[
          Space.gapMd,
          Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
        ],
        Space.gapXl,
        FilledButton(
          onPressed: _busy ? null : _save,
          child: _busy
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('Hesabı oluştur'),
        ),
      ],
    );
  }
}
