import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../categories/application/categories_providers.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../data/assets_repository.dart';

final assetsRepositoryProvider = Provider<AssetsRepository>((ref) => AssetsRepository(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(categoriesRepositoryProvider),
      ref.watch(entryEditServiceProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final assetProvider = StreamProvider.autoDispose.family<AssetInfo?, String>((ref, accountId) {
  return ref.watch(assetsRepositoryProvider).watch(accountId);
});
