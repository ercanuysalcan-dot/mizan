/// Birikim (varlık) türü. Kod, veritabanındaki savings_details.asset_type'tır.
enum AssetType {
  gramAltin('gram_altin', 'Gram altın', 'gr', 'Gram Altın'),
  ceyrekAltin('ceyrek_altin', 'Çeyrek altın', 'adet', 'Çeyrek Altın'),
  altin('altin', 'Altın (diğer)', 'adet', 'Altın'),
  gumus('gumus', 'Gümüş', 'gr', 'Gümüş'),
  bitcoin('bitcoin', 'Bitcoin', 'BTC', 'Bitcoin'),
  kripto('kripto', 'Diğer kripto', 'adet', 'Kripto'),
  dolar('dolar', 'Dolar', '\$', 'Dolar'),
  euro('euro', 'Euro', '€', 'Euro'),
  hisse('hisse', 'Hisse / fon', 'adet', 'Hisse'),
  diger('diger', 'Diğer', 'adet', 'Birikim');

  const AssetType(this.code, this.label, this.defaultUnit, this.defaultName);
  final String code;
  final String label;
  final String defaultUnit;
  final String defaultName;

  static AssetType fromCode(String? code) =>
      AssetType.values.firstWhere((t) => t.code == code, orElse: () => AssetType.diger);
}

/// Miktar hareketi türü.
enum AssetMoveType {
  alis('alis', 'Alış'),
  satis('satis', 'Satış'),
  ekle('ekle', 'Ekle'),
  cikar('cikar', 'Çıkar');

  const AssetMoveType(this.code, this.label);
  final String code;
  final String label;

  /// Miktarı artırır mı?
  bool get isIn => this == alis || this == ekle;

  static AssetMoveType fromCode(String code) => AssetMoveType.values.firstWhere((t) => t.code == code);
}
