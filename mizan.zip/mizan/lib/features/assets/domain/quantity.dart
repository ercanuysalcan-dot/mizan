/// Varlık miktarı: tamsayı olarak miktar × 10^8 (Bitcoin'in 8 ondalığı için).
abstract final class Qty {
  static const scale = 100000000;

  /// "22,76" / "0.00123456" / "1.250,5" → e8. Geçersizse FormatException.
  static int parse(String input) {
    var s = input.trim().replaceAll(' ', '');
    if (s.isEmpty) throw const FormatException('Miktar boş');
    if (s.contains(',')) {
      s = s.replaceAll('.', '').replaceAll(',', '.');
    } else if ('.'.allMatches(s).length > 1) {
      s = s.replaceAll('.', '');
    }
    if (!RegExp(r'^\d+(\.\d+)?$').hasMatch(s)) throw const FormatException('Miktar yalnızca rakam olabilir');
    final parts = s.split('.');
    final frac = parts.length > 1 ? parts[1] : '';
    if (frac.length > 8) throw const FormatException('En fazla 8 ondalık basamak');
    final whole = int.parse(parts[0]);
    final f = frac.isEmpty ? 0 : int.parse(frac.padRight(8, '0'));
    final v = whole * scale + f;
    if (v <= 0) throw const FormatException('Miktar sıfırdan büyük olmalı');
    return v;
  }

  /// e8 → "22,76" (gereksiz sıfırlar atılır, binlik ayırıcı nokta).
  static String format(int e8) {
    final neg = e8 < 0;
    final a = e8.abs();
    final whole = a ~/ scale;
    var frac = (a % scale).toString().padLeft(8, '0');
    frac = frac.replaceFirst(RegExp(r'0+$'), '');
    final w = whole.toString();
    final b = StringBuffer();
    for (var i = 0; i < w.length; i++) {
      if (i > 0 && (w.length - i) % 3 == 0) b.write('.');
      b.write(w[i]);
    }
    return '${neg ? '-' : ''}$b${frac.isEmpty ? '' : ',$frac'}';
  }
}
