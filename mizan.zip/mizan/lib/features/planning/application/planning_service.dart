import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/clock.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../cards/data/card_statements_repository.dart';
import '../../loans/data/loans_repository.dart';
import '../../transactions/application/quick_entry_service.dart';
import '../data/recurring_repository.dart';

enum UpcomingKind { loan, card, income, expense, transfer }

/// Takvimdeki bir ödeme / tahsilat.
class UpcomingItem {
  const UpcomingItem({
    required this.date,
    required this.kind,
    required this.title,
    required this.subtitle,
    required this.amount,
    required this.cashEffect,
    this.loan,
    this.installment,
    this.rule,
    this.cardAccountId,
  });

  final DateTime date;
  final UpcomingKind kind;
  final String title;
  final String subtitle;
  final Money amount;

  /// Kasa+banka (nakit) üzerindeki etkisi: +1 giriş, −1 çıkış, 0 etkisiz.
  final int cashEffect;

  final LoanInfo? loan;
  final LoanInstallment? installment;
  final RecurringRule? rule;
  final String? cardAccountId;

  /// Bu satır, kuralın sıradaki (kaydedilebilir) vadesi mi?
  bool get isNextOfRule => rule != null && _sameDay(rule!.nextDue, date);

  static bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
}

class ForecastPoint {
  const ForecastPoint(this.day, this.balanceMinor);
  final DateTime day;
  final int balanceMinor;
}

/// Kasa ve banka hesaplarının (ana para biriminde) gün gün tahmini.
class CashForecast {
  const CashForecast({
    required this.currency,
    required this.start,
    required this.end,
    required this.lowest,
    required this.lowestDay,
    required this.inflow,
    required this.outflow,
    required this.points,
    required this.otherCurrencies,
  });

  final Currency currency;
  final Money start;
  final Money end;
  final Money lowest;
  final DateTime lowestDay;
  final Money inflow;
  final Money outflow;
  final List<ForecastPoint> points;

  /// Tahmine katılmayan (başka para birimindeki) nakit hesap sayısı.
  final int otherCurrencies;

  bool get goesNegative => lowest.isNegative;
}

class PlanSnapshot {
  const PlanSnapshot({required this.upcoming, required this.forecast, required this.horizonDays});
  final List<UpcomingItem> upcoming;
  final CashForecast forecast;
  final int horizonDays;

  List<UpcomingItem> overdue(DateTime today) =>
      upcoming.where((u) => u.date.isBefore(DateTime(today.year, today.month, today.day))).toList();
}

/// Yaklaşan ödemeler takvimi + nakit akışı tahmini.
class PlanningService {
  PlanningService(this._accounts, this._loans, this._cards, this._recurring, {Clock clock = const Clock()})
      : _clock = clock;

  final AccountsRepository _accounts;
  final LoansRepository _loans;
  final CardStatementsRepository _cards;
  final RecurringRepository _recurring;
  final Clock _clock;

  static const _liquid = {AccountKind.kasa, AccountKind.banka};

  Future<PlanSnapshot> snapshot(String businessId, Currency baseCurrency, {int horizonDays = 30}) async {
    final now = _clock.now();
    final today = DateTime(now.year, now.month, now.day);
    final horizonEnd = DateTime(today.year, today.month, today.day + horizonDays);
    final accounts = await _accounts.userAccounts(businessId);
    final byId = {for (final a in accounts) a.account.id: a};
    String name(String? id) => id == null ? '' : (byId[id]?.account.name ?? 'Silinmiş hesap');
    bool liquid(String? id) => id != null && _liquid.contains(byId[id]?.account.kind);

    final items = <UpcomingItem>[];

    // 1) Kredi taksitleri
    for (final a in accounts.where((a) => a.account.kind == AccountKind.kredi)) {
      final info = await _loans.load(a.account.id);
      if (info == null) continue;
      for (final i in info.installments) {
        if (i.isPaid || i.dueDate.isAfter(horizonEnd)) continue;
        items.add(UpcomingItem(
          date: DateTime(i.dueDate.year, i.dueDate.month, i.dueDate.day),
          kind: UpcomingKind.loan,
          title: '${info.account.name} — ${i.no}/${info.installments.length}. taksit',
          subtitle: 'Kredi taksiti',
          amount: i.amount,
          cashEffect: -1,
          loan: info,
          installment: i,
        ));
      }
    }

    // 2) Kart son ödeme günleri (borcu olan kartlar, son ekstreye göre)
    for (final a in accounts.where((a) => a.account.kind == AccountKind.krediKarti && a.balance.isPositive)) {
      final statements = await _cards.list(a.account.id);
      for (final s in statements) {
        final due = s.dueDate;
        if (due == null) continue;
        final dueDay = DateTime(due.year, due.month, due.day);
        if (dueDay.isBefore(today.subtract(const Duration(days: 45)))) break;
        if (dueDay.isAfter(horizonEnd)) continue;
        final amount = s.amount.isPositive && s.amount.compareTo(a.balance) < 0 ? s.amount : a.balance;
        items.add(UpcomingItem(
          date: dueDay,
          kind: UpcomingKind.card,
          title: '${a.account.name} — son ödeme',
          subtitle: 'Kart borcu · ekstre ${MoneyFormat.format(s.amount)}',
          amount: amount,
          cashEffect: -1,
          cardAccountId: a.account.id,
        ));
        break;
      }
    }

    // 3) Tekrarlayan işlemler
    final rules = await _recurring.list(businessId, onlyActive: true);
    for (final r in rules) {
      for (final d in r.occurrencesUntil(horizonEnd)) {
        final (kind, effect, sub) = switch (r.kind) {
          QuickEntryKind.income => (UpcomingKind.income, liquid(r.accountId) ? 1 : 0, '${name(r.accountId)} hesabına'),
          QuickEntryKind.transfer => (
              UpcomingKind.transfer,
              liquid(r.accountId) == liquid(r.targetAccountId) ? 0 : (liquid(r.accountId) ? -1 : 1),
              '${name(r.accountId)} → ${name(r.targetAccountId)}',
            ),
          _ => (UpcomingKind.expense, liquid(r.accountId) ? -1 : 0, '${name(r.accountId)} hesabından'),
        };
        items.add(UpcomingItem(
          date: DateTime(d.year, d.month, d.day),
          kind: kind,
          title: r.name,
          subtitle: '${r.frequency.label} · $sub',
          amount: r.amount,
          cashEffect: effect,
          rule: r,
        ));
      }
    }

    items.sort((a, b) => a.date.compareTo(b.date));

    // Nakit tahmini (ana para birimi)
    var start = 0;
    var others = 0;
    for (final a in accounts.where((a) => _liquid.contains(a.account.kind))) {
      if (a.account.currency == baseCurrency) {
        start += a.balance.minor;
      } else {
        others++;
      }
    }
    final deltas = List<int>.filled(horizonDays + 1, 0);
    var inflow = 0, outflow = 0;
    for (final it in items) {
      if (it.cashEffect == 0 || it.amount.currency != baseCurrency) continue;
      final idx = it.date.isBefore(today) ? 0 : it.date.difference(today).inHours ~/ 24;
      if (idx < 0 || idx > horizonDays) continue;
      deltas[idx] += it.cashEffect * it.amount.minor;
      if (it.cashEffect > 0) {
        inflow += it.amount.minor;
      } else {
        outflow += it.amount.minor;
      }
    }
    final points = <ForecastPoint>[];
    var running = start;
    var lowest = start;
    var lowestDay = today;
    for (var i = 0; i <= horizonDays; i++) {
      running += deltas[i];
      final day = DateTime(today.year, today.month, today.day + i);
      points.add(ForecastPoint(day, running));
      if (running < lowest) {
        lowest = running;
        lowestDay = day;
      }
    }
    Money m(int v) => Money.fromMinor(v, baseCurrency);
    return PlanSnapshot(
      upcoming: items,
      horizonDays: horizonDays,
      forecast: CashForecast(
        currency: baseCurrency,
        start: m(start),
        end: m(running),
        lowest: m(lowest),
        lowestDay: lowestDay,
        inflow: m(inflow),
        outflow: m(outflow),
        points: points,
        otherCurrencies: others,
      ),
    );
  }
}
