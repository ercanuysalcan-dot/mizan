import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../cards/application/cards_providers.dart';
import '../../loans/application/loans_providers.dart';
import '../../transactions/application/quick_entry_service.dart';
import '../data/budgets_repository.dart';
import '../data/recurring_repository.dart';
import 'planning_service.dart';

final recurringRepositoryProvider = Provider<RecurringRepository>((ref) => RecurringRepository(
      ref.watch(databaseProvider),
      ref.watch(quickEntryServiceProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final budgetsRepositoryProvider = Provider<BudgetsRepository>((ref) => BudgetsRepository(
      ref.watch(databaseProvider),
      ref.watch(accountsRepositoryProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final planningServiceProvider = Provider<PlanningService>((ref) => PlanningService(
      ref.watch(accountsRepositoryProvider),
      ref.watch(loansRepositoryProvider),
      ref.watch(cardStatementsRepositoryProvider),
      ref.watch(recurringRepositoryProvider),
      clock: ref.watch(clockProvider),
    ));

/// Plan ekranındaki tahmin süresi (gün).
class HorizonNotifier extends Notifier<int> {
  @override
  int build() => 30;
  void set(int days) => state = days;
}

final planHorizonProvider = NotifierProvider<HorizonNotifier, int>(HorizonNotifier.new);

final planSnapshotProvider = StreamProvider.autoDispose<PlanSnapshot>((ref) {
  final business = ref.watch(currentBusinessProvider);
  final days = ref.watch(planHorizonProvider);
  final service = ref.watch(planningServiceProvider);
  return ref
      .watch(databaseProvider)
      .watchAll(() => service.snapshot(business.id, business.baseCurrency, horizonDays: days));
});

final recurringRulesProvider = StreamProvider.autoDispose<List<RecurringRule>>((ref) {
  return ref.watch(recurringRepositoryProvider).watch(ref.watch(currentBusinessProvider).id);
});

final budgetStatusProvider = StreamProvider.autoDispose<List<BudgetStatus>>((ref) {
  return ref.watch(budgetsRepositoryProvider).watch(ref.watch(currentBusinessProvider).id);
});
