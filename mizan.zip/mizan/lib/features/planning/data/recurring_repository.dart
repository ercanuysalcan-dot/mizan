import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../transactions/application/quick_entry_service.dart';

enum RecurFrequency {
  haftalik('Haftalık', 'hafta'),
  aylik('Aylık', 'ay'),
  yillik('Yıllık', 'yıl');

  const RecurFrequency(this.label, this.unit);
  final String label;
  final String unit;

  static RecurFrequency fromCode(String code) =>
      RecurFrequency.values.firstWhere((f) => f.name == code, orElse: () => RecurFrequency.aylik);
}

/// Tekrarlayan işlem (maaş, kira, fatura …). Plan bilgisidir; deftere yalnızca
/// kullanıcı "Kaydet" dediğinde yazılır.
class RecurringRule {
  const RecurringRule({
    required this.id,
    required this.name,
    required this.kind,
    required this.accountId,
    required this.targetAccountId,
    required this.categoryId,
    required this.amount,
    required this.description,
    required this.frequency,
    required this.interval,
    required this.anchorDay,
    required this.nextDue,
    required this.endDate,
    required this.active,
  });

  final String id;
  final String name;

  /// Yalnızca gelir, gider ya da transfer.
  final QuickEntryKind kind;
  final String accountId;
  final String? targetAccountId;
  final String? categoryId;
  final Money amount;
  final String? description;
  final RecurFrequency frequency;
  final int interval;

  /// Aylık/yıllık tekrarda ayın günü (31 → ay sonu).
  final int anchorDay;
  final DateTime nextDue;
  final DateTime? endDate;
  final bool active;

  /// [nextDue]'dan başlayarak [until] (dahil) tarihine kadarki vadeler.
  List<DateTime> occurrencesUntil(DateTime until, {int max = 120}) {
    final out = <DateTime>[];
    var d = nextDue;
    while (!_day(d).isAfter(_day(until)) && out.length < max) {
      if (endDate != null && _day(d).isAfter(_day(endDate!))) break;
      out.add(d);
      d = RecurringRepository.advance(d, frequency, interval, anchorDay);
    }
    return out;
  }

  static DateTime _day(DateTime d) => DateTime(d.year, d.month, d.day);
}

class RecurringRepository {
  RecurringRepository(this._db, this._quick, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final QuickEntryService _quick;
  final String deviceId;
  final Clock _clock;

  /// Bir sonraki vade. Aylık/yıllıkta ayın günü korunur (31 Ocak → 28/29 Şubat → 31 Mart).
  static DateTime advance(DateTime d, RecurFrequency f, int interval, int anchorDay) {
    if (f == RecurFrequency.haftalik) return DateTime(d.year, d.month, d.day + 7 * interval, 12);
    final months = f == RecurFrequency.aylik ? interval : 12 * interval;
    final idx = d.month - 1 + months;
    final y = d.year + idx ~/ 12;
    final m = idx % 12 + 1;
    final last = DateTime(y, m + 1, 0).day;
    return DateTime(y, m, anchorDay > last ? last : anchorDay, 12);
  }

  Stream<List<RecurringRule>> watch(String businessId) => _db.watchAll(() => list(businessId));

  Future<List<RecurringRule>> list(String businessId, {bool onlyActive = false}) async {
    final rows = await _db.customSelect(
      'SELECT id, template_json, frequency, interval_count, next_run_date, end_date, active '
      'FROM recurring_rules WHERE business_id = ? AND deleted_at IS NULL '
      '${onlyActive ? 'AND active = 1 ' : ''}ORDER BY next_run_date',
      variables: [Variable.withString(businessId)],
    ).get();
    final out = <RecurringRule>[];
    for (final r in rows) {
      final rule = _map(r);
      if (rule != null) out.add(rule);
    }
    return out;
  }

  Future<RecurringRule?> byId(String id) async {
    final r = await _db.customSelect(
      'SELECT id, template_json, frequency, interval_count, next_run_date, end_date, active '
      'FROM recurring_rules WHERE id = ? AND deleted_at IS NULL',
      variables: [Variable.withString(id)],
    ).getSingleOrNull();
    return r == null ? null : _map(r);
  }

  Future<String> save({
    String? id,
    required String businessId,
    required String name,
    required QuickEntryKind kind,
    required String accountId,
    String? targetAccountId,
    String? categoryId,
    required Money amount,
    String? description,
    required RecurFrequency frequency,
    int interval = 1,
    required DateTime firstDue,
    DateTime? endDate,
    bool active = true,
  }) async {
    if (!{QuickEntryKind.income, QuickEntryKind.expense, QuickEntryKind.transfer}.contains(kind)) {
      throw const AppException('RECURRING', 'Tekrarlayan işlem gelir, gider ya da transfer olabilir.');
    }
    if (name.trim().isEmpty) throw const AppException('RECURRING', 'Bir ad yazın (örn. Kira, Maaş).');
    if (!amount.isPositive) throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');
    if (kind == QuickEntryKind.transfer) {
      if (targetAccountId == null) throw const AppException('RECURRING', 'Paranın gideceği hesabı seçin.');
      if (targetAccountId == accountId) throw const AppException('RECURRING', 'İki hesap aynı olamaz.');
    } else if (categoryId == null) {
      throw const AppException('CATEGORY', 'Kategori seçin.');
    }
    if (interval < 1 || interval > 24) throw const AppException('RECURRING', 'Tekrar aralığı 1–24 olmalı.');
    final due = DateTime(firstDue.year, firstDue.month, firstDue.day, 12);
    if (endDate != null && endDate.isBefore(due)) {
      throw const AppException('RECURRING', 'Bitiş tarihi ilk tarihten önce olamaz.');
    }
    final template = jsonEncode({
      'v': 1,
      'name': name.trim(),
      'kind': kind.name,
      'account_id': accountId,
      'target_account_id': kind == QuickEntryKind.transfer ? targetAccountId : null,
      'category_id': kind == QuickEntryKind.transfer ? null : categoryId,
      'amount_minor': amount.minor,
      'currency': amount.currency.code,
      'description': description == null || description.trim().isEmpty ? null : description.trim(),
      'anchor_day': due.day,
    });
    final now = _clock.nowMs();
    final endMs = endDate == null ? null : DateTime(endDate.year, endDate.month, endDate.day, 12).millisecondsSinceEpoch;
    if (id == null) {
      final newRuleId = newId();
      await _db.customInsert(
        'INSERT INTO recurring_rules (id, business_id, template_json, frequency, interval_count, next_run_date, '
        'end_date, active, created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(newRuleId),
          Variable.withString(businessId),
          Variable.withString(template),
          Variable.withString(frequency.name),
          Variable.withInt(interval),
          Variable.withInt(due.millisecondsSinceEpoch),
          Variable<int>(endMs),
          Variable.withInt(active ? 1 : 0),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      return newRuleId;
    }
    await _db.customUpdate(
      'UPDATE recurring_rules SET template_json = ?, frequency = ?, interval_count = ?, next_run_date = ?, '
      'end_date = ?, active = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
      variables: [
        Variable.withString(template),
        Variable.withString(frequency.name),
        Variable.withInt(interval),
        Variable.withInt(due.millisecondsSinceEpoch),
        Variable<int>(endMs),
        Variable.withInt(active ? 1 : 0),
        Variable.withInt(now),
        Variable.withString(id),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
    return id;
  }

  Future<void> delete(String id) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE recurring_rules SET deleted_at = ?, active = 0, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE id = ?',
      variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  /// Sıradaki vadeyi deftere yazar ve bir sonraki vadeye geçer.
  /// [amountText] boşsa kayıtlı tutar kullanılır.
  Future<String> post({
    required String businessId,
    required String ruleId,
    String? amountText,
    DateTime? date,
    required String idempotencyKey,
  }) async {
    return _db.transaction(() async {
      final rule = await byId(ruleId);
      if (rule == null) throw const AppException('RECURRING', 'Tekrarlayan işlem bulunamadı.');
      final when = date ?? rule.nextDue;
      final entryId = await _quick.submit(
        kind: rule.kind,
        businessId: businessId,
        sourceAccountId: rule.accountId,
        targetAccountId: rule.targetAccountId,
        categoryId: rule.categoryId,
        amountText: (amountText == null || amountText.trim().isEmpty)
            ? _plain(rule.amount)
            : amountText,
        date: when,
        description: rule.description ?? rule.name,
        idempotencyKey: idempotencyKey,
      );
      await _advance(rule, lastEntryId: entryId);
      return entryId;
    });
  }

  /// Bu vadeyi atlar (kayıt yazılmaz).
  Future<void> skip(String ruleId) async {
    final rule = await byId(ruleId);
    if (rule == null) return;
    await _advance(rule);
  }

  // ---------------------------------------------------------------------------

  Future<void> _advance(RecurringRule rule, {String? lastEntryId}) async {
    final next = advance(rule.nextDue, rule.frequency, rule.interval, rule.anchorDay);
    final ended = rule.endDate != null && next.isAfter(rule.endDate!);
    await _db.customUpdate(
      'UPDATE recurring_rules SET next_run_date = ?, active = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE id = ?',
      variables: [
        Variable.withInt(next.millisecondsSinceEpoch),
        Variable.withInt(ended ? 0 : 1),
        Variable.withInt(_clock.nowMs()),
        Variable.withString(rule.id),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  static String _plain(Money m) {
    final d = m.currency.decimals;
    final s = m.minor.abs().toString().padLeft(d + 1, '0');
    return d == 0 ? s : '${s.substring(0, s.length - d)},${s.substring(s.length - d)}';
  }

  RecurringRule? _map(QueryRow r) {
    final Map<String, dynamic> t;
    try {
      t = jsonDecode(r.read<String>('template_json')) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
    final kindName = t['kind'] as String?;
    final kind = QuickEntryKind.values.where((k) => k.name == kindName).firstOrNull;
    final accountId = t['account_id'] as String?;
    final minor = t['amount_minor'] as int?;
    final currency = t['currency'] as String?;
    if (kind == null || accountId == null || minor == null || currency == null) return null;
    final next = DateTime.fromMillisecondsSinceEpoch(r.read<int>('next_run_date'));
    final endMs = r.readNullable<int>('end_date');
    return RecurringRule(
      id: r.read<String>('id'),
      name: (t['name'] as String?) ?? 'Tekrarlayan işlem',
      kind: kind,
      accountId: accountId,
      targetAccountId: t['target_account_id'] as String?,
      categoryId: t['category_id'] as String?,
      amount: Money.fromMinor(minor, Currency.fromCode(currency)),
      description: t['description'] as String?,
      frequency: RecurFrequency.fromCode(r.read<String>('frequency')),
      interval: r.read<int>('interval_count'),
      anchorDay: (t['anchor_day'] as int?) ?? next.day,
      nextDue: next,
      endDate: endMs == null ? null : DateTime.fromMillisecondsSinceEpoch(endMs),
      active: r.read<int>('active') == 1,
    );
  }
}
