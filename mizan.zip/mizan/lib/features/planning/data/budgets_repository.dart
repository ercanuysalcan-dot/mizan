import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../accounts/data/accounts_repository.dart';

/// Bir gider kategorisinin bu ayki bütçe durumu.
class BudgetStatus {
  const BudgetStatus({
    required this.id,
    required this.category,
    required this.limit,
    required this.spent,
  });

  final String id;
  final CategoryInfo category;
  final Money limit;

  /// Bu ay harcanan (alt kategoriler dahil).
  final Money spent;

  double get ratio => limit.minor == 0 ? 0 : spent.minor / limit.minor;
  Money get remaining => limit - spent;
  bool get isWarning => ratio >= 0.8 && ratio < 1;
  bool get isOver => ratio >= 1;
}

/// Kategori başına aylık harcama limiti.
class BudgetsRepository {
  BudgetsRepository(this._db, this._accounts, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final AccountsRepository _accounts;
  final String deviceId;
  final Clock _clock;

  Stream<List<BudgetStatus>> watch(String businessId) => _db.watchAll(() => statuses(businessId));

  Future<List<BudgetStatus>> statuses(String businessId, {DateTime? month}) async {
    final now = month ?? _clock.now();
    final start = DateTime(now.year, now.month).millisecondsSinceEpoch;
    final end = DateTime(now.year, now.month + 1).millisecondsSinceEpoch;
    final cats = await _accounts.categories(businessId, 'gider');
    final byId = {for (final c in cats) c.id: c};
    final rows = await _db.customSelect(
      '''
      SELECT b.id, b.category_id, b.currency, b.amount_minor,
        COALESCE((
          SELECT SUM(l.debit_minor - l.credit_minor)
          FROM journal_lines l
          JOIN journal_entries e ON e.id = l.entry_id AND e.status <> 'draft'
          JOIN accounts a ON a.id = l.account_id
          JOIN categories c ON c.id = a.category_id
          WHERE a.business_id = b.business_id AND l.currency = b.currency
            AND (c.id = b.category_id OR c.parent_id = b.category_id)
            AND e.entry_date >= ? AND e.entry_date < ?
        ), 0) AS spent
      FROM budgets b
      WHERE b.business_id = ? AND b.deleted_at IS NULL
      ''',
      variables: [Variable.withInt(start), Variable.withInt(end), Variable.withString(businessId)],
    ).get();
    final out = <BudgetStatus>[];
    for (final r in rows) {
      final cat = byId[r.read<String>('category_id')];
      if (cat == null) continue;
      final c = Currency.fromCode(r.read<String>('currency'));
      out.add(BudgetStatus(
        id: r.read<String>('id'),
        category: cat,
        limit: Money.fromMinor(r.read<int>('amount_minor'), c),
        spent: Money.fromMinor(r.read<int>('spent'), c),
      ));
    }
    out.sort((a, b) => b.ratio.compareTo(a.ratio));
    return out;
  }

  /// Bütçe ekler ya da aynı kategori + para birimindekini günceller.
  Future<void> set({
    required String businessId,
    required String categoryId,
    required Money limit,
  }) async {
    if (!limit.isPositive) throw const AppException('BUDGET', 'Bütçe tutarı sıfırdan büyük olmalı.');
    final now = _clock.nowMs();
    final existing = await _db.customSelect(
      'SELECT id FROM budgets WHERE category_id = ? AND currency = ? AND deleted_at IS NULL',
      variables: [Variable.withString(categoryId), Variable.withString(limit.currency.code)],
    ).getSingleOrNull();
    if (existing != null) {
      await _db.customUpdate(
        'UPDATE budgets SET amount_minor = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
        variables: [Variable.withInt(limit.minor), Variable.withInt(now), Variable.withString(existing.read<String>('id'))],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      return;
    }
    await _db.customInsert(
      'INSERT INTO budgets (id, business_id, category_id, currency, amount_minor, created_at, updated_at, device_id) '
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(categoryId),
        Variable.withString(limit.currency.code),
        Variable.withInt(limit.minor),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }

  Future<void> delete(String id) async {
    final now = _clock.nowMs();
    await _db.customUpdate(
      'UPDATE budgets SET deleted_at = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE id = ?',
      variables: [Variable.withInt(now), Variable.withInt(now), Variable.withString(id)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }
}
