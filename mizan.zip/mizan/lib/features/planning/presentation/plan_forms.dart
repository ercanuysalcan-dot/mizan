import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounts/application/accounts_providers.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../transactions/application/quick_entry_service.dart';
import '../application/planning_providers.dart';
import '../data/budgets_repository.dart';
import '../data/recurring_repository.dart';

final _amountFormatter = FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'));

Future<void> showRecurringForm(BuildContext context, {RecurringRule? existing}) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 600),
      builder: (_) => _RecurringForm(existing: existing),
    );

class _RecurringForm extends ConsumerStatefulWidget {
  const _RecurringForm({this.existing});
  final RecurringRule? existing;

  @override
  ConsumerState<_RecurringForm> createState() => _RecurringFormState();
}

class _RecurringFormState extends ConsumerState<_RecurringForm> {
  late final RecurringRule? _e = widget.existing;
  late QuickEntryKind _kind = _e?.kind ?? QuickEntryKind.expense;
  late final _name = TextEditingController(text: _e?.name ?? '');
  late final _amount =
      TextEditingController(text: _e == null ? '' : MoneyFormat.format(_e!.amount, symbol: false));
  late final _desc = TextEditingController(text: _e?.description ?? '');
  late String? _accountId = _e?.accountId;
  late String? _targetId = _e?.targetAccountId;
  late String? _categoryId = _e?.categoryId;
  late RecurFrequency _freq = _e?.frequency ?? RecurFrequency.aylik;
  late int _interval = _e?.interval ?? 1;
  late DateTime _first = _e?.nextDue ?? ref.read(clockProvider).now();
  late DateTime? _end = _e?.endDate;
  late bool _active = _e?.active ?? true;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _amount.dispose();
    _desc.dispose();
    super.dispose();
  }

  Future<void> _save(List<AccountWithBalance> accounts) async {
    final acc = accounts.where((a) => a.account.id == _accountId).firstOrNull;
    if (acc == null) {
      setState(() => _error = 'Hesap seçin.');
      return;
    }
    final Money amount;
    try {
      amount = Money.parse(_amount.text, acc.account.currency);
    } on FormatException {
      setState(() => _error = 'Tutar geçersiz.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(recurringRepositoryProvider).save(
            id: _e?.id,
            businessId: ref.read(currentBusinessProvider).id,
            name: _name.text,
            kind: _kind,
            accountId: acc.account.id,
            targetAccountId: _kind == QuickEntryKind.transfer ? _targetId : null,
            categoryId: _kind == QuickEntryKind.transfer ? null : _categoryId,
            amount: amount,
            description: _desc.text,
            frequency: _freq,
            interval: _interval,
            firstDue: _first,
            endDate: _end,
            active: _active,
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('“${_name.text.trim()}” ${_e == null ? 'eklendi' : 'güncellendi'}.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('“${_e!.name}” silinsin mi?'),
        content: const Text('Daha önce kaydedilmiş işlemler silinmez; yalnızca tekrar planı kaldırılır.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Sil')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await ref.read(recurringRepositoryProvider).delete(_e!.id);
    if (mounted) Navigator.pop(context);
  }

  Future<DateTime?> _pick(DateTime initial) => showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(2000),
        lastDate: DateTime(initial.year + 10),
      );

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final all = ref.watch(userAccountsProvider).valueOrNull ?? const <AccountWithBalance>[];
    final sources = all.where((a) => _kind.sourceKinds.contains(a.account.kind)).toList();
    final source = all.where((a) => a.account.id == _accountId).firstOrNull;
    final targets = all
        .where((a) =>
            _kind.targetKinds.contains(a.account.kind) &&
            a.account.id != _accountId &&
            (source == null || a.account.currency == source.account.currency))
        .toList();
    final cats = _kind == QuickEntryKind.transfer
        ? const <CategoryInfo>[]
        : (ref.watch(categoriesProvider(_kind == QuickEntryKind.income ? 'gelir' : 'gider')).valueOrNull ??
            const <CategoryInfo>[]);

    DropdownButtonFormField<String> accountField(
            String label, List<AccountWithBalance> list, String? value, ValueChanged<String?> onChanged) =>
        DropdownButtonFormField<String>(
          // ignore: deprecated_member_use
          value: list.any((a) => a.account.id == value) ? value : null,
          isExpanded: true,
          decoration: InputDecoration(labelText: label),
          items: [
            for (final a in list)
              DropdownMenuItem(
                value: a.account.id,
                child: Text('${a.account.name} · ${a.account.currency.code}', overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: onChanged,
        );

    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(_e == null ? 'Tekrarlayan işlem' : 'Tekrarlayan işlemi düzenle', style: context.text.headlineSmall),
            Space.gapLg,
            SegmentedButton<QuickEntryKind>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: QuickEntryKind.expense, label: Text('Gider')),
                ButtonSegment(value: QuickEntryKind.income, label: Text('Gelir')),
                ButtonSegment(value: QuickEntryKind.transfer, label: Text('Transfer')),
              ],
              selected: {_kind},
              onSelectionChanged: (s) => setState(() {
                _kind = s.first;
                _categoryId = null;
                _targetId = null;
                if (!sources.any((a) => a.account.id == _accountId)) _accountId = null;
              }),
            ),
            Space.gapMd,
            TextField(
              controller: _name,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                labelText: 'Ad',
                hintText: switch (_kind) {
                  QuickEntryKind.income => 'Maaş',
                  QuickEntryKind.transfer => 'Birikime aktarım',
                  _ => 'Kira, İnternet faturası',
                },
              ),
            ),
            Space.gapMd,
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [_amountFormatter],
              style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
              decoration: InputDecoration(
                labelText: 'Tutar',
                helperText: 'Değişken tutarlarda (fatura) tahmini yaz; kaydederken düzeltebilirsin.',
                suffixText: source?.account.currency.code,
              ),
            ),
            Space.gapMd,
            accountField(
              _kind == QuickEntryKind.income
                  ? 'Paranın gireceği hesap'
                  : (_kind == QuickEntryKind.transfer ? 'Paranın çıkacağı hesap' : 'Ödemenin yapılacağı hesap'),
              sources,
              _accountId,
              (v) => setState(() {
                _accountId = v;
                if (_targetId == v) _targetId = null;
              }),
            ),
            if (_kind == QuickEntryKind.transfer) ...[
              Space.gapMd,
              accountField('Paranın gideceği hesap', targets, _targetId, (v) => setState(() => _targetId = v)),
            ] else ...[
              Space.gapMd,
              DropdownButtonFormField<String>(
                // ignore: deprecated_member_use
                value: cats.any((c) => c.id == _categoryId) ? _categoryId : null,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Kategori'),
                items: [
                  for (final c in cats)
                    DropdownMenuItem(value: c.id, child: Text(c.displayName, overflow: TextOverflow.ellipsis)),
                ],
                onChanged: (v) => setState(() => _categoryId = v),
              ),
            ],
            Space.gapLg,
            Text('Tekrar', style: context.text.labelLarge),
            Space.gapSm,
            Row(children: [
              Expanded(
                child: SegmentedButton<RecurFrequency>(
                  showSelectedIcon: false,
                  segments: [
                    for (final f in RecurFrequency.values) ButtonSegment(value: f, label: Text(f.label)),
                  ],
                  selected: {_freq},
                  onSelectionChanged: (s) => setState(() => _freq = s.first),
                ),
              ),
              Space.gapSm,
              DropdownButton<int>(
                value: _interval,
                items: [
                  for (var i = 1; i <= 12; i++)
                    DropdownMenuItem(value: i, child: Text(i == 1 ? 'Her ${_freq.unit}' : '$i ${_freq.unit}da bir')),
                ],
                onChanged: (v) => setState(() => _interval = v ?? 1),
              ),
            ]),
            Space.gapMd,
            Row(children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    final p = await _pick(_first);
                    if (p != null) setState(() => _first = p);
                  },
                  child: Text('${_e == null ? 'İlk' : 'Sıradaki'}: ${TrFormat.date(_first)}',
                      overflow: TextOverflow.ellipsis),
                ),
              ),
              Space.gapSm,
              Expanded(
                child: OutlinedButton(
                  onPressed: () async {
                    final p = await _pick(_end ?? _first);
                    if (p != null) setState(() => _end = p);
                  },
                  onLongPress: () => setState(() => _end = null),
                  child: Text(_end == null ? 'Bitiş: yok' : 'Bitiş: ${TrFormat.date(_end!)}',
                      overflow: TextOverflow.ellipsis),
                ),
              ),
            ]),
            Text('Bitiş tarihini kaldırmak için düğmeye basılı tut.', style: context.text.bodySmall),
            Space.gapMd,
            TextField(
              controller: _desc,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(labelText: 'Açıklama (isteğe bağlı)'),
            ),
            if (_e != null)
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: _active,
                onChanged: (v) => setState(() => _active = v),
                title: const Text('Etkin'),
                subtitle: const Text('Kapatırsan takvimde ve tahminde görünmez.'),
              ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy ? null : () => _save(all),
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Kaydet'),
            ),
            if (_e != null) ...[
              Space.gapSm,
              TextButton.icon(
                onPressed: _busy ? null : _delete,
                icon: Icon(Icons.delete_outline_rounded, color: context.tokens.expense),
                label: Text('Sil', style: TextStyle(color: context.tokens.expense)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------

Future<void> showBudgetForm(BuildContext context, {BudgetStatus? existing}) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _BudgetForm(existing: existing),
    );

class _BudgetForm extends ConsumerStatefulWidget {
  const _BudgetForm({this.existing});
  final BudgetStatus? existing;

  @override
  ConsumerState<_BudgetForm> createState() => _BudgetFormState();
}

class _BudgetFormState extends ConsumerState<_BudgetForm> {
  late String? _categoryId = widget.existing?.category.id;
  late final _amount = TextEditingController(
      text: widget.existing == null ? '' : MoneyFormat.format(widget.existing!.limit, symbol: false));
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Currency get _currency => widget.existing?.limit.currency ?? ref.read(currentBusinessProvider).baseCurrency;

  Future<void> _save() async {
    if (_categoryId == null) {
      setState(() => _error = 'Kategori seçin.');
      return;
    }
    final Money limit;
    try {
      limit = Money.parse(_amount.text, _currency);
    } on FormatException {
      setState(() => _error = 'Tutar geçersiz.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final repo = ref.read(budgetsRepositoryProvider);
      final old = widget.existing;
      if (old != null && old.category.id != _categoryId) await repo.delete(old.id);
      await repo.set(businessId: ref.read(currentBusinessProvider).id, categoryId: _categoryId!, limit: limit);
      if (mounted) Navigator.pop(context);
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final cats = ref.watch(categoriesProvider('gider')).valueOrNull ?? const <CategoryInfo>[];
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.existing == null ? 'Aylık bütçe' : 'Bütçeyi düzenle', style: context.text.headlineSmall),
          Space.gapLg,
          DropdownButtonFormField<String>(
            // ignore: deprecated_member_use
            value: cats.any((c) => c.id == _categoryId) ? _categoryId : null,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Gider kategorisi',
              helperText: 'Ana kategori seçersen alt kategorileri de sayılır.',
            ),
            items: [
              for (final c in cats) DropdownMenuItem(value: c.id, child: Text(c.displayName, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: (v) => setState(() => _categoryId = v),
          ),
          Space.gapMd,
          TextField(
            controller: _amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [_amountFormatter],
            decoration: InputDecoration(labelText: 'Aylık limit', suffixText: _currency.code),
          ),
          if (_error != null) ...[
            Space.gapMd,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapXl,
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Kaydet'),
          ),
          if (widget.existing != null) ...[
            Space.gapSm,
            TextButton(
              onPressed: _busy
                  ? null
                  : () async {
                      await ref.read(budgetsRepositoryProvider).delete(widget.existing!.id);
                      if (context.mounted) Navigator.pop(context);
                    },
              child: Text('Bütçeyi kaldır', style: TextStyle(color: context.tokens.expense)),
            ),
          ],
        ],
      ),
    );
  }
}
