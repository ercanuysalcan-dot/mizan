import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../loans/presentation/loan_section.dart';
import '../application/planning_providers.dart';
import '../application/planning_service.dart';
import '../data/budgets_repository.dart';
import '../data/recurring_repository.dart';
import 'plan_forms.dart';

/// Plan: nakit akışı tahmini, yaklaşan ödemeler, tekrarlayan işlemler, bütçe.
class PlanScreen extends ConsumerWidget {
  const PlanScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final horizon = ref.watch(planHorizonProvider);
    final snap = ref.watch(planSnapshotProvider);
    final rules = ref.watch(recurringRulesProvider).valueOrNull ?? const <RecurringRule>[];
    final budgets = ref.watch(budgetStatusProvider).valueOrNull ?? const <BudgetStatus>[];
    final now = ref.watch(clockProvider).now();

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: Align(
          alignment: Alignment.topCenter,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(Space.lg, Space.lg, Space.lg, 120),
              children: [
                Row(children: [
                  Icon(Icons.event_note_rounded, color: context.colors.secondary),
                  Space.gapSm,
                  Expanded(child: Text('Plan', style: context.text.headlineMedium)),
                  SegmentedButton<int>(
                    showSelectedIcon: false,
                    segments: const [
                      ButtonSegment(value: 30, label: Text('30 g')),
                      ButtonSegment(value: 60, label: Text('60 g')),
                      ButtonSegment(value: 90, label: Text('90 g')),
                    ],
                    selected: {horizon},
                    onSelectionChanged: (s) => ref.read(planHorizonProvider.notifier).set(s.first),
                  ),
                ]),
                Space.gapLg,
                ...snap.when<List<Widget>>(
                  skipLoadingOnReload: true,
                  loading: () => const [Center(child: Padding(padding: EdgeInsets.all(Space.xl), child: CircularProgressIndicator()))],
                  error: (e, _) => [Text('Plan yüklenemedi: $e')],
                  data: (p) => [
                    _ForecastCard(p: p),
                    Space.gapLg,
                    SectionHeader(
                      'Yaklaşan ödemeler',
                      trailing: Text('${p.horizonDays} gün', style: context.text.labelMedium),
                    ),
                    _UpcomingList(items: p.upcoming, now: now),
                  ],
                ),
                Space.gapLg,
                SectionHeader(
                  'Tekrarlayan işlemler',
                  trailing: TextButton.icon(
                    onPressed: () => showRecurringForm(context),
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: const Text('Ekle'),
                  ),
                ),
                _RulesCard(rules: rules),
                Space.gapLg,
                SectionHeader(
                  'Bütçe (bu ay)',
                  trailing: TextButton.icon(
                    onPressed: () => showBudgetForm(context),
                    icon: const Icon(Icons.add_rounded, size: 18),
                    label: const Text('Ekle'),
                  ),
                ),
                _BudgetsCard(budgets: budgets),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Nakit akışı tahmini

class _ForecastCard extends StatelessWidget {
  const _ForecastCard({required this.p});
  final PlanSnapshot p;

  @override
  Widget build(BuildContext context) {
    final f = p.forecast;
    final t = context.tokens;
    final accent = context.colors.secondary;
    final values = [for (final pt in f.points) pt.balanceMinor / f.currency.minorPerMajor];
    var minV = values.fold<double>(values.first, (a, v) => v < a ? v : a);
    var maxV = values.fold<double>(values.first, (a, v) => v > a ? v : a);
    if (minV > 0) minV = 0;
    if (maxV == minV) maxV = minV + 1;
    final pad = (maxV - minV) * 0.12;

    Widget stat(String label, Money m, {Color? color}) => Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: context.text.labelSmall),
            Text(
              MoneyFormat.format(m),
              style: context.text.titleSmall!.copyWith(color: color, fontFeatures: MizanTheme.tabular),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ]),
        );

    return MizanCard(
      title: 'Nakit akışı tahmini',
      subtitle: 'Kasa + banka (${f.currency.code}) · yaklaşan ödeme ve tahsilatlarla',
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          stat('BUGÜN', f.start),
          stat('${p.horizonDays} GÜN SONRA', f.end, color: f.end.isNegative ? t.expense : null),
          stat('EN DÜŞÜK', f.lowest, color: f.goesNegative ? t.expense : null),
        ]),
        if (f.goesNegative) ...[
          Space.gapMd,
          Container(
            padding: const EdgeInsets.all(Space.md),
            decoration: BoxDecoration(
              color: t.expense.withValues(alpha: 0.10),
              borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
            ),
            child: Row(children: [
              Icon(Icons.warning_amber_rounded, color: t.expense),
              Space.gapSm,
              Expanded(
                child: Text(
                  '${TrFormat.date(f.lowestDay)} civarında nakit eksiye düşüyor '
                  '(${MoneyFormat.format(f.lowest)}). Ödemeleri ya da tahsilatları planla.',
                  style: context.text.bodySmall!.copyWith(color: t.expense),
                ),
              ),
            ]),
          ),
        ],
        Space.gapMd,
        SizedBox(
          height: 170,
          child: LineChart(
            LineChartData(
              minY: minV - pad,
              maxY: maxV + pad,
              borderData: FlBorderData(show: false),
              gridData: FlGridData(
                drawVerticalLine: false,
                getDrawingHorizontalLine: (v) => FlLine(color: t.border, strokeWidth: 1),
              ),
              titlesData: FlTitlesData(
                topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 54,
                    getTitlesWidget: (value, meta) {
                      if (value == meta.max || value == meta.min) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Text(
                          MoneyFormat.compact((value * f.currency.minorPerMajor).round(), f.currency),
                          style: context.text.bodySmall,
                          textAlign: TextAlign.right,
                        ),
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 24,
                    interval: (f.points.length / 4).ceilToDouble(),
                    getTitlesWidget: (value, meta) {
                      final i = value.toInt();
                      if (i < 0 || i >= f.points.length || value != i.toDouble()) return const SizedBox.shrink();
                      return Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(TrFormat.dayMonth(f.points[i].day), style: context.text.bodySmall),
                      );
                    },
                  ),
                ),
              ),
              lineTouchData: LineTouchData(
                touchTooltipData: LineTouchTooltipData(
                  getTooltipColor: (_) => context.colors.inverseSurface,
                  getTooltipItems: (spots) => [
                    for (final sp in spots)
                      LineTooltipItem(
                        '${TrFormat.date(f.points[sp.x.toInt()].day)}\n'
                        '${MoneyFormat.format(Money.fromMinor(f.points[sp.x.toInt()].balanceMinor, f.currency))}',
                        context.text.labelMedium!.copyWith(color: context.colors.onInverseSurface),
                      ),
                  ],
                ),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: [for (var i = 0; i < values.length; i++) FlSpot(i.toDouble(), values[i])],
                  isCurved: false,
                  color: f.goesNegative ? t.expense : accent,
                  barWidth: 2.5,
                  dotData: FlDotData(show: false),
                  belowBarData: BarAreaData(
                    show: true,
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [accent.withValues(alpha: 0.22), accent.withValues(alpha: 0.0)],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Space.gapSm,
        Text(
          'Beklenen giriş ${MoneyFormat.format(f.inflow)} · çıkış ${MoneyFormat.format(f.outflow)}'
          '${f.otherCurrencies > 0 ? ' · ${f.otherCurrencies} hesap başka para biriminde, tahmine katılmadı' : ''}',
          style: context.text.bodySmall,
        ),
      ]),
    );
  }
}

// ---------------------------------------------------------------------------
// Yaklaşan ödemeler

class _UpcomingList extends StatelessWidget {
  const _UpcomingList({required this.items, required this.now});
  final List<UpcomingItem> items;
  final DateTime now;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return const MizanCard(
        child: EmptyState(
          compact: true,
          icon: Icons.event_available_rounded,
          title: 'Yaklaşan ödeme yok',
          message: 'Kredi taksitleri, kart son ödeme günleri ve tekrarlayan işlemler burada görünür.',
        ),
      );
    }
    return MizanCard(
      padding: const EdgeInsets.symmetric(vertical: Space.xs),
      child: Column(children: [
        for (var i = 0; i < items.length; i++) ...[
          if (i > 0) const Divider(height: 1),
          _UpcomingTile(item: items[i], now: now),
        ],
      ]),
    );
  }
}

class _UpcomingTile extends ConsumerWidget {
  const _UpcomingTile({required this.item, required this.now});
  final UpcomingItem item;
  final DateTime now;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.tokens;
    final today = DateTime(now.year, now.month, now.day);
    final overdue = item.date.isBefore(today);
    final soon = !overdue && !item.date.isAfter(DateTime(today.year, today.month, today.day + 3));
    final (icon, sign, color) = switch (item.kind) {
      UpcomingKind.loan => (Icons.request_quote_outlined, '−', t.expense),
      UpcomingKind.card => (Icons.credit_card_rounded, '−', t.expense),
      UpcomingKind.expense => (Icons.south_east_rounded, '−', t.expense),
      UpcomingKind.income => (Icons.north_east_rounded, '+', t.income),
      UpcomingKind.transfer => (Icons.swap_horiz_rounded, '', context.colors.onSurface),
    };

    Widget? action;
    if (item.kind == UpcomingKind.loan && item.loan != null && item.installment != null) {
      action = FilledButton.tonal(
        onPressed: () => showPayInstallmentSheet(context, item.loan!, item.installment!),
        child: const Text('Öde'),
      );
    } else if (item.kind == UpcomingKind.card && item.cardAccountId != null) {
      action = OutlinedButton(
        onPressed: () => context.push('/hesaplar/${item.cardAccountId}'),
        child: const Text('Aç'),
      );
    } else if (item.rule != null && item.isNextOfRule) {
      action = FilledButton.tonal(
        onPressed: () => showPostRecurringSheet(context, item.rule!),
        child: const Text('Kaydet'),
      );
    }

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.xs),
      leading: CircleAvatar(
        radius: 18,
        backgroundColor: (overdue ? t.expense : color).withValues(alpha: 0.12),
        child: Icon(icon, size: 18, color: overdue ? t.expense : color),
      ),
      title: Text(item.title, style: context.text.titleSmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          '${TrFormat.date(item.date)} · ${dueLabel(item.date, now)}',
          style: context.text.bodySmall!.copyWith(
            color: overdue || soon ? t.expense : null,
            fontWeight: overdue ? FontWeight.w600 : null,
          ),
        ),
        Text(item.subtitle, style: context.text.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
      ]),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(
          '$sign${MoneyFormat.format(item.amount)}',
          style: context.text.titleSmall!.copyWith(color: color, fontFeatures: MizanTheme.tabular),
        ),
        if (action != null) ...[Space.gapSm, action],
      ]),
    );
  }
}

// ---------------------------------------------------------------------------
// Tekrarlayan işlemler

class _RulesCard extends StatelessWidget {
  const _RulesCard({required this.rules});
  final List<RecurringRule> rules;

  @override
  Widget build(BuildContext context) {
    if (rules.isEmpty) {
      return MizanCard(
        child: EmptyState(
          compact: true,
          icon: Icons.repeat_rounded,
          title: 'Tekrarlayan işlem yok',
          message: 'Maaş, kira, fatura gibi her ay olan kayıtları bir kez tanımla; günü gelince tek dokunuşla kaydet.',
          action: FilledButton.tonal(
            onPressed: () => showRecurringForm(context),
            child: const Text('Tekrarlayan işlem ekle'),
          ),
        ),
      );
    }
    return MizanCard(
      padding: const EdgeInsets.symmetric(vertical: Space.xs),
      child: Column(children: [
        for (var i = 0; i < rules.length; i++) ...[
          if (i > 0) const Divider(height: 1),
          _RuleTile(rule: rules[i]),
        ],
      ]),
    );
  }
}

class _RuleTile extends StatelessWidget {
  const _RuleTile({required this.rule});
  final RecurringRule rule;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final color = switch (rule.kind.name) {
      'income' => t.income,
      'expense' => t.expense,
      _ => context.colors.onSurface,
    };
    final every = rule.interval == 1 ? rule.frequency.label : 'Her ${rule.interval} ${rule.frequency.unit}';
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg),
      leading: Icon(Icons.repeat_rounded, color: rule.active ? context.colors.secondary : t.subtleText),
      title: Text(rule.name, style: context.text.titleSmall),
      subtitle: Text(
        rule.active ? '$every · ${rule.kind.label} · sıradaki ${TrFormat.date(rule.nextDue)}' : '$every · bitti / durduruldu',
        style: context.text.bodySmall,
      ),
      trailing: Text(MoneyFormat.format(rule.amount),
          style: context.text.titleSmall!.copyWith(color: color, fontFeatures: MizanTheme.tabular)),
      onTap: () => showRecurringForm(context, existing: rule),
    );
  }
}

// ---------------------------------------------------------------------------
// Bütçe

class _BudgetsCard extends StatelessWidget {
  const _BudgetsCard({required this.budgets});
  final List<BudgetStatus> budgets;

  @override
  Widget build(BuildContext context) {
    if (budgets.isEmpty) {
      return MizanCard(
        child: EmptyState(
          compact: true,
          icon: Icons.savings_outlined,
          title: 'Bütçe yok',
          message: 'Kategori başına aylık limit koy (örn. Market 10.000 ₺); dolmaya yaklaşınca burada uyarı görürsün.',
          action: FilledButton.tonal(onPressed: () => showBudgetForm(context), child: const Text('Bütçe ekle')),
        ),
      );
    }
    final t = context.tokens;
    return MizanCard(
      child: Column(children: [
        for (var i = 0; i < budgets.length; i++) ...[
          if (i > 0) const Divider(height: Space.xl),
          InkWell(
            onTap: () => showBudgetForm(context, existing: budgets[i]),
            child: Builder(builder: (context) {
              final b = budgets[i];
              final color = b.isOver ? t.expense : (b.isWarning ? t.warning : t.income);
              return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Row(children: [
                  Expanded(child: Text(b.category.displayName, style: context.text.titleSmall)),
                  Text('${MoneyFormat.format(b.spent)} / ${MoneyFormat.format(b.limit)}',
                      style: context.text.labelMedium!.copyWith(fontFeatures: MizanTheme.tabular)),
                ]),
                Space.gapSm,
                ClipRRect(
                  borderRadius: Radii.pill,
                  child: LinearProgressIndicator(
                    value: b.ratio > 1 ? 1 : b.ratio,
                    minHeight: 8,
                    color: color,
                    backgroundColor: t.mutedSurface,
                  ),
                ),
                Space.gapXs,
                Text(
                  b.isOver
                      ? 'Bütçe ${MoneyFormat.format(-b.remaining)} aşıldı'
                      : '%${(b.ratio * 100).round()} kullanıldı · kalan ${MoneyFormat.format(b.remaining)}',
                  style: context.text.bodySmall!.copyWith(color: b.isOver || b.isWarning ? color : null),
                ),
              ]);
            }),
          ),
        ],
      ]),
    );
  }
}

/// Tekrarlayan işlemi kaydetme (tutar ve tarih düzeltilebilir).
Future<void> showPostRecurringSheet(BuildContext context, RecurringRule rule) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _PostSheet(rule: rule),
    );

class _PostSheet extends ConsumerStatefulWidget {
  const _PostSheet({required this.rule});
  final RecurringRule rule;

  @override
  ConsumerState<_PostSheet> createState() => _PostSheetState();
}

class _PostSheetState extends ConsumerState<_PostSheet> {
  late final _amount = TextEditingController(text: MoneyFormat.format(widget.rule.amount, symbol: false));
  late DateTime _date = widget.rule.nextDue;
  final _key = 'tekrar:${newId()}';
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Future<void> _run(bool skip) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = ref.read(recurringRepositoryProvider);
    try {
      if (skip) {
        await repo.skip(widget.rule.id);
      } else {
        await repo.post(
          businessId: ref.read(currentBusinessProvider).id,
          ruleId: widget.rule.id,
          amountText: _amount.text,
          date: _date,
          idempotencyKey: _key,
        );
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(skip ? '“${widget.rule.name}” bu sefer atlandı.' : '“${widget.rule.name}” kaydedildi.'),
      ));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.rule.name, style: context.text.headlineSmall),
          Space.gapXs,
          Text('${widget.rule.kind.label} · ${widget.rule.frequency.label}', style: context.text.bodySmall),
          Space.gapLg,
          TextField(
            controller: _amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
            decoration: InputDecoration(
              labelText: 'Tutar',
              helperText: 'Bu ay farklıysa düzelt (örn. fatura).',
              suffixText: widget.rule.amount.currency.code,
            ),
          ),
          Space.gapMd,
          OutlinedButton.icon(
            icon: const Icon(Icons.event_outlined, size: 18),
            label: Text('Tarih: ${TrFormat.date(_date)}'),
            onPressed: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(2000),
                lastDate: DateTime(_date.year + 5),
              );
              if (picked != null) setState(() => _date = DateTime(picked.year, picked.month, picked.day, 12));
            },
          ),
          if (_error != null) ...[
            Space.gapMd,
            Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
          ],
          Space.gapXl,
          FilledButton(
            onPressed: _busy ? null : () => _run(false),
            child: _busy
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Deftere kaydet'),
          ),
          Space.gapSm,
          TextButton(onPressed: _busy ? null : () => _run(true), child: const Text('Bu seferlik atla')),
        ],
      ),
    );
  }
}
