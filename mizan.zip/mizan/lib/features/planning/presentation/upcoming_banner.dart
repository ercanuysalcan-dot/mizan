import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../design_system/design_system.dart';
import '../application/planning_providers.dart';
import '../application/planning_service.dart';

/// Genel Bakış'ta: önümüzdeki 7 günün ödemeleri ve gecikenler. Dokununca Plan açılır.
class UpcomingBanner extends ConsumerWidget {
  const UpcomingBanner({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final p = ref.watch(planSnapshotProvider).valueOrNull;
    if (p == null) return const SizedBox.shrink();
    final now = ref.watch(clockProvider).now();
    final today = DateTime(now.year, now.month, now.day);
    final week = DateTime(today.year, today.month, today.day + 7);
    final overdue = p.upcoming.where((u) => u.cashEffect < 0 && u.date.isBefore(today)).toList();
    final soon = p.upcoming.where((u) => u.cashEffect < 0 && !u.date.isBefore(today) && !u.date.isAfter(week)).toList();
    if (overdue.isEmpty && soon.isEmpty && !p.forecast.goesNegative) return const SizedBox.shrink();

    final base = p.forecast.currency;
    int sum(Iterable<UpcomingItem> xs) =>
        xs.where((u) => u.amount.currency == base).fold<int>(0, (a, u) => a + u.amount.minor);
    final t = context.tokens;
    final alert = overdue.isNotEmpty || p.forecast.goesNegative;
    final parts = <String>[
      if (overdue.isNotEmpty) '${overdue.length} gecikmiş ödeme',
      if (soon.isNotEmpty) 'Bu hafta ${soon.length} ödeme · ${MoneyFormat.format(Money.fromMinor(sum(soon), base))}',
      if (p.forecast.goesNegative) '${p.horizonDays} gün içinde nakit eksiye düşebilir',
    ];
    return Padding(
      padding: const EdgeInsets.only(bottom: Space.lg),
      child: Material(
        color: (alert ? t.expense : context.colors.secondary).withValues(alpha: 0.10),
        borderRadius: const BorderRadius.all(Radius.circular(Radii.md)),
        child: InkWell(
          borderRadius: const BorderRadius.all(Radius.circular(Radii.md)),
          onTap: () => context.go('/plan'),
          child: Padding(
            padding: const EdgeInsets.all(Space.md),
            child: Row(children: [
              Icon(alert ? Icons.warning_amber_rounded : Icons.event_note_rounded,
                  color: alert ? t.expense : context.colors.secondary),
              Space.gapMd,
              Expanded(child: Text(parts.join('\n'), style: context.text.bodyMedium)),
              const Icon(Icons.chevron_right_rounded),
            ]),
          ),
        ),
      ),
    );
  }
}
