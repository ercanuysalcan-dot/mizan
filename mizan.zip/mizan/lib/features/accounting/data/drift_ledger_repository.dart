import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../domain/account_kind.dart';
import '../domain/ledger_models.dart';
import '../domain/ledger_repository.dart';

/// Drift/SQLite üzerinde çift kayıtlı muhasebe motoru.
///
/// Savunma katmanları:
///  1. Dart tarafında istek doğrulaması (bu sınıf).
///  2. Veritabanı tetikleyicileri (core.drift): denge, değişmezlik,
///     para birimi eşleşmesi, durum akışı.
///  3. Benzersiz indeksler: idempotency anahtarı, tek iptal.
class DriftLedgerRepository implements LedgerRepository {
  DriftLedgerRepository(this._db, {required this.deviceId, Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final String deviceId;
  final Clock _clock;

  @override
  Future<String> post(PostingRequest r) async {
    _validateShape(r);
    try {
      return await _db.transaction(() async {
        final existing = await _findByKey(r.businessId, r.idempotencyKey);
        if (existing != null) return existing;

        final accounts = await _loadAccounts(r.lines.map((l) => l.accountId).toSet());
        for (final line in r.lines) {
          final a = accounts[line.accountId];
          if (a == null) throw LedgerException.of('LEDGER_INVALID', 'Hesap bulunamadı.');
          if (a.businessId != r.businessId) {
            throw LedgerException.of('LEDGER_ACCOUNT_MISMATCH');
          }
          if (a.currency != line.amount.currency) {
            throw LedgerException.of('LEDGER_ACCOUNT_MISMATCH',
                '"${a.name}" hesabı ${a.currency.code}; satır ${line.amount.currency.code}.');
          }
          if (a.archived) throw LedgerException.of('ACCOUNT_ARCHIVED');
        }

        final id = newId();
        await _insertEntry(
          id: id,
          businessId: r.businessId,
          type: r.type,
          dateMs: r.date.toUtc().millisecondsSinceEpoch,
          description: r.description,
          key: r.idempotencyKey,
        );
        await _insertLines(id, r.businessId, r.lines);
        await _setStatus(id, 'posted');
        await _audit(
          businessId: r.businessId,
          table: 'journal_entries',
          recordId: id,
          action: 'post',
          after: {
            'type': r.type.code,
            'date': r.date.toIso8601String(),
            'description': r.description,
            'lines': [
              for (final l in r.lines)
                {'account': l.accountId, 'side': l.side.code, 'amount': l.amount.toString()}
            ],
          },
        );
        return id;
      });
    } catch (e) {
      // Eşzamanlı/yinelenen gönderim: benzersiz indeks yakaladıysa ilk kaydı döndür.
      if (e.toString().contains('journal_entries.idempotency_key')) {
        final existing = await _findByKey(r.businessId, r.idempotencyKey);
        if (existing != null) return existing;
      }
      throw _translate(e);
    }
  }

  @override
  Future<String> reverse({
    required String entryId,
    required String idempotencyKey,
    String? reason,
  }) async {
    try {
      return await _db.transaction(() async {
        final original = await _db.customSelect(
          'SELECT business_id, entry_type, entry_date, description, status '
          'FROM journal_entries WHERE id = ?',
          variables: [Variable.withString(entryId)],
        ).getSingleOrNull();
        if (original == null) throw LedgerException.of('LEDGER_NOT_FOUND');
        final businessId = original.read<String>('business_id');

        final existing = await _findByKey(businessId, idempotencyKey);
        if (existing != null) return existing;

        final status = original.read<String>('status');
        if (status == 'reversed') throw LedgerException.of('LEDGER_ALREADY_REVERSED');
        if (status != 'posted') throw LedgerException.of('LEDGER_BAD_STATUS');
        if (original.read<String>('entry_type') == EntryType.iptal.code) {
          throw LedgerException.of('LEDGER_INVALID', 'İptal kaydı tekrar iptal edilemez.');
        }

        final lineRows = await _db.customSelect(
          'SELECT account_id, currency, debit_minor, credit_minor, quantity_micro, memo '
          'FROM journal_lines WHERE entry_id = ? ORDER BY line_no',
          variables: [Variable.withString(entryId)],
        ).get();

        final reversedLines = [
          for (final row in lineRows)
            PostingLine(
              accountId: row.read<String>('account_id'),
              // Yönler ters çevrilir: borç ↔ alacak
              side: row.read<int>('debit_minor') > 0 ? EntrySide.credit : EntrySide.debit,
              amount: Money.fromMinor(
                row.read<int>('debit_minor') + row.read<int>('credit_minor'),
                Currency.fromCode(row.read<String>('currency')),
              ),
              quantityMicro: row.readNullable<int>('quantity_micro'),
              memo: row.readNullable<String>('memo'),
            ),
        ];

        final id = newId();
        final desc = original.readNullable<String>('description');
        await _insertEntry(
          id: id,
          businessId: businessId,
          type: EntryType.iptal,
          dateMs: original.read<int>('entry_date'),
          description: 'İptal: ${desc ?? EntryType.fromCode(original.read<String>('entry_type')).label}'
              '${reason == null || reason.isEmpty ? '' : ' — $reason'}',
          key: idempotencyKey,
          reverses: entryId,
        );
        await _insertLines(id, businessId, reversedLines);
        await _setStatus(id, 'posted');
        await _setStatus(entryId, 'reversed');
        await _audit(
          businessId: businessId,
          table: 'journal_entries',
          recordId: entryId,
          action: 'reverse',
          before: {'status': 'posted'},
          after: {'status': 'reversed', 'reversal_entry_id': id},
          reason: reason,
        );
        return id;
      });
    } catch (e) {
      throw _translate(e);
    }
  }

  @override
  Future<List<AccountBalance>> balances(String businessId, {DateTime? asOf}) async {
    final rows = await _db.customSelect(
      '''
      SELECT a.id, a.kind, a.currency,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.debit_minor END), 0) AS d,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.credit_minor END), 0) AS c
      FROM accounts a
      LEFT JOIN journal_lines l ON l.account_id = a.id
      LEFT JOIN journal_entries e
        ON e.id = l.entry_id AND e.status <> 'draft' AND e.entry_date < ?
      WHERE a.business_id = ? AND a.deleted_at IS NULL
      GROUP BY a.id, a.kind, a.currency
      ''',
      variables: [
        Variable.withInt(asOf?.toUtc().millisecondsSinceEpoch ?? Money.maxMinor),
        Variable.withString(businessId),
      ],
    ).get();
    return [
      for (final r in rows)
        AccountBalance(
          accountId: r.read<String>('id'),
          kind: AccountKind.fromCode(r.read<String>('kind')),
          currency: Currency.fromCode(r.read<String>('currency')),
          debitMinor: r.read<int>('d'),
          creditMinor: r.read<int>('c'),
        ),
    ];
  }

  @override
  Future<AccountBalance> balanceOf(String accountId) async {
    final r = await _db.customSelect(
      '''
      SELECT a.id, a.kind, a.currency,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.debit_minor END), 0) AS d,
        COALESCE(SUM(CASE WHEN e.id IS NOT NULL THEN l.credit_minor END), 0) AS c
      FROM accounts a
      LEFT JOIN journal_lines l ON l.account_id = a.id
      LEFT JOIN journal_entries e ON e.id = l.entry_id AND e.status <> 'draft'
      WHERE a.id = ?
      GROUP BY a.id, a.kind, a.currency
      ''',
      variables: [Variable.withString(accountId)],
    ).getSingleOrNull();
    if (r == null) throw LedgerException.of('LEDGER_INVALID', 'Hesap bulunamadı.');
    return AccountBalance(
      accountId: accountId,
      kind: AccountKind.fromCode(r.read<String>('kind')),
      currency: Currency.fromCode(r.read<String>('currency')),
      debitMinor: r.read<int>('d'),
      creditMinor: r.read<int>('c'),
    );
  }

  @override
  Future<LedgerAccount> account(String accountId) async {
    final m = await _loadAccounts({accountId});
    final a = m[accountId];
    if (a == null) throw LedgerException.of('LEDGER_INVALID', 'Hesap bulunamadı.');
    return a;
  }

  @override
  Future<List<LedgerIssue>> verifyIntegrity(String businessId) async {
    final issues = <LedgerIssue>[];
    final unbalanced = await _db.customSelect(
      '''
      SELECT e.id, l.currency, SUM(l.debit_minor) AS d, SUM(l.credit_minor) AS c
      FROM journal_entries e JOIN journal_lines l ON l.entry_id = e.id
      WHERE e.business_id = ? AND e.status <> 'draft'
      GROUP BY e.id, l.currency HAVING SUM(l.debit_minor) <> SUM(l.credit_minor)
      ''',
      variables: [Variable.withString(businessId)],
    ).get();
    for (final r in unbalanced) {
      issues.add(LedgerIssue(r.read<String>('id'),
          '${r.read<String>('currency')} dengesiz: B ${r.read<int>('d')} / A ${r.read<int>('c')}'));
    }
    final orphanReversed = await _db.customSelect(
      '''
      SELECT e.id FROM journal_entries e
      WHERE e.business_id = ? AND e.status = 'reversed'
        AND NOT EXISTS (SELECT 1 FROM journal_entries r
                        WHERE r.reverses_entry_id = e.id AND r.status = 'posted')
      ''',
      variables: [Variable.withString(businessId)],
    ).get();
    for (final r in orphanReversed) {
      issues.add(LedgerIssue(r.read<String>('id'), 'İptal edilmiş ama ters kaydı yok'));
    }
    final drafts = await _db.customSelect(
      "SELECT id FROM journal_entries WHERE business_id = ? AND status = 'draft'",
      variables: [Variable.withString(businessId)],
    ).get();
    for (final r in drafts) {
      issues.add(LedgerIssue(r.read<String>('id'), 'Kesinleşmemiş taslak kayıt'));
    }
    return issues;
  }

  // ---------------------------------------------------------------- yardımcılar

  void _validateShape(PostingRequest r) {
    if (r.lines.length < 2) {
      throw LedgerException.of('LEDGER_UNBALANCED', 'Bir işlem en az iki satırdan oluşur.');
    }
    if (r.idempotencyKey.trim().isEmpty) {
      throw LedgerException.of('LEDGER_INVALID', 'İşlem anahtarı eksik.');
    }
    if (r.type == EntryType.iptal) {
      throw LedgerException.of('LEDGER_INVALID', 'İptal kaydı yalnızca reverse() ile oluşturulur.');
    }
    final totals = <Currency, int>{};
    for (final l in r.lines) {
      if (!l.amount.isPositive) {
        throw LedgerException.of('LEDGER_INVALID', 'Satır tutarı sıfırdan büyük olmalı.');
      }
      final signed = l.side == EntrySide.debit ? l.amount.minor : -l.amount.minor;
      totals[l.amount.currency] = (totals[l.amount.currency] ?? 0) + signed;
    }
    if (totals.values.any((v) => v != 0)) throw LedgerException.of('LEDGER_UNBALANCED');
  }

  Future<String?> _findByKey(String businessId, String key) async {
    final row = await _db.customSelect(
      'SELECT id FROM journal_entries WHERE business_id = ? AND idempotency_key = ?',
      variables: [Variable.withString(businessId), Variable.withString(key)],
    ).getSingleOrNull();
    return row?.read<String>('id');
  }

  Future<Map<String, LedgerAccount>> _loadAccounts(Set<String> ids) async {
    if (ids.isEmpty) return const {};
    final placeholders = List.filled(ids.length, '?').join(',');
    final rows = await _db.customSelect(
      'SELECT id, business_id, kind, name, currency, archived, category_id, system_role '
      'FROM accounts WHERE id IN ($placeholders) AND deleted_at IS NULL',
      variables: [for (final id in ids) Variable.withString(id)],
    ).get();
    return {
      for (final r in rows)
        r.read<String>('id'): LedgerAccount(
          id: r.read<String>('id'),
          businessId: r.read<String>('business_id'),
          kind: AccountKind.fromCode(r.read<String>('kind')),
          name: r.read<String>('name'),
          currency: Currency.fromCode(r.read<String>('currency')),
          archived: r.read<int>('archived') == 1,
          categoryId: r.readNullable<String>('category_id'),
          systemRole: r.readNullable<String>('system_role'),
        ),
    };
  }

  Future<void> _insertEntry({
    required String id,
    required String businessId,
    required EntryType type,
    required int dateMs,
    required String? description,
    required String key,
    String? reverses,
  }) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO journal_entries (id, business_id, entry_type, entry_date, description, status, '
      'idempotency_key, reverses_entry_id, created_at, updated_at, device_id) '
      "VALUES (?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(id),
        Variable.withString(businessId),
        Variable.withString(type.code),
        Variable.withInt(dateMs),
        Variable<String>(description),
        Variable.withString(key),
        Variable<String>(reverses),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }

  Future<void> _insertLines(String entryId, String businessId, List<PostingLine> lines) async {
    final now = _clock.nowMs();
    for (var i = 0; i < lines.length; i++) {
      final l = lines[i];
      await _db.customInsert(
        'INSERT INTO journal_lines (id, entry_id, business_id, line_no, account_id, currency, '
        'debit_minor, credit_minor, quantity_micro, memo, created_at, updated_at, device_id) '
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(newId()),
          Variable.withString(entryId),
          Variable.withString(businessId),
          Variable.withInt(i + 1),
          Variable.withString(l.accountId),
          Variable.withString(l.amount.currency.code),
          Variable.withInt(l.side == EntrySide.debit ? l.amount.minor : 0),
          Variable.withInt(l.side == EntrySide.credit ? l.amount.minor : 0),
          Variable<int>(l.quantityMicro),
          Variable<String>(l.memo),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
    }
  }

  Future<void> _setStatus(String entryId, String status) async {
    await _db.customUpdate(
      'UPDATE journal_entries SET status = ?, updated_at = ?, sync_status = 0, '
      'version = version + 1 WHERE id = ?',
      variables: [
        Variable.withString(status),
        Variable.withInt(_clock.nowMs()),
        Variable.withString(entryId),
      ],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  Future<void> _audit({
    required String businessId,
    required String table,
    required String recordId,
    required String action,
    Map<String, Object?>? before,
    Map<String, Object?>? after,
    String? reason,
  }) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, '
      'after_json, reason, occurred_at, created_at, updated_at, device_id) '
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(table),
        Variable.withString(recordId),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable<String>(after == null ? null : jsonEncode(after)),
        Variable<String>(reason),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }

  Object _translate(Object e) {
    if (e is LedgerException) return e;
    return LedgerException.fromDatabaseError(e) ?? e;
  }
}
