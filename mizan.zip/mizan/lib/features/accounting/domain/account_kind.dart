/// Defterdeki satır yönü. D = borç (debit), C = alacak (credit).
enum EntrySide {
  debit('D'),
  credit('C');

  const EntrySide(this.code);
  final String code;

  static EntrySide fromCode(String c) => c == 'D' ? debit : credit;
}

/// Hesap türleri ve bakiye yönleri.
///
/// | Tür          | Sınıf    | Normal yön | Pozitif bakiye anlamı                  |
/// |--------------|----------|------------|----------------------------------------|
/// | kasa         | Varlık   | D          | Kasadaki nakit                         |
/// | banka        | Varlık   | D          | Hesaptaki para                         |
/// | birikim      | Varlık   | D          | Birikimin maliyet değeri               |
/// | stok         | Varlık   | D          | Depodaki stok değeri                   |
/// | cari         | Varlık   | D          | Alacak (karşı taraf bize borçlu)       |
/// |              |          |            | Negatif = borç (biz borçluyuz)         |
/// | kredi_karti  | Borç     | C          | Kart borcu                             |
/// | kredi        | Borç     | C          | Kalan kredi borcu (taksitli)           |
/// | personel     | Borç     | C          | Personele ödenecek tutar               |
/// |              |          |            | Negatif = verilen avans (alacak)       |
/// | gelir        | Gelir    | C          | Dönem geliri                           |
/// | gider        | Gider    | D          | Dönem gideri                           |
/// | ozkaynak     | Özkaynak | C          | Açılış bakiyeleri karşılığı            |
/// | kur_farki    | Sistem   | D          | Döviz çevrim ara hesabı                |
enum AccountKind {
  cari('cari', EntrySide.debit, 'Cari (Borç / Alacak)', true),
  banka('banka', EntrySide.debit, 'Banka', true),
  krediKarti('kredi_karti', EntrySide.credit, 'Kredi Kartı', true),
  kredi('kredi', EntrySide.credit, 'Banka Kredisi', true),
  stok('stok', EntrySide.debit, 'Stok', true),
  personel('personel', EntrySide.credit, 'Personel', true),
  birikim('birikim', EntrySide.debit, 'Birikim', true),
  kasa('kasa', EntrySide.debit, 'Nakit (Kasa)', true),
  gelir('gelir', EntrySide.credit, 'Gelir', false),
  gider('gider', EntrySide.debit, 'Gider', false),
  ozkaynak('ozkaynak', EntrySide.credit, 'Özkaynak', false),
  kurFarki('kur_farki', EntrySide.debit, 'Kur Farkı', false);

  const AccountKind(this.code, this.normalSide, this.label, this.userFacing);

  final String code;
  final EntrySide normalSide;
  final String label;

  /// "Yeni hesap" ekranında listelenen 8 tür.
  final bool userFacing;

  static List<AccountKind> get creatable => values.where((k) => k.userFacing).toList();

  static AccountKind fromCode(String code) =>
      values.firstWhere((k) => k.code == code, orElse: () => throw ArgumentError(code));

  /// Kasa/banka gibi "para tutan" hesaplar (gelir/gider karşı hesabı olabilir).
  bool get holdsMoney => this == kasa || this == banka;

  /// Satır toplamlarından imzalı bakiye: normal yönde pozitif.
  int signedBalance(int debit, int credit) =>
      normalSide == EntrySide.debit ? debit - credit : credit - debit;
}
