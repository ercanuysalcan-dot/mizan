import '../../../core/money/money.dart';
import 'account_kind.dart';

/// İşlem türleri (journal_entries.entry_type).
enum EntryType {
  acilis('acilis', 'Açılış bakiyesi'),
  gelir('gelir', 'Gelir'),
  gider('gider', 'Gider'),
  transfer('transfer', 'Transfer'),
  kartHarcama('kart_harcama', 'Kart harcaması'),
  kartOdeme('kart_odeme', 'Kart ödemesi'),
  tahsilat('tahsilat', 'Tahsilat'),
  odeme('odeme', 'Ödeme'),
  borc('borc', 'Borç kaydı'),
  alacak('alacak', 'Alacak kaydı'),
  maas('maas', 'Maaş'),
  avans('avans', 'Avans'),
  stok('stok', 'Stok'),
  duzeltme('duzeltme', 'Düzeltme'),
  iptal('iptal', 'İptal kaydı');

  const EntryType(this.code, this.label);
  final String code;
  final String label;

  static EntryType fromCode(String c) =>
      values.firstWhere((t) => t.code == c, orElse: () => throw ArgumentError(c));
}

/// Muhasebe motorunun bildiği hesap özeti.
class LedgerAccount {
  const LedgerAccount({
    required this.id,
    required this.businessId,
    required this.kind,
    required this.name,
    required this.currency,
    this.archived = false,
    this.categoryId,
    this.systemRole,
  });

  final String id;
  final String businessId;
  final AccountKind kind;
  final String name;
  final Currency currency;
  final bool archived;
  final String? categoryId;
  final String? systemRole;
}

class PostingLine {
  const PostingLine({
    required this.accountId,
    required this.side,
    required this.amount,
    this.quantityMicro,
    this.memo,
  });

  factory PostingLine.debit(LedgerAccount a, Money m, {String? memo}) =>
      PostingLine(accountId: a.id, side: EntrySide.debit, amount: m, memo: memo);

  factory PostingLine.credit(LedgerAccount a, Money m, {String? memo}) =>
      PostingLine(accountId: a.id, side: EntrySide.credit, amount: m, memo: memo);

  final String accountId;
  final EntrySide side;

  /// Her zaman pozitif. Yön [side] ile belirlenir.
  final Money amount;
  final int? quantityMicro;
  final String? memo;
}

/// Deftere işlenecek işlem isteği.
class PostingRequest {
  const PostingRequest({
    required this.businessId,
    required this.type,
    required this.date,
    required this.idempotencyKey,
    required this.lines,
    this.description,
  });

  final String businessId;
  final EntryType type;
  final DateTime date;

  /// Aynı form gönderimi için sabit anahtar. Çift tıklama ve senkron
  /// tekrarlarında işlem ikinci kez kaydedilmez.
  final String idempotencyKey;
  final List<PostingLine> lines;
  final String? description;
}

class AccountBalance {
  const AccountBalance({
    required this.accountId,
    required this.kind,
    required this.currency,
    required this.debitMinor,
    required this.creditMinor,
  });

  final String accountId;
  final AccountKind kind;
  final Currency currency;
  final int debitMinor;
  final int creditMinor;

  /// Normal yönde pozitif bakiye.
  Money get balance => Money.fromMinor(kind.signedBalance(debitMinor, creditMinor), currency);
}

/// [LedgerRepository.verifyIntegrity] çıktısı.
class LedgerIssue {
  const LedgerIssue(this.entryId, this.message);
  final String entryId;
  final String message;
  @override
  String toString() => '$entryId: $message';
}
