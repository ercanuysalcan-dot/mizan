import 'ledger_models.dart';

/// Merkezi muhasebe motoru sözleşmesi. Tüm finansal hareketler buradan geçer.
abstract interface class LedgerRepository {
  /// İşlemi tek bir atomik veritabanı işleminde deftere yazar.
  /// Aynı [PostingRequest.idempotencyKey] ile ikinci çağrı yeni kayıt
  /// oluşturmaz, ilk kaydın kimliğini döner.
  Future<String> post(PostingRequest request);

  /// Kesinleşmiş işlemi ters kayıtla iptal eder. Orijinal kayıt silinmez,
  /// durumu `reversed` olur; ters kayıt aynı tarihle yazılır, böylece dönem
  /// raporları iptalden sonra da doğru kalır.
  Future<String> reverse({required String entryId, required String idempotencyKey, String? reason});

  /// Tüm hesapların [asOf] anından önceki işlemlere göre bakiyesi.
  /// Bakiyeler önbellekten değil, doğrudan defter satırlarından hesaplanır.
  Future<List<AccountBalance>> balances(String businessId, {DateTime? asOf});

  Future<AccountBalance> balanceOf(String accountId);

  Future<LedgerAccount> account(String accountId);

  /// Defterin bütünlüğünü baştan doğrular (dengesizlik, yarım iptal vb.).
  Future<List<LedgerIssue>> verifyIntegrity(String businessId);
}
