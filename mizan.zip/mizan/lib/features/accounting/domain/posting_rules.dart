import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import 'account_kind.dart';
import 'ledger_models.dart';

/// İş olaylarını çift kayıt satırlarına çeviren saf kurallar.
///
/// Tüm finansal işlemler buradan üretilip [LedgerRepository.post] ile
/// tek bir atomik işlemde deftere yazılır. Kurallar yan etkisizdir ve
/// birim testleriyle doğrulanır.
abstract final class PostingRules {
  /// Gelir: para hesabı (kasa/banka) artar, gelir kategorisi artar.
  /// D para hesabı / C gelir
  static List<PostingLine> income({
    required LedgerAccount moneyAccount,
    required LedgerAccount incomeAccount,
    required Money amount,
  }) {
    _expectKind(incomeAccount, {AccountKind.gelir});
    _expectKind(moneyAccount, {AccountKind.kasa, AccountKind.banka});
    _check([moneyAccount, incomeAccount], amount);
    return [PostingLine.debit(moneyAccount, amount), PostingLine.credit(incomeAccount, amount)];
  }

  /// Gider: gider kategorisi artar; ödeme hesabı kasa/banka ise azalır,
  /// kredi kartı ise kart borcu artar (kart harcaması).
  /// D gider / C kasa|banka|kredi kartı
  static List<PostingLine> expense({
    required LedgerAccount paidFrom,
    required LedgerAccount expenseAccount,
    required Money amount,
  }) {
    _expectKind(expenseAccount, {AccountKind.gider});
    _expectKind(paidFrom, {AccountKind.kasa, AccountKind.banka, AccountKind.krediKarti});
    _check([paidFrom, expenseAccount], amount);
    return [PostingLine.debit(expenseAccount, amount), PostingLine.credit(paidFrom, amount)];
  }

  /// Hesaplar arası transfer. Toplam varlığı değiştirmez.
  /// Hedef kredi kartıysa bu bir kart ödemesidir (kart borcu azalır);
  /// kaynak kredi kartıysa nakit avanstır (kart borcu artar).
  /// D hedef / C kaynak
  static List<PostingLine> transfer({
    required LedgerAccount from,
    required LedgerAccount to,
    required Money amount,
  }) {
    const allowed = {AccountKind.kasa, AccountKind.banka, AccountKind.birikim, AccountKind.krediKarti};
    _expectKind(from, allowed);
    _expectKind(to, allowed);
    if (from.id == to.id) {
      throw LedgerException.of('LEDGER_INVALID', 'Kaynak ve hedef hesap aynı olamaz.');
    }
    if (from.currency != to.currency) {
      throw LedgerException.of('LEDGER_INVALID',
          'Farklı para birimleri arası transfer (döviz çevirme) sonraki aşamada eklenecek.');
    }
    _check([from, to], amount);
    return [PostingLine.debit(to, amount), PostingLine.credit(from, amount)];
  }

  /// Transferin türünü belirler (raporlarda doğru görünmesi için).
  static EntryType transferType(LedgerAccount from, LedgerAccount to) =>
      to.kind == AccountKind.krediKarti ? EntryType.kartOdeme : EntryType.transfer;

  /// Cari tahsilat: cariden para alındı. Cari alacağı azalır, para hesabı artar.
  /// D kasa|banka / C cari
  static List<PostingLine> collection({
    required LedgerAccount cari,
    required LedgerAccount moneyAccount,
    required Money amount,
  }) {
    _expectKind(cari, {AccountKind.cari});
    _expectKind(moneyAccount, {AccountKind.kasa, AccountKind.banka});
    _check([cari, moneyAccount], amount);
    return [PostingLine.debit(moneyAccount, amount), PostingLine.credit(cari, amount)];
  }

  /// Cari ödeme: cariye para ödendi. Cariye borcumuz azalır, para hesabı azalır.
  /// D cari / C kasa|banka
  static List<PostingLine> payment({
    required LedgerAccount cari,
    required LedgerAccount moneyAccount,
    required Money amount,
  }) {
    _expectKind(cari, {AccountKind.cari});
    _expectKind(moneyAccount, {AccountKind.kasa, AccountKind.banka});
    _check([cari, moneyAccount], amount);
    return [PostingLine.debit(cari, amount), PostingLine.credit(moneyAccount, amount)];
  }

  /// Veresiye satış (alacak kaydı): D cari / C gelir
  static List<PostingLine> receivable({
    required LedgerAccount cari,
    required LedgerAccount incomeAccount,
    required Money amount,
  }) {
    _expectKind(cari, {AccountKind.cari});
    _expectKind(incomeAccount, {AccountKind.gelir});
    _check([cari, incomeAccount], amount);
    return [PostingLine.debit(cari, amount), PostingLine.credit(incomeAccount, amount)];
  }

  /// Veresiye alış (borç kaydı): D gider / C cari
  static List<PostingLine> payable({
    required LedgerAccount cari,
    required LedgerAccount expenseAccount,
    required Money amount,
  }) {
    _expectKind(cari, {AccountKind.cari});
    _expectKind(expenseAccount, {AccountKind.gider});
    _check([cari, expenseAccount], amount);
    return [PostingLine.debit(expenseAccount, amount), PostingLine.credit(cari, amount)];
  }

  /// Açılış bakiyesi. [inNormalDirection] true ise hesabın normal yönünde
  /// bakiye oluşur (kasa: para var, kart: borç var). Cari için false
  /// "biz borçluyuz" anlamına gelir.
  static List<PostingLine> opening({
    required LedgerAccount account,
    required LedgerAccount equity,
    required Money amount,
    bool inNormalDirection = true,
  }) {
    _expectKind(equity, {AccountKind.ozkaynak});
    _check([account, equity], amount);
    final accountSide = inNormalDirection
        ? account.kind.normalSide
        : (account.kind.normalSide == EntrySide.debit ? EntrySide.credit : EntrySide.debit);
    final equitySide = accountSide == EntrySide.debit ? EntrySide.credit : EntrySide.debit;
    return [
      PostingLine(accountId: account.id, side: accountSide, amount: amount),
      PostingLine(accountId: equity.id, side: equitySide, amount: amount),
    ];
  }

  // --------------------------------------------------------------------------
  static void _expectKind(LedgerAccount a, Set<AccountKind> kinds) {
    if (!kinds.contains(a.kind)) {
      throw LedgerException.of('LEDGER_INVALID', '"${a.name}" bu işlem için uygun hesap türü değil.');
    }
  }

  static void _check(List<LedgerAccount> accounts, Money amount) {
    if (!amount.isPositive) {
      throw LedgerException.of('LEDGER_INVALID', 'Tutar sıfırdan büyük olmalı.');
    }
    for (final a in accounts) {
      if (a.currency != amount.currency) {
        throw LedgerException.of(
            'LEDGER_INVALID', '"${a.name}" hesabı ${a.currency.code}, tutar ${amount.currency.code}.');
      }
      if (a.archived) throw LedgerException.of('ACCOUNT_ARCHIVED');
    }
  }
}
