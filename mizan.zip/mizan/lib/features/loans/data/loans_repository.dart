import 'dart:convert';

import 'package:drift/drift.dart';

import '../../../core/database/app_database.dart' show AppDatabase;
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/utils/clock.dart';
import '../../../core/utils/ids.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounting/domain/ledger_models.dart';
import '../../accounting/domain/ledger_repository.dart';
import '../../accounting/domain/posting_rules.dart';
import '../../accounts/data/accounts_repository.dart';
import '../../transactions/application/entry_edit_service.dart';

class LoanInstallment {
  const LoanInstallment({
    required this.id,
    required this.no,
    required this.dueDate,
    required this.amount,
    required this.paidEntryId,
    required this.prepaid,
    this.paidAmount,
    this.paidDate,
  });

  final String id;
  final int no;
  final DateTime dueDate;

  /// Plandaki taksit tutarı.
  final Money amount;
  final String? paidEntryId;

  /// Takibe başlamadan önce ödenmiş (deftere ödeme yazılmamış).
  final bool prepaid;

  /// Gerçekte ödenen tutar ve tarih (ödeme kaydından).
  final Money? paidAmount;
  final DateTime? paidDate;

  bool get isPaid => paidEntryId != null || prepaid;
}

class LoanInfo {
  const LoanInfo({
    required this.account,
    required this.bankName,
    required this.total,
    required this.installmentCount,
    required this.installmentAmount,
    required this.firstDueDate,
    required this.remaining,
    required this.installments,
  });

  final LedgerAccount account;
  final String bankName;
  final Money total;
  final int installmentCount;
  final Money installmentAmount;
  final DateTime firstDueDate;

  /// Defterdeki kalan borç (ödeme yaptıkça düşer).
  final Money remaining;
  final List<LoanInstallment> installments;

  int get paidCount => installments.where((i) => i.isPaid).length;
  int get prepaidCount => installments.where((i) => i.prepaid).length;
  int get remainingCount => installments.length - paidCount;

  LoanInstallment? get next {
    for (final i in installments) {
      if (!i.isPaid) return i;
    }
    return null;
  }

  bool get isClosed => next == null;
}

/// Taksitli banka kredisi. Borç = toplam geri ödenecek tutar; taksitler
/// yalnızca kullanıcı "Taksit öde" dediğinde borçtan düşer.
class LoansRepository {
  LoansRepository(
    this._db,
    this._ledger,
    this._accounts,
    this._edit, {
    required this.deviceId,
    Clock clock = const Clock(),
  }) : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final AccountsRepository _accounts;
  final EntryEditService _edit;
  final String deviceId;
  final Clock _clock;

  /// Ödeme planı: her taksit tutarı [installment]; son taksit, toplamı
  /// tutturmak için farkı alır. Tutarlar her zaman [total]'a eşit toplanır.
  static List<int> planAmounts({required int totalMinor, required int count, required int installmentMinor}) {
    if (count < 1) throw const AppException('LOAN', 'Taksit sayısı en az 1 olmalı.');
    if (installmentMinor <= 0) throw const AppException('LOAN', 'Taksit tutarı sıfırdan büyük olmalı.');
    final last = totalMinor - installmentMinor * (count - 1);
    if (last <= 0) {
      throw const AppException('LOAN', 'Taksit tutarı × taksit sayısı toplam borcu aşıyor. Tutarları kontrol edin.');
    }
    return [for (var i = 1; i <= count; i++) i == count ? last : installmentMinor];
  }

  /// [n]. taksitin vadesi: ilk vadeden (n-1) ay sonra; ay sonu taşmaları
  /// ayın son gününe çekilir (31 Ocak → 28/29 Şubat).
  static DateTime dueDateFor(DateTime first, int n) {
    final monthIndex = first.month - 1 + (n - 1);
    final year = first.year + monthIndex ~/ 12;
    final month = monthIndex % 12 + 1;
    final lastDay = DateTime(year, month + 1, 0).day;
    final day = first.day > lastDay ? lastDay : first.day;
    return DateTime(year, month, day, 12);
  }

  Future<LedgerAccount> createLoan({
    required String businessId,
    required String name,
    required String bankName,
    required Currency currency,
    required Money total,
    required int installmentCount,
    required Money installmentAmount,
    required DateTime firstDueDate,
    int prepaidCount = 0,
    required String formKey,
  }) async {
    if (total.currency != currency || installmentAmount.currency != currency) {
      throw const AppException('LOAN', 'Tutarların para birimi kredinin para birimiyle aynı olmalı.');
    }
    if (!total.isPositive) throw const AppException('LOAN', 'Toplam borç sıfırdan büyük olmalı.');
    if (installmentCount > 600) throw const AppException('LOAN', 'Taksit sayısı en fazla 600 olabilir.');
    if (prepaidCount < 0 || prepaidCount >= installmentCount) {
      throw const AppException('LOAN', 'Daha önce ödenen taksit sayısı, toplam taksit sayısından az olmalı.');
    }
    final amounts =
        planAmounts(totalMinor: total.minor, count: installmentCount, installmentMinor: installmentAmount.minor);
    final prepaidSum = amounts.take(prepaidCount).fold<int>(0, (a, b) => a + b);
    final openingDebt = Money.fromMinor(total.minor - prepaidSum, currency);

    return _db.transaction(() async {
      final existing = await _db.customSelect(
        'SELECT 1 FROM loan_details WHERE account_id = ?',
        variables: [Variable.withString(formKey)],
      ).getSingleOrNull();
      if (existing != null) return _ledger.account(formKey);

      final account = await _accounts.createAccount(
        businessId: businessId,
        kind: AccountKind.kredi,
        name: name,
        currency: currency,
        formKey: formKey,
        openingBalance: openingDebt,
        openingDate: _clock.now(),
      );
      final openingId = await _entryIdByKey('acilis:$formKey');
      final now = _clock.nowMs();
      await _db.customInsert(
        'INSERT INTO loan_details (account_id, bank_name, total_minor, installment_count, installment_minor, '
        'first_due_date, opening_entry_id, created_at, updated_at, device_id) '
        'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        variables: [
          Variable.withString(account.id),
          Variable.withString(bankName.trim().isEmpty ? name.trim() : bankName.trim()),
          Variable.withInt(total.minor),
          Variable.withInt(installmentCount),
          Variable.withInt(installmentAmount.minor),
          Variable.withInt(_ms(firstDueDate)),
          Variable<String>(openingId),
          Variable.withInt(now),
          Variable.withInt(now),
          Variable.withString(deviceId),
        ],
        updates: _db.everyTable,
      );
      for (var n = 1; n <= installmentCount; n++) {
        await _insertInstallment(
          businessId: businessId,
          loanId: account.id,
          no: n,
          due: dueDateFor(firstDueDate, n),
          amountMinor: amounts[n - 1],
          prepaid: n <= prepaidCount,
        );
      }
      await _audit(businessId, account.id, 'insert', after: {
        'total_minor': total.minor,
        'count': installmentCount,
        'installment_minor': installmentAmount.minor,
        'prepaid': prepaidCount,
      });
      return account;
    });
  }

  Stream<LoanInfo?> watch(String accountId) => _db.watchAll(() => load(accountId));

  Future<LoanInfo?> load(String accountId) async {
    final d = await _db.customSelect(
      'SELECT bank_name, total_minor, installment_count, installment_minor, first_due_date '
      'FROM loan_details WHERE account_id = ?',
      variables: [Variable.withString(accountId)],
    ).getSingleOrNull();
    if (d == null) return null;
    final account = await _ledger.account(accountId);
    final balance = await _ledger.balanceOf(accountId);
    final c = account.currency;
    final rows = await _db.customSelect(
      '''
      SELECT i.id, i.installment_no, i.due_date, i.amount_minor, i.paid_entry_id, i.prepaid,
        e.entry_date AS paid_date,
        (SELECT SUM(l.debit_minor) FROM journal_lines l
          WHERE l.entry_id = i.paid_entry_id AND l.account_id = i.loan_account_id) AS paid_minor
      FROM loan_installments i
      LEFT JOIN journal_entries e ON e.id = i.paid_entry_id
      WHERE i.loan_account_id = ?
      ORDER BY i.installment_no
      ''',
      variables: [Variable.withString(accountId)],
    ).get();
    return LoanInfo(
      account: account,
      bankName: d.read<String>('bank_name'),
      total: Money.fromMinor(d.read<int>('total_minor'), c),
      installmentCount: d.read<int>('installment_count'),
      installmentAmount: Money.fromMinor(d.read<int>('installment_minor'), c),
      firstDueDate: DateTime.fromMillisecondsSinceEpoch(d.read<int>('first_due_date')),
      remaining: balance.balance,
      installments: [
        for (final r in rows)
          LoanInstallment(
            id: r.read<String>('id'),
            no: r.read<int>('installment_no'),
            dueDate: DateTime.fromMillisecondsSinceEpoch(r.read<int>('due_date')),
            amount: Money.fromMinor(r.read<int>('amount_minor'), c),
            paidEntryId: r.readNullable<String>('paid_entry_id'),
            prepaid: r.read<int>('prepaid') == 1,
            paidAmount: r.readNullable<int>('paid_minor') == null
                ? null
                : Money.fromMinor(r.read<int>('paid_minor'), c),
            paidDate: r.readNullable<int>('paid_date') == null
                ? null
                : DateTime.fromMillisecondsSinceEpoch(r.read<int>('paid_date')),
          ),
      ],
    );
  }

  /// Sıradaki ödenmemiş taksit (hesap listesindeki hatırlatma için).
  Future<LoanInstallment?> nextInstallment(String accountId) async {
    final info = await load(accountId);
    return info?.next;
  }

  Stream<LoanInstallment?> watchNext(String accountId) => _db.watchAll(() => nextInstallment(accountId));

  /// Taksiti öder: D kredi / C kasa|banka. Tutar plandakinden farklı olabilir.
  Future<String> pay({
    required String installmentId,
    required String moneyAccountId,
    required String amountText,
    required DateTime date,
    required String idempotencyKey,
  }) async {
    return _db.transaction(() async {
      final row = await _db.customSelect(
        'SELECT i.loan_account_id, i.installment_no, i.paid_entry_id, i.prepaid, d.installment_count '
        'FROM loan_installments i JOIN loan_details d ON d.account_id = i.loan_account_id WHERE i.id = ?',
        variables: [Variable.withString(installmentId)],
      ).getSingleOrNull();
      if (row == null) throw const AppException('LOAN', 'Taksit bulunamadı.');
      final already = await _entryIdByKey(idempotencyKey);
      if (already != null) return already;
      if (row.readNullable<String>('paid_entry_id') != null || row.read<int>('prepaid') == 1) {
        throw const AppException('LOAN', 'Bu taksit zaten ödenmiş.');
      }
      final loan = await _ledger.account(row.read<String>('loan_account_id'));
      final money = await _ledger.account(moneyAccountId);
      final Money amount;
      try {
        amount = Money.parse(amountText, loan.currency);
      } on FormatException catch (e) {
        throw AppException('AMOUNT', 'Tutar geçersiz: ${e.message}');
      }
      if (!amount.isPositive) throw const AppException('AMOUNT', 'Tutar sıfırdan büyük olmalı.');
      if (money.currency != loan.currency) {
        throw AppException('LOAN', 'Ödeme hesabı ${money.currency.code}, kredi ${loan.currency.code}.');
      }
      final no = row.read<int>('installment_no');
      final count = row.read<int>('installment_count');
      final entryId = await _ledger.post(PostingRequest(
        businessId: loan.businessId,
        type: EntryType.odeme,
        date: date,
        idempotencyKey: idempotencyKey,
        description: '${loan.name} — $no/$count. taksit',
        lines: PostingRules.loanPayment(loan: loan, moneyAccount: money, amount: amount),
      ));
      await _db.customUpdate(
        'UPDATE loan_installments SET paid_entry_id = ?, updated_at = ?, sync_status = 0, '
        'version = version + 1 WHERE id = ?',
        variables: [Variable.withString(entryId), Variable.withInt(_clock.nowMs()), Variable.withString(installmentId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      return entryId;
    });
  }

  /// Yanlışlıkla girilen ödemeyi geri alır: ödeme kaydı iptal edilir,
  /// taksit yeniden "ödenmedi" olur.
  Future<void> undoPayment({required String installmentId, required String idempotencyKey}) async {
    final row = await _db.customSelect(
      'SELECT paid_entry_id, prepaid FROM loan_installments WHERE id = ?',
      variables: [Variable.withString(installmentId)],
    ).getSingleOrNull();
    if (row == null) throw const AppException('LOAN', 'Taksit bulunamadı.');
    final entryId = row.readNullable<String>('paid_entry_id');
    if (entryId != null) {
      await _edit.reverse(entryId: entryId, idempotencyKey: idempotencyKey, reason: 'Taksit ödemesi geri alındı');
      return;
    }
    if (row.read<int>('prepaid') != 1) return;
    await _db.transaction(() async {
      await _db.customUpdate(
        'UPDATE loan_installments SET prepaid = 0, updated_at = ?, sync_status = 0, version = version + 1 '
        'WHERE id = ?',
        variables: [Variable.withInt(_clock.nowMs()), Variable.withString(installmentId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      // Önceden ödenmiş sayılan taksit artık borca eklenir.
      await _refreshOpening(installmentIdOfLoan: installmentId, key: idempotencyKey);
    });
  }

  /// Kredi bilgilerini düzeltir. Açılış borcu değişirse açılış kaydı
  /// "iptal + yeni kayıt" ile düzeltilir; ödenmemiş taksitler yeni bilgilere
  /// göre yeniden planlanır, ödenmiş taksitler olduğu gibi kalır.
  Future<void> updateLoan({
    required String accountId,
    required String name,
    required String bankName,
    required Money total,
    required int installmentCount,
    required Money installmentAmount,
    required DateTime firstDueDate,
    required int prepaidCount,
    required String editKey,
  }) async {
    final account = await _ledger.account(accountId);
    final c = account.currency;
    if (total.currency != c || installmentAmount.currency != c) {
      throw const AppException('LOAN', 'Tutarların para birimi kredinin para birimiyle aynı olmalı.');
    }
    if (!total.isPositive) throw const AppException('LOAN', 'Toplam borç sıfırdan büyük olmalı.');
    if (installmentCount > 600) throw const AppException('LOAN', 'Taksit sayısı en fazla 600 olabilir.');
    if (prepaidCount < 0 || prepaidCount >= installmentCount) {
      throw const AppException('LOAN', 'Daha önce ödenen taksit sayısı, toplam taksit sayısından az olmalı.');
    }
    final amounts =
        planAmounts(totalMinor: total.minor, count: installmentCount, installmentMinor: installmentAmount.minor);

    await _db.transaction(() async {
      final before = await load(accountId);
      if (before == null) throw const AppException('LOAN', 'Kredi bilgisi bulunamadı.');
      final paidRows = before.installments.where((i) => i.paidEntryId != null).toList();
      for (final p in paidRows) {
        if (p.no > installmentCount) {
          throw AppException('LOAN', '${p.no}. taksit ödenmiş; taksit sayısı ${p.no}\'den az olamaz.');
        }
        if (p.no <= prepaidCount) {
          throw AppException('LOAN',
              '${p.no}. taksitin ödemesi uygulamada kayıtlı; "daha önce ödenen" sayısı ${p.no}\'den az olmalı.');
        }
      }

      if (name.trim() != account.name) await _accounts.rename(accountId, name);

      final now = _clock.nowMs();
      await _db.customUpdate(
        'DELETE FROM loan_installments WHERE loan_account_id = ? AND paid_entry_id IS NULL',
        variables: [Variable.withString(accountId)],
        updates: _db.everyTable,
        updateKind: UpdateKind.delete,
      );
      final paidNos = {for (final p in paidRows) p.no};
      for (var n = 1; n <= installmentCount; n++) {
        if (paidNos.contains(n)) continue;
        await _insertInstallment(
          businessId: account.businessId,
          loanId: accountId,
          no: n,
          due: dueDateFor(firstDueDate, n),
          amountMinor: amounts[n - 1],
          prepaid: n <= prepaidCount,
        );
      }
      await _db.customUpdate(
        'UPDATE loan_details SET bank_name = ?, total_minor = ?, installment_count = ?, installment_minor = ?, '
        'first_due_date = ?, updated_at = ?, sync_status = 0, version = version + 1 WHERE account_id = ?',
        variables: [
          Variable.withString(bankName.trim().isEmpty ? name.trim() : bankName.trim()),
          Variable.withInt(total.minor),
          Variable.withInt(installmentCount),
          Variable.withInt(installmentAmount.minor),
          Variable.withInt(_ms(firstDueDate)),
          Variable.withInt(now),
          Variable.withString(accountId),
        ],
        updates: _db.everyTable,
        updateKind: UpdateKind.update,
      );
      await _refreshOpening(loanId: accountId, key: editKey);
      await _audit(account.businessId, accountId, 'update', before: {
        'total_minor': before.total.minor,
        'count': before.installmentCount,
        'installment_minor': before.installmentAmount.minor,
        'prepaid': before.prepaidCount,
      }, after: {
        'total_minor': total.minor,
        'count': installmentCount,
        'installment_minor': installmentAmount.minor,
        'prepaid': prepaidCount,
      });
    });
  }

  // ----------------------------------------------------------------------------

  /// Açılış borcunu "toplam − önceden ödenmiş taksitler" ile eşitler.
  Future<void> _refreshOpening({String? loanId, String? installmentIdOfLoan, required String key}) async {
    var id = loanId;
    if (id == null) {
      final r = await _db.customSelect(
        'SELECT loan_account_id FROM loan_installments WHERE id = ?',
        variables: [Variable.withString(installmentIdOfLoan!)],
      ).getSingle();
      id = r.read<String>('loan_account_id');
    }
    final d = await _db.customSelect(
      'SELECT d.total_minor, d.opening_entry_id, e.status '
      'FROM loan_details d LEFT JOIN journal_entries e ON e.id = d.opening_entry_id WHERE d.account_id = ?',
      variables: [Variable.withString(id)],
    ).getSingle();
    final prepaid = await _db.customSelect(
      'SELECT COALESCE(SUM(amount_minor), 0) AS s FROM loan_installments WHERE loan_account_id = ? AND prepaid = 1',
      variables: [Variable.withString(id)],
    ).getSingle();
    final target = d.read<int>('total_minor') - prepaid.read<int>('s');
    final account = await _ledger.account(id);
    final openingId = d.readNullable<String>('opening_entry_id');
    final openingPosted = openingId != null && d.readNullable<String>('status') == 'posted';

    var current = 0;
    if (openingPosted) {
      final r = await _db.customSelect(
        'SELECT COALESCE(SUM(credit_minor), 0) AS s FROM journal_lines WHERE entry_id = ? AND account_id = ?',
        variables: [Variable.withString(openingId!), Variable.withString(id)],
      ).getSingle();
      current = r.read<int>('s');
    }
    if (current == target) return;

    String? newOpening;
    if (openingPosted && target > 0) {
      newOpening = await _edit.edit(
        entryId: openingId!,
        editKey: 'kredi-acilis:$key',
        amount: Money.fromMinor(target, account.currency),
        keepDescription: true,
      );
    } else {
      if (openingPosted) {
        await _edit.reverse(entryId: openingId!, idempotencyKey: 'kredi-acilis-iptal:$key', reason: 'Kredi düzeltme');
      }
      if (target > 0) {
        final equity = await _accounts.ensureSystemAccount(account.businessId, 'acilis_ozkaynak', account.currency);
        newOpening = await _ledger.post(PostingRequest(
          businessId: account.businessId,
          type: EntryType.acilis,
          date: _clock.now(),
          idempotencyKey: 'kredi-acilis:$key',
          description: 'Açılış bakiyesi — ${account.name}',
          lines: PostingRules.opening(
            account: account,
            equity: equity,
            amount: Money.fromMinor(target, account.currency),
          ),
        ));
      }
    }
    await _db.customUpdate(
      'UPDATE loan_details SET opening_entry_id = ?, updated_at = ?, sync_status = 0, version = version + 1 '
      'WHERE account_id = ?',
      variables: [Variable<String>(newOpening), Variable.withInt(_clock.nowMs()), Variable.withString(id)],
      updates: _db.everyTable,
      updateKind: UpdateKind.update,
    );
  }

  Future<void> _insertInstallment({
    required String businessId,
    required String loanId,
    required int no,
    required DateTime due,
    required int amountMinor,
    required bool prepaid,
  }) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO loan_installments (id, business_id, loan_account_id, installment_no, due_date, amount_minor, '
      'prepaid, created_at, updated_at, device_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(loanId),
        Variable.withInt(no),
        Variable.withInt(_ms(due)),
        Variable.withInt(amountMinor),
        Variable.withInt(prepaid ? 1 : 0),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }

  Future<String?> _entryIdByKey(String key) async {
    final row = await _db.customSelect(
      'SELECT id FROM journal_entries WHERE idempotency_key = ?',
      variables: [Variable.withString(key)],
    ).getSingleOrNull();
    return row?.read<String>('id');
  }

  static int _ms(DateTime d) => DateTime(d.year, d.month, d.day, 12).millisecondsSinceEpoch;

  Future<void> _audit(String businessId, String id, String action,
      {Map<String, Object?>? before, Map<String, Object?>? after}) async {
    final now = _clock.nowMs();
    await _db.customInsert(
      'INSERT INTO audit_log (id, business_id, entity_table, record_id, audit_action, before_json, after_json, '
      "occurred_at, created_at, updated_at, device_id) VALUES (?, ?, 'loan_details', ?, ?, ?, ?, ?, ?, ?, ?)",
      variables: [
        Variable.withString(newId()),
        Variable.withString(businessId),
        Variable.withString(id),
        Variable.withString(action),
        Variable<String>(before == null ? null : jsonEncode(before)),
        Variable<String>(after == null ? null : jsonEncode(after)),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withInt(now),
        Variable.withString(deviceId),
      ],
      updates: _db.everyTable,
    );
  }
}
