import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../transactions/application/entry_edit_service.dart';
import '../data/loans_repository.dart';

final loansRepositoryProvider = Provider<LoansRepository>((ref) => LoansRepository(
      ref.watch(databaseProvider),
      ref.watch(ledgerRepositoryProvider),
      ref.watch(accountsRepositoryProvider),
      ref.watch(entryEditServiceProvider),
      deviceId: ref.watch(deviceIdProvider),
      clock: ref.watch(clockProvider),
    ));

final loanProvider = StreamProvider.autoDispose.family<LoanInfo?, String>((ref, accountId) {
  return ref.watch(loansRepositoryProvider).watch(accountId);
});

/// Hesap listesindeki "sıradaki taksit" hatırlatması.
final nextInstallmentProvider = StreamProvider.autoDispose.family<LoanInstallment?, String>((ref, accountId) {
  return ref.watch(loansRepositoryProvider).watchNext(accountId);
});
