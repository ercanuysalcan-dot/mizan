import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../application/loans_providers.dart';
import '../data/loans_repository.dart';

/// Krediyi düzenleme formunu alt sayfa olarak açar.
Future<void> showEditLoanSheet(BuildContext context, LoanInfo loan) => showModalBottomSheet<void>(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 640),
      builder: (ctx) {
        final bottom = MediaQuery.viewInsetsOf(ctx).bottom;
        return Padding(
          padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
          child: SingleChildScrollView(child: LoanForm(existing: loan)),
        );
      },
    );

/// Banka kredisi oluşturma / düzenleme formu.
///
/// Borç basit gösterilir: toplam geri ödenecek tutar yazılır, taksitler
/// ödendikçe düşer. Daha önce ödenmiş taksitler "önceden ödendi" sayılır.
class LoanForm extends ConsumerStatefulWidget {
  const LoanForm({super.key, this.existing, this.onBack});

  final LoanInfo? existing;

  /// Hesap türü seçimine dönüş (yalnızca oluşturma sırasında).
  final VoidCallback? onBack;

  @override
  ConsumerState<LoanForm> createState() => _LoanFormState();
}

class _LoanFormState extends ConsumerState<LoanForm> {
  late final LoanInfo? _e = widget.existing;
  late Currency _currency = _e?.account.currency ?? ref.read(currentBusinessProvider).baseCurrency;
  late final _name = TextEditingController(text: _e?.account.name ?? '');
  late final _bank = TextEditingController(text: _e?.bankName ?? '');
  late final _total = TextEditingController(text: _e == null ? '' : _plain(_e!.total));
  late final _count = TextEditingController(text: _e == null ? '' : '${_e!.installmentCount}');
  late final _installment = TextEditingController(text: _e == null ? '' : _plain(_e!.installmentAmount));
  late final _prepaid = TextEditingController(text: '${_e?.prepaidCount ?? 0}');
  late DateTime _firstDue = _e?.firstDueDate ?? _defaultFirstDue();
  bool _installmentTouched = false;
  bool _busy = false;
  String? _error;
  final String _key = newId();

  static String _plain(Money m) => MoneyFormat.format(m, symbol: false);

  DateTime _defaultFirstDue() {
    final now = ref.read(clockProvider).now();
    return LoansRepository.dueDateFor(DateTime(now.year, now.month, now.day), 2);
  }

  @override
  void initState() {
    super.initState();
    _installmentTouched = widget.existing != null;
  }

  @override
  void dispose() {
    _name.dispose();
    _bank.dispose();
    _total.dispose();
    _count.dispose();
    _installment.dispose();
    _prepaid.dispose();
    super.dispose();
  }

  Money? _money(TextEditingController c) {
    if (c.text.trim().isEmpty) return null;
    try {
      return Money.parse(c.text, _currency);
    } on FormatException {
      return null;
    }
  }

  int? _int(TextEditingController c) => int.tryParse(c.text.trim());

  /// Toplam ve taksit sayısı girilince aylık taksiti önerir.
  void _suggestInstallment() {
    if (_installmentTouched) return;
    final total = _money(_total);
    final count = _int(_count);
    if (total == null || count == null || count < 1 || !total.isPositive) return;
    final per = divideRounded(BigInt.from(total.minor), BigInt.from(count), RoundingMode.halfUp).toInt();
    _installment.text = _plain(Money.fromMinor(per, _currency));
  }

  String? _preview() {
    final total = _money(_total);
    final count = _int(_count);
    final inst = _money(_installment);
    if (total == null || count == null || inst == null || count < 1) return null;
    try {
      final plan = LoansRepository.planAmounts(totalMinor: total.minor, count: count, installmentMinor: inst.minor);
      final last = Money.fromMinor(plan.last, _currency);
      final lastNote = plan.last == inst.minor ? '' : ' (son taksit ${MoneyFormat.format(last)})';
      final prepaid = _int(_prepaid) ?? 0;
      final safePrepaid = prepaid < 0 ? 0 : (prepaid > count ? count : prepaid);
      final prepaidSum = plan.take(safePrepaid).fold<int>(0, (a, b) => a + b);
      final debt = Money.fromMinor(total.minor - prepaidSum, _currency);
      return '$count taksit × ${MoneyFormat.format(inst)}$lastNote\n'
          'Toplam borç ${MoneyFormat.format(total)} · Uygulamaya girilecek kalan borç ${MoneyFormat.format(debt)}\n'
          'Son ödeme: ${TrFormat.date(LoansRepository.dueDateFor(_firstDue, count))}';
    } on AppException catch (e) {
      return e.message;
    }
  }

  Future<void> _save() async {
    final total = _money(_total);
    final count = _int(_count);
    final inst = _money(_installment);
    final prepaid = _int(_prepaid) ?? 0;
    String? err;
    if (_name.text.trim().isEmpty) err = 'Kredi adını yazın (örn. Denizbank İhtiyaç Kredisi).';
    if (err == null && (total == null || !total.isPositive)) err = 'Toplam borcu girin.';
    if (err == null && (count == null || count < 1)) err = 'Taksit sayısını girin.';
    if (err == null && (inst == null || !inst.isPositive)) err = 'Aylık taksit tutarını girin.';
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    final repo = ref.read(loansRepositoryProvider);
    try {
      if (_e == null) {
        await repo.createLoan(
          businessId: ref.read(currentBusinessProvider).id,
          name: _name.text,
          bankName: _bank.text,
          currency: _currency,
          total: total!,
          installmentCount: count!,
          installmentAmount: inst!,
          firstDueDate: _firstDue,
          prepaidCount: prepaid,
          formKey: _key,
        );
      } else {
        await repo.updateLoan(
          accountId: _e!.account.id,
          name: _name.text,
          bankName: _bank.text,
          total: total!,
          installmentCount: count!,
          installmentAmount: inst!,
          firstDueDate: _firstDue,
          prepaidCount: prepaid,
          editKey: _key,
        );
      }
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_e == null ? '“${_name.text.trim()}” oluşturuldu.' : 'Kredi bilgileri güncellendi.')),
      );
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final preview = _preview();
    final amountFormatter = FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'));
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(children: [
          if (widget.onBack != null)
            IconButton(
              tooltip: 'Tür seçimine dön',
              onPressed: widget.onBack,
              icon: const Icon(Icons.arrow_back_rounded),
            ),
          Icon(Icons.request_quote_outlined, color: context.colors.secondary),
          Space.gapSm,
          Expanded(
            child: Text(_e == null ? 'Banka Kredisi' : 'Krediyi düzenle', style: context.text.titleLarge),
          ),
        ]),
        Space.gapLg,
        TextField(
          controller: _name,
          autofocus: _e == null,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Kredi adı', hintText: 'Denizbank İhtiyaç Kredisi'),
        ),
        Space.gapMd,
        TextField(
          controller: _bank,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Banka (isteğe bağlı)', hintText: 'Denizbank'),
        ),
        if (_e == null) ...[
          Space.gapLg,
          Text('Para birimi', style: context.text.labelLarge),
          Space.gapSm,
          SegmentedButton<Currency>(
            showSelectedIcon: false,
            segments: [
              for (final c in Currency.values) ButtonSegment(value: c, label: Text('${c.symbol} ${c.code}')),
            ],
            selected: {_currency},
            onSelectionChanged: (s) => setState(() => _currency = s.first),
          ),
        ],
        Space.gapLg,
        TextField(
          controller: _total,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          inputFormatters: [amountFormatter],
          onChanged: (_) => setState(_suggestInstallment),
          decoration: InputDecoration(
            labelText: 'Toplam borç (geri ödenecek toplam)',
            hintText: '114.000',
            suffixText: _currency.code,
          ),
        ),
        Space.gapMd,
        Row(children: [
          Expanded(
            child: TextField(
              controller: _count,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              onChanged: (_) => setState(_suggestInstallment),
              decoration: const InputDecoration(labelText: 'Taksit sayısı', hintText: '12'),
            ),
          ),
          Space.gapMd,
          Expanded(
            child: TextField(
              controller: _installment,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [amountFormatter],
              onChanged: (_) => setState(() => _installmentTouched = true),
              decoration: InputDecoration(labelText: 'Aylık taksit', suffixText: _currency.code),
            ),
          ),
        ]),
        Space.gapMd,
        OutlinedButton.icon(
          icon: const Icon(Icons.event_outlined, size: 18),
          label: Text('İlk taksit tarihi: ${TrFormat.date(_firstDue)}'),
          onPressed: () async {
            final picked = await showDatePicker(
              context: context,
              initialDate: _firstDue,
              firstDate: DateTime(2000),
              lastDate: DateTime(2100),
            );
            if (picked != null) setState(() => _firstDue = picked);
          },
        ),
        Space.gapMd,
        TextField(
          controller: _prepaid,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            labelText: 'Daha önce ödenmiş taksit sayısı',
            helperText: 'Krediyi yeni girmiyorsan, uygulamadan önce ödediğin taksitler.',
          ),
        ),
        if (preview != null) ...[
          Space.gapLg,
          Container(
            padding: const EdgeInsets.all(Space.md),
            decoration: BoxDecoration(
              color: context.tokens.mutedSurface,
              borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
            ),
            child: Text(preview, style: context.text.bodySmall),
          ),
        ],
        Space.gapSm,
        Text(
          'Taksitler otomatik düşmez; ödeme yaptığında “Taksit öde” ile kaydedersin.',
          style: context.text.bodySmall,
        ),
        if (_error != null) ...[
          Space.gapMd,
          Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
        ],
        Space.gapXl,
        FilledButton(
          onPressed: _busy ? null : _save,
          child: _busy
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : Text(_e == null ? 'Krediyi oluştur' : 'Kaydet'),
        ),
      ],
    );
  }
}
