import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../app/providers.dart';
import '../../../core/errors/app_exception.dart';
import '../../../core/money/money.dart';
import '../../../core/money/money_format.dart';
import '../../../core/utils/ids.dart';
import '../../../core/utils/tr_format.dart';
import '../../../design_system/design_system.dart';
import '../../accounting/domain/account_kind.dart';
import '../../accounts/application/accounts_providers.dart';
import '../application/loans_providers.dart';
import '../data/loans_repository.dart';
import 'loan_form.dart';

/// Vade durumuna göre kısa açıklama: "3 gün sonra", "Bugün", "5 gün gecikti".
String dueLabel(DateTime due, DateTime now) {
  final a = DateTime(now.year, now.month, now.day);
  final b = DateTime(due.year, due.month, due.day);
  final days = b.difference(a).inHours ~/ 24;
  if (days == 0) return 'Bugün';
  if (days == 1) return 'Yarın';
  if (days > 1) return '$days gün sonra';
  return '${-days} gün gecikti';
}

/// Kredi detay sayfasındaki özet + ödeme planı.
class LoanSection extends ConsumerWidget {
  const LoanSection({super.key, required this.accountId});
  final String accountId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(loanProvider(accountId));
    return async.when(
      loading: () => const Padding(
        padding: EdgeInsets.all(Space.xl),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (e, _) => Text('Kredi bilgisi yüklenemedi: $e'),
      data: (loan) {
        if (loan == null) {
          return const MizanCard(
            child: Text('Bu kredi hesabının ödeme planı yok. Yeni kredi eklerken “Banka Kredisi” türünü seçin.'),
          );
        }
        return _LoanBody(loan: loan);
      },
    );
  }
}

class _LoanBody extends ConsumerWidget {
  const _LoanBody({required this.loan});
  final LoanInfo loan;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final now = ref.watch(clockProvider).now();
    final next = loan.next;
    final paidRatio = loan.installments.isEmpty ? 0.0 : loan.paidCount / loan.installments.length;
    final remainingPlan = loan.installments
        .where((i) => !i.isPaid)
        .fold<int>(0, (a, i) => a + i.amount.minor);
    final overdue = next != null && DateTime(next.dueDate.year, next.dueDate.month, next.dueDate.day)
        .isBefore(DateTime(now.year, now.month, now.day));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        MizanCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text('KALAN BORÇ', style: context.text.labelSmall),
            Space.gapXs,
            MoneyText(loan.remaining, style: context.text.displaySmall, tone: MoneyTone.expense),
            Space.gapSm,
            Text(
              loan.isClosed
                  ? 'Tüm taksitler ödendi.'
                  : 'Kalan: ${loan.remainingCount} taksit / '
                      '${MoneyFormat.format(Money.fromMinor(remainingPlan, loan.total.currency))}',
              style: context.text.titleSmall,
            ),
            Space.gapMd,
            ClipRRect(
              borderRadius: Radii.pill,
              child: LinearProgressIndicator(value: paidRatio, minHeight: 8),
            ),
            Space.gapSm,
            Text(
              '${loan.paidCount}/${loan.installments.length} taksit ödendi · Toplam ${MoneyFormat.format(loan.total)}'
              '${loan.bankName == loan.account.name ? '' : ' · ${loan.bankName}'}',
              style: context.text.bodySmall,
            ),
            if (next != null) ...[
              Space.gapLg,
              Container(
                padding: const EdgeInsets.all(Space.md),
                decoration: BoxDecoration(
                  color: overdue ? context.tokens.expense.withValues(alpha: 0.10) : context.tokens.mutedSurface,
                  borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                ),
                child: Row(children: [
                  Icon(overdue ? Icons.warning_amber_rounded : Icons.event_outlined,
                      color: overdue ? context.tokens.expense : context.colors.secondary),
                  Space.gapMd,
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('Sıradaki: ${next.no}. taksit · ${MoneyFormat.format(next.amount)}',
                          style: context.text.titleSmall),
                      Text('${TrFormat.date(next.dueDate)} · ${dueLabel(next.dueDate, now)}',
                          style: context.text.bodySmall),
                    ]),
                  ),
                ]),
              ),
              Space.gapMd,
              FilledButton.icon(
                onPressed: () => showPayInstallmentSheet(context, loan, next),
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: Text('${next.no}. taksiti öde'),
              ),
            ],
            Space.gapSm,
            OutlinedButton.icon(
              onPressed: () => showEditLoanSheet(context, loan),
              icon: const Icon(Icons.edit_outlined, size: 18),
              label: const Text('Kredi bilgilerini düzenle'),
            ),
          ]),
        ),
        Space.gapLg,
        const SectionHeader('Ödeme planı'),
        MizanCard(
          padding: const EdgeInsets.symmetric(vertical: Space.xs),
          child: Column(children: [
            for (var i = 0; i < loan.installments.length; i++) ...[
              if (i > 0) const Divider(height: 1),
              _InstallmentTile(loan: loan, item: loan.installments[i], now: now),
            ],
          ]),
        ),
      ],
    );
  }
}

enum _InstAction { pay, undo }

class _InstallmentTile extends ConsumerWidget {
  const _InstallmentTile({required this.loan, required this.item, required this.now});
  final LoanInfo loan;
  final LoanInstallment item;
  final DateTime now;

  Future<void> _undo(BuildContext context, WidgetRef ref) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${item.no}. taksit ödemesi geri alınsın mı?'),
        content: Text(item.prepaid
            ? 'Bu taksit “daha önce ödenmiş” olarak işaretliydi. İşaret kaldırılınca tutarı kalan borca eklenir.'
            : 'Ödeme kaydı iptal edilir (ters kayıt), para ödediğin hesaba geri döner ve taksit yeniden '
                '“ödenmedi” olur. Bu adım değişiklik geçmişine yazılır.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Vazgeç')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Geri al')),
        ],
      ),
    );
    if (ok != true) return;
    if (!context.mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await ref
          .read(loansRepositoryProvider)
          .undoPayment(installmentId: item.id, idempotencyKey: 'taksit-geri:${newId()}');
      messenger.showSnackBar(SnackBar(content: Text('${item.no}. taksit yeniden “ödenmedi”.')));
    } on AppException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final t = context.tokens;
    final due = DateTime(item.dueDate.year, item.dueDate.month, item.dueDate.day);
    final overdue = !item.isPaid && due.isBefore(DateTime(now.year, now.month, now.day));
    final String subtitle;
    if (item.prepaid) {
      subtitle = 'Vade ${TrFormat.date(item.dueDate)} · Uygulamadan önce ödendi';
    } else if (item.paidEntryId != null) {
      final paid = item.paidAmount == null ? '' : ' ${MoneyFormat.format(item.paidAmount!)}';
      final when = item.paidDate == null ? '' : ' (${TrFormat.date(item.paidDate!)})';
      subtitle = 'Vade ${TrFormat.date(item.dueDate)} · Ödendi$paid$when';
    } else {
      subtitle = 'Vade ${TrFormat.date(item.dueDate)} · ${dueLabel(item.dueDate, now)}';
    }
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg),
      leading: CircleAvatar(
        radius: 16,
        backgroundColor: item.isPaid
            ? t.income.withValues(alpha: 0.15)
            : (overdue ? t.expense.withValues(alpha: 0.15) : t.mutedSurface),
        child: item.isPaid
            ? Icon(Icons.check_rounded, size: 18, color: t.income)
            : Text('${item.no}', style: context.text.labelMedium),
      ),
      title: Text('${item.no}. taksit', style: context.text.titleSmall),
      subtitle: Text(subtitle, style: context.text.bodySmall!.copyWith(color: overdue ? t.expense : null)),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        MoneyText(item.amount, style: context.text.titleSmall, animate: false),
        PopupMenuButton<_InstAction>(
          tooltip: 'Taksit işlemleri',
          onSelected: (a) {
            switch (a) {
              case _InstAction.pay:
                showPayInstallmentSheet(context, loan, item);
              case _InstAction.undo:
                _undo(context, ref);
            }
          },
          itemBuilder: (_) => [
            if (!item.isPaid) const PopupMenuItem(value: _InstAction.pay, child: Text('Taksiti öde')),
            if (item.isPaid) const PopupMenuItem(value: _InstAction.undo, child: Text('Ödemeyi geri al')),
          ],
        ),
      ]),
      onTap: item.isPaid ? null : () => showPayInstallmentSheet(context, loan, item),
    );
  }
}

Future<void> showPayInstallmentSheet(BuildContext context, LoanInfo loan, LoanInstallment item) =>
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      constraints: const BoxConstraints(maxWidth: 560),
      builder: (_) => _PaySheet(loan: loan, item: item),
    );

class _PaySheet extends ConsumerStatefulWidget {
  const _PaySheet({required this.loan, required this.item});
  final LoanInfo loan;
  final LoanInstallment item;

  @override
  ConsumerState<_PaySheet> createState() => _PaySheetState();
}

class _PaySheetState extends ConsumerState<_PaySheet> {
  late final _amount = TextEditingController(text: MoneyFormat.format(widget.item.amount, symbol: false));
  late DateTime _date = ref.read(clockProvider).now();
  String? _moneyId;
  String? _error;
  bool _busy = false;
  final _key = 'taksit:${newId()}';

  @override
  void dispose() {
    _amount.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_moneyId == null) {
      setState(() => _error = 'Ödemeyi yaptığın hesabı seç.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(loansRepositoryProvider).pay(
            installmentId: widget.item.id,
            moneyAccountId: _moneyId!,
            amountText: _amount.text,
            date: _date,
            idempotencyKey: _key,
          );
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('${widget.item.no}. taksit ödendi, borçtan düştü.')));
    } on AppException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final c = widget.loan.account.currency;
    final accounts = (ref.watch(userAccountsProvider).valueOrNull ?? const [])
        .where((a) =>
            (a.account.kind == AccountKind.kasa || a.account.kind == AccountKind.banka) && a.account.currency == c)
        .toList();
    return Padding(
      padding: EdgeInsets.fromLTRB(Space.xl, 0, Space.xl, Space.xl + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${widget.item.no}. taksiti öde', style: context.text.headlineSmall),
            Space.gapXs,
            Text('${widget.loan.account.name} · Vade ${TrFormat.date(widget.item.dueDate)}',
                style: context.text.bodySmall),
            Space.gapLg,
            if (accounts.isEmpty)
              Text('Önce ${c.code} para biriminde bir kasa veya banka hesabı ekle.',
                  style: context.text.bodyMedium!.copyWith(color: context.tokens.expense))
            else
              DropdownButtonFormField<String>(
                // ignore: deprecated_member_use
                value: accounts.any((a) => a.account.id == _moneyId) ? _moneyId : null,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Ödemeyi yaptığın hesap'),
                items: [
                  for (final a in accounts)
                    DropdownMenuItem(
                      value: a.account.id,
                      child: Text('${a.account.name}  ·  ${MoneyFormat.format(a.balance)}',
                          overflow: TextOverflow.ellipsis),
                    ),
                ],
                onChanged: (v) => setState(() => _moneyId = v),
              ),
            Space.gapMd,
            TextField(
              controller: _amount,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
              style: context.text.headlineSmall!.copyWith(fontFeatures: MizanTheme.tabular),
              decoration: InputDecoration(
                labelText: 'Ödenen tutar',
                helperText: 'Plandaki tutardan farklı ödediysen düzeltebilirsin.',
                suffixText: c.code,
              ),
            ),
            Space.gapMd,
            OutlinedButton.icon(
              icon: const Icon(Icons.event_outlined, size: 18),
              label: Text('Ödeme tarihi: ${TrFormat.date(_date)}'),
              onPressed: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: _date,
                  firstDate: DateTime(2000),
                  lastDate: DateTime(_date.year + 5),
                );
                if (picked != null) {
                  final now = ref.read(clockProvider).now();
                  setState(() => _date = DateTime(picked.year, picked.month, picked.day, now.hour, now.minute));
                }
              },
            ),
            if (_error != null) ...[
              Space.gapMd,
              Text(_error!, style: context.text.bodyMedium!.copyWith(color: context.tokens.expense)),
            ],
            Space.gapXl,
            FilledButton(
              onPressed: _busy || accounts.isEmpty ? null : _save,
              child: _busy
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Ödemeyi kaydet'),
            ),
          ],
        ),
      ),
    );
  }
}
