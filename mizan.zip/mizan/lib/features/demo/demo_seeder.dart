import 'dart:convert';

import 'package:drift/drift.dart';

import '../../core/database/app_database.dart' show AppDatabase;
import '../../core/errors/app_exception.dart';
import '../../core/money/money.dart';
import '../../core/utils/clock.dart';
import '../../core/utils/ids.dart';
import '../accounting/domain/account_kind.dart';
import '../accounting/domain/ledger_models.dart';
import '../accounting/domain/ledger_repository.dart';
import '../accounting/domain/posting_rules.dart';
import '../accounts/data/accounts_repository.dart';
import '../settings/data/settings_repository.dart';

/// Ana ekranı denemek için örnek kayıtlar.
///
/// Sahte veri tabanına doğrudan yazmaz: her hesap ve işlem gerçek muhasebe
/// motorundan geçer. "Örnek verileri kaldır" tüm örnek işlemleri ters kayıtla
/// iptal eder ve örnek hesapları arşivler — defterden hiçbir şey silinmez.
class DemoSeeder {
  DemoSeeder(this._db, this._ledger, this._accounts, this._settings, {Clock clock = const Clock()})
      : _clock = clock;

  final AppDatabase _db;
  final LedgerRepository _ledger;
  final AccountsRepository _accounts;
  final SettingsRepository _settings;
  final Clock _clock;

  static const stateKey = 'demo.accounts';

  Future<bool> isLoaded() async => (await _settings.get(stateKey)) != null;

  Future<void> load(String businessId) async {
    if (await isLoaded()) return;
    final existing = await _accounts.userAccounts(businessId, includeArchived: true);
    if (existing.isNotEmpty) {
      throw const AppException('DEMO', 'Örnek veriler yalnızca hiç hesap yokken yüklenebilir.');
    }
    final now = _clock.now();
    final start = DateTime(now.year, now.month - 5, 1);
    const tl = Currency.tryLira;
    Money m(int lira) => Money.fromMinor(lira * 100, tl);

    final ids = <String>[];
    Future<LedgerAccount> acc(AccountKind k, String name, int opening, {bool normal = true}) async {
      final a = await _accounts.createAccount(
        businessId: businessId,
        kind: k,
        name: name,
        currency: tl,
        formKey: newId(),
        openingBalance: opening == 0 ? null : m(opening),
        openingInNormalDirection: normal,
        openingDate: start,
      );
      ids.add(a.id);
      return a;
    }

    final kasa = await acc(AccountKind.kasa, 'Ana Kasa', 18500);
    final banka = await acc(AccountKind.banka, 'İş Bankası Vadesiz', 142000);
    final banka2 = await acc(AccountKind.banka, 'Ziraat Ticari', 64000);
    final kart = await acc(AccountKind.krediKarti, 'Bonus Kart', 8200);
    final musteri = await acc(AccountKind.cari, 'Yıldız Yapı Ltd.', 26000);
    final tedarikci = await acc(AccountKind.cari, 'Demir Toptan', 15400, normal: false);
    await acc(AccountKind.birikim, 'Gram Altın', 95000);
    await acc(AccountKind.personel, 'Mehmet Kaya', 0);

    Future<LedgerAccount> cat(String type, String name) async {
      final c = (await _accounts.categories(businessId, type)).firstWhere((x) => x.name == name);
      return _accounts.ensureCategoryAccount(businessId, c.id, tl);
    }

    final satis = await cat('gelir', 'Satış');
    final hizmet = await cat('gelir', 'Hizmet Geliri');
    final kira = await cat('gider', 'Kira');
    final maas = await cat('gider', 'Maaş');
    final fatura = await cat('gider', 'Faturalar');
    final market = await cat('gider', 'Market');
    final ulasim = await cat('gider', 'Ulaşım');

    var n = 0;
    Future<void> post(EntryType t, DateTime d, String desc, List<PostingLine> lines) => _ledger.post(
          PostingRequest(
            businessId: businessId,
            type: t,
            date: d,
            idempotencyKey: 'demo:${n++}',
            description: desc,
            lines: lines,
          ),
        );

    for (var i = 0; i < 6; i++) {
      DateTime day(int d) {
        final first = DateTime(start.year, start.month + i, 1);
        final isCurrent = first.year == now.year && first.month == now.month;
        final safe = isCurrent ? (d > now.day ? now.day : d) : d;
        return DateTime(first.year, first.month, safe, 10 + (d % 7));
      }

      final wave = [0, 6, 3, 9, 4, 11][i]; // aydan aya doğal dalgalanma
      await post(EntryType.gelir, day(3), 'Toptan satış',
          PostingRules.income(moneyAccount: banka, incomeAccount: satis, amount: m(48000 + wave * 1500)));
      await post(EntryType.gelir, day(12), 'Danışmanlık',
          PostingRules.income(moneyAccount: banka2, incomeAccount: hizmet, amount: m(12500 + wave * 400)));
      await post(EntryType.gelir, day(18), 'Perakende satış',
          PostingRules.income(moneyAccount: kasa, incomeAccount: satis, amount: m(9300 + wave * 650)));
      await post(EntryType.gider, day(1), 'Dükkan kirası',
          PostingRules.expense(paidFrom: banka, expenseAccount: kira, amount: m(22000)));
      await post(EntryType.gider, day(5), 'Personel maaşı',
          PostingRules.expense(paidFrom: banka, expenseAccount: maas, amount: m(26500)));
      await post(EntryType.gider, day(9), 'Elektrik ve su',
          PostingRules.expense(paidFrom: banka2, expenseAccount: fatura, amount: m(3400 + wave * 120)));
      await post(EntryType.kartHarcama, day(14), 'Market alışverişi',
          PostingRules.expense(paidFrom: kart, expenseAccount: market, amount: m(4100 + wave * 210)));
      await post(EntryType.kartHarcama, day(20), 'Akaryakıt',
          PostingRules.expense(paidFrom: kart, expenseAccount: ulasim, amount: m(2900 + wave * 90)));
      await post(EntryType.kartOdeme, day(25), 'Kart ekstre ödemesi',
          PostingRules.transfer(from: banka, to: kart, amount: m(6800 + wave * 200)));
      await post(EntryType.tahsilat, day(16), 'Yıldız Yapı tahsilatı',
          PostingRules.collection(cari: musteri, moneyAccount: banka, amount: m(9000 + wave * 300)));
      await post(EntryType.alacak, day(22), 'Veresiye satış — Yıldız Yapı',
          PostingRules.receivable(cari: musteri, incomeAccount: satis, amount: m(11000 + wave * 250)));
      await post(EntryType.odeme, day(19), 'Demir Toptan ödemesi',
          PostingRules.payment(cari: tedarikci, moneyAccount: banka2, amount: m(5200 + wave * 150)));
      await post(EntryType.transfer, day(27), 'Kasadan bankaya',
          PostingRules.transfer(from: kasa, to: banka, amount: m(6000)));
    }

    await _settings.set(stateKey, jsonEncode(ids));
  }

  /// Tüm örnek işlemleri ters kayıtla iptal eder ve örnek hesapları arşivler.
  Future<int> remove(String businessId) async {
    final raw = await _settings.get(stateKey);
    if (raw == null) return 0;
    final ids = (jsonDecode(raw) as List<dynamic>).cast<String>();
    final keys = [for (final id in ids) 'acilis:$id'];
    final rows = await _db.customSelect(
      "SELECT id FROM journal_entries WHERE business_id = ? AND status = 'posted' "
      "AND entry_type <> 'iptal' AND (idempotency_key LIKE 'demo:%' "
      'OR idempotency_key IN (${List.filled(keys.isEmpty ? 1 : keys.length, '?').join(',')}))',
      variables: [
        Variable.withString(businessId),
        if (keys.isEmpty) Variable.withString('-') else for (final k in keys) Variable.withString(k),
      ],
    ).get();
    var count = 0;
    for (final r in rows) {
      final id = r.read<String>('id');
      await _ledger.reverse(entryId: id, idempotencyKey: 'demo-iptal:$id', reason: 'Örnek veriler kaldırıldı');
      count++;
    }
    for (final id in ids) {
      await _accounts.archive(id);
    }
    await _db.customUpdate(
      'DELETE FROM app_settings WHERE setting_key = ?',
      variables: [Variable.withString(stateKey)],
      updates: _db.everyTable,
      updateKind: UpdateKind.delete,
    );
    return count;
  }
}
