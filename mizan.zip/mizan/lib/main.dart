import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'app/bootstrap.dart';
import 'app/providers.dart';
import 'core/database/app_database.dart' show AppDatabase;
import 'core/database/connection.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final db = AppDatabase(openAppDatabaseConnection());
  final boot = await bootstrap(db);
  runApp(
    ProviderScope(
      overrides: [
        databaseProvider.overrideWithValue(db),
        bootstrapProvider.overrideWithValue(boot),
      ],
      child: const MizanApp(),
    ),
  );
}
