import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';
import 'app/bootstrap.dart';
import 'app/providers.dart';
import 'app/startup_error.dart';
import 'core/database/app_database.dart' show AppDatabase;
import 'core/database/connection.dart';

/// Açılışta veritabanı bu süre içinde hazır olmazsa hata ekranı gösterilir.
const _startupTimeout = Duration(seconds: 25);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    final db = AppDatabase(openAppDatabaseConnection());
    final boot = await bootstrap(db).timeout(_startupTimeout);
    runApp(
      ProviderScope(
        overrides: [
          databaseProvider.overrideWithValue(db),
          bootstrapProvider.overrideWithValue(boot),
        ],
        child: const MizanApp(),
      ),
    );
  } catch (error, stack) {
    // Boş ekranda kalmak yerine hatayı göster.
    debugPrint('Mizan açılış hatası: $error\n$stack');
    final message = error is TimeoutException
        ? 'Veritabanı ${_startupTimeout.inSeconds} saniye içinde açılamadı.\n$error'
        : error.toString();
    runApp(StartupErrorApp(message: message, stack: stack.toString()));
  }
}
