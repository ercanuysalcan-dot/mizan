import 'package:flutter/material.dart';

import '../tokens/mizan_tokens.dart';
import '../tokens/spacing.dart';

class SectionHeader extends StatelessWidget {
  const SectionHeader(this.title, {super.key, this.trailing});
  final String title;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: Space.md, top: Space.sm),
      child: Row(
        children: [
          Expanded(child: Text(title.toUpperCase(), style: context.text.labelSmall)),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}
