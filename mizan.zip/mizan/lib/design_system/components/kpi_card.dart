import 'package:flutter/material.dart';

import '../../core/money/money.dart';
import '../tokens/mizan_tokens.dart';
import '../tokens/spacing.dart';
import 'mizan_card.dart';
import 'money_text.dart';

/// Dashboard KPI kartı.
class KpiCard extends StatelessWidget {
  const KpiCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    this.tone = MoneyTone.neutral,
    this.accent,
    this.footnote,
    this.onTap,
  });

  final String label;
  final Money value;
  final IconData icon;
  final MoneyTone tone;
  final Color? accent;
  final String? footnote;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = accent ?? context.colors.secondary;
    return MizanCard(
      onTap: onTap,
      padding: const EdgeInsets.all(Space.lg),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: const BorderRadius.all(Radius.circular(Radii.sm)),
                ),
                child: Icon(icon, size: 18, color: color),
              ),
              Space.gapSm,
              Expanded(
                child: Text(
                  label,
                  style: context.text.labelMedium!.copyWith(color: context.tokens.subtleText),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          Space.gapMd,
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: MoneyText(value, tone: tone, style: context.text.headlineSmall),
          ),
          if (footnote != null) ...[
            const SizedBox(height: Space.xs),
            Text(footnote!, style: context.text.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ],
      ),
    );
  }
}
