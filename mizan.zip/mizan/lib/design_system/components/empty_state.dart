import 'package:flutter/material.dart';

import '../tokens/mizan_tokens.dart';
import '../tokens/spacing.dart';

class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    this.message,
    this.action,
    this.compact = false,
  });

  final IconData icon;
  final String title;
  final String? message;
  final Widget? action;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: compact ? Space.lg : Space.xxl, horizontal: Space.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: compact ? 44 : 64,
            height: compact ? 44 : 64,
            decoration: BoxDecoration(color: context.tokens.mutedSurface, shape: BoxShape.circle),
            child: Icon(icon, size: compact ? 22 : 30, color: context.colors.secondary),
          ),
          Space.gapMd,
          Text(title, style: context.text.titleMedium, textAlign: TextAlign.center),
          if (message != null) ...[
            Space.gapXs,
            ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Text(message!, style: context.text.bodySmall, textAlign: TextAlign.center),
            ),
          ],
          if (action != null) ...[Space.gapLg, action!],
        ],
      ),
    );
  }
}
