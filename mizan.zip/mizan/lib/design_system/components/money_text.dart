import 'package:flutter/material.dart';

import '../../core/money/money.dart';
import '../../core/money/money_format.dart';
import '../tokens/mizan_theme.dart';
import '../tokens/mizan_tokens.dart';
import '../tokens/spacing.dart';

enum MoneyTone { neutral, signed, income, expense }

/// Tutar gösterimi: eşit genişlikli rakam, isteğe bağlı renk ve yumuşak geçiş.
class MoneyText extends StatelessWidget {
  const MoneyText(
    this.money, {
    super.key,
    this.style,
    this.tone = MoneyTone.neutral,
    this.showPlus = false,
    this.animate = true,
  });

  final Money money;
  final TextStyle? style;
  final MoneyTone tone;
  final bool showPlus;
  final bool animate;

  @override
  Widget build(BuildContext context) {
    final t = context.tokens;
    final color = switch (tone) {
      MoneyTone.neutral => null,
      MoneyTone.income => t.income,
      MoneyTone.expense => t.expense,
      MoneyTone.signed => money.isNegative ? t.expense : (money.isPositive ? t.income : null),
    };
    final text = Text(
      MoneyFormat.format(money, showPlus: showPlus),
      key: ValueKey(money),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: (style ?? context.text.titleMedium)!.copyWith(
        color: color ?? style?.color,
        fontFeatures: MizanTheme.tabular,
      ),
    );
    if (!animate) return text;
    return AnimatedSwitcher(
      duration: Motion.normal,
      switchInCurve: Motion.curve,
      transitionBuilder: (child, anim) => FadeTransition(
        opacity: anim,
        child: SlideTransition(
          position: Tween(begin: const Offset(0, 0.15), end: Offset.zero).animate(anim),
          child: child,
        ),
      ),
      child: text,
    );
  }
}
