import 'package:flutter/material.dart';

import '../tokens/colors.dart';
import '../tokens/mizan_tokens.dart';

/// Mizan işareti: terazinin iki kefesi gibi dengelenmiş iki çubuk —
/// çift kayıt dengesinin görsel karşılığı. Kod ile çizilir (görsel dosya yok).
class BrandMark extends StatelessWidget {
  const BrandMark({super.key, this.size = 32});
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: size,
      child: CustomPaint(painter: _MarkPainter(Theme.of(context).brightness)),
    );
  }
}

class _MarkPainter extends CustomPainter {
  _MarkPainter(this.brightness);
  final Brightness brightness;

  @override
  void paint(Canvas canvas, Size s) {
    final bg = Paint()..color = brightness == Brightness.light ? MizanPalette.navy900 : MizanPalette.navy800;
    canvas.drawRRect(RRect.fromRectAndRadius(Offset.zero & s, Radius.circular(s.width * 0.28)), bg);
    final w = s.width;
    final bar = Paint()
      ..color = MizanPalette.teal400
      ..strokeCap = StrokeCap.round
      ..strokeWidth = w * 0.11;
    final white = Paint()
      ..color = MizanPalette.white
      ..strokeCap = StrokeCap.round
      ..strokeWidth = w * 0.11;
    canvas.drawLine(Offset(w * 0.24, w * 0.40), Offset(w * 0.76, w * 0.40), white);
    canvas.drawLine(Offset(w * 0.24, w * 0.62), Offset(w * 0.76, w * 0.62), bar);
    canvas.drawCircle(Offset(w * 0.5, w * 0.40), w * 0.06, Paint()..color = MizanPalette.teal400);
  }

  @override
  bool shouldRepaint(covariant _MarkPainter old) => old.brightness != brightness;
}

class BrandWordmark extends StatelessWidget {
  const BrandWordmark({super.key, this.showText = true});
  final bool showText;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        const BrandMark(size: 30),
        if (showText) ...[
          const SizedBox(width: 10),
          Text('mizan',
              style: context.text.titleLarge!.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.6)),
        ],
      ],
    );
  }
}
