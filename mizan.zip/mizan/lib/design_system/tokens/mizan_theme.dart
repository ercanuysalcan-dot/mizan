import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';

import 'colors.dart';
import 'mizan_tokens.dart';
import 'spacing.dart';

/// Uygulamanın açık ve koyu temaları. Tüm ekranlar buradan beslenir.
abstract final class MizanTheme {
  static ThemeData light() => _build(
        Brightness.light,
        const ColorScheme(
          brightness: Brightness.light,
          primary: MizanPalette.navy900,
          onPrimary: MizanPalette.white,
          primaryContainer: MizanPalette.navy100,
          onPrimaryContainer: MizanPalette.navy900,
          secondary: MizanPalette.teal500,
          onSecondary: MizanPalette.navy950,
          secondaryContainer: MizanPalette.teal100,
          onSecondaryContainer: MizanPalette.navy900,
          tertiary: MizanPalette.teal600,
          onTertiary: MizanPalette.white,
          error: MizanPalette.expense,
          onError: MizanPalette.white,
          surface: MizanPalette.white,
          onSurface: MizanPalette.navy900,
          onSurfaceVariant: MizanPalette.slate500,
          surfaceContainerLowest: MizanPalette.white,
          surfaceContainerLow: Color(0xFFF7F9FC),
          surfaceContainer: MizanPalette.navy50,
          surfaceContainerHigh: Color(0xFFE9EEF6),
          surfaceContainerHighest: MizanPalette.navy100,
          outline: Color(0xFFC9D2E1),
          outlineVariant: MizanPalette.line,
        ),
        MizanTokens.light,
        scaffold: const Color(0xFFF4F6FA),
      );

  static ThemeData dark() => _build(
        Brightness.dark,
        const ColorScheme(
          brightness: Brightness.dark,
          primary: MizanPalette.teal400,
          onPrimary: MizanPalette.navy950,
          primaryContainer: MizanPalette.navy700,
          onPrimaryContainer: MizanPalette.navy50,
          secondary: MizanPalette.teal400,
          onSecondary: MizanPalette.navy950,
          secondaryContainer: Color(0xFF0D4752),
          onSecondaryContainer: MizanPalette.teal100,
          tertiary: MizanPalette.navy300,
          onTertiary: MizanPalette.navy950,
          error: MizanPalette.expenseDark,
          onError: MizanPalette.navy950,
          surface: Color(0xFF0C1A30),
          onSurface: Color(0xFFE8EEF8),
          onSurfaceVariant: MizanPalette.slate400,
          surfaceContainerLowest: Color(0xFF071224),
          surfaceContainerLow: Color(0xFF0A172B),
          surfaceContainer: Color(0xFF0F1F38),
          surfaceContainerHigh: Color(0xFF142744),
          surfaceContainerHighest: Color(0xFF1A3052),
          outline: Color(0xFF2B4266),
          outlineVariant: MizanPalette.lineDark,
        ),
        MizanTokens.dark,
        scaffold: const Color(0xFF060F1F),
      );

  static ThemeData _build(Brightness b, ColorScheme scheme, MizanTokens tokens, {required Color scaffold}) {
    final base = ThemeData(useMaterial3: true, brightness: b, colorScheme: scheme);
    final text = _textTheme(base.textTheme, scheme);
    return base.copyWith(
      scaffoldBackgroundColor: scaffold,
      textTheme: text,
      extensions: [tokens],
      appBarTheme: AppBarTheme(
        backgroundColor: scaffold,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        titleTextStyle: text.titleLarge,
        foregroundColor: scheme.onSurface,
      ),
      cardTheme: CardThemeData(
        color: scheme.surface,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: Radii.card, side: BorderSide(color: tokens.border)),
      ),
      dividerTheme: DividerThemeData(color: tokens.border, thickness: 1, space: 1),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        indicatorColor: scheme.secondaryContainer,
        height: 68,
        labelTextStyle: WidgetStateProperty.resolveWith(
          (s) => text.labelMedium!.copyWith(
            fontWeight: s.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: scheme.surface,
        indicatorColor: scheme.secondaryContainer,
        selectedLabelTextStyle: text.labelLarge!.copyWith(fontWeight: FontWeight.w700),
        unselectedLabelTextStyle: text.labelLarge!.copyWith(color: scheme.onSurfaceVariant),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(48, 48),
          padding: const EdgeInsets.symmetric(horizontal: Space.xl),
          shape: const RoundedRectangleBorder(borderRadius: Radii.control),
          textStyle: text.labelLarge!.copyWith(fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(48, 48),
          shape: const RoundedRectangleBorder(borderRadius: Radii.control),
          side: BorderSide(color: scheme.outline),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: scheme.secondary,
        foregroundColor: scheme.onSecondary,
        elevation: 2,
        shape: const RoundedRectangleBorder(borderRadius: Radii.control),
      ),
      chipTheme: ChipThemeData(
        shape: const RoundedRectangleBorder(borderRadius: Radii.pill),
        side: BorderSide(color: tokens.border),
        backgroundColor: scheme.surface,
        selectedColor: scheme.secondaryContainer,
        labelStyle: text.labelLarge,
        showCheckmark: false,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: tokens.mutedSurface,
        contentPadding: const EdgeInsets.symmetric(horizontal: Space.lg, vertical: Space.md),
        border: OutlineInputBorder(borderRadius: Radii.control, borderSide: BorderSide(color: tokens.border)),
        enabledBorder:
            OutlineInputBorder(borderRadius: Radii.control, borderSide: BorderSide(color: tokens.border)),
        focusedBorder:
            OutlineInputBorder(borderRadius: Radii.control, borderSide: BorderSide(color: scheme.secondary, width: 2)),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        showDragHandle: true,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(Radii.xl))),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: scheme.surface,
        surfaceTintColor: Colors.transparent,
        shape: const RoundedRectangleBorder(borderRadius: Radii.card),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: ButtonStyle(
          shape: const WidgetStatePropertyAll(RoundedRectangleBorder(borderRadius: Radii.control)),
          side: WidgetStatePropertyAll(BorderSide(color: tokens.border)),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        shape: const RoundedRectangleBorder(borderRadius: Radii.control),
        backgroundColor: b == Brightness.light ? MizanPalette.navy900 : MizanPalette.navy100,
        contentTextStyle: text.bodyMedium!.copyWith(
          color: b == Brightness.light ? MizanPalette.white : MizanPalette.navy950,
        ),
      ),
    );
  }

  static TextTheme _textTheme(TextTheme base, ColorScheme scheme) {
    TextStyle s(TextStyle? t, double size, FontWeight w, {double? height, double spacing = 0}) =>
        t!.copyWith(fontSize: size, fontWeight: w, height: height, letterSpacing: spacing, color: scheme.onSurface);
    return base.copyWith(
      displaySmall: s(base.displaySmall, 34, FontWeight.w700, height: 1.1, spacing: -0.8),
      headlineMedium: s(base.headlineMedium, 26, FontWeight.w700, height: 1.15, spacing: -0.5),
      headlineSmall: s(base.headlineSmall, 22, FontWeight.w700, height: 1.2, spacing: -0.3),
      titleLarge: s(base.titleLarge, 19, FontWeight.w700, spacing: -0.2),
      titleMedium: s(base.titleMedium, 16, FontWeight.w600),
      titleSmall: s(base.titleSmall, 14, FontWeight.w600),
      bodyLarge: s(base.bodyLarge, 15, FontWeight.w400, height: 1.45),
      bodyMedium: s(base.bodyMedium, 14, FontWeight.w400, height: 1.4),
      bodySmall: base.bodySmall!.copyWith(fontSize: 12, color: scheme.onSurfaceVariant),
      labelLarge: s(base.labelLarge, 14, FontWeight.w600),
      labelMedium: base.labelMedium!.copyWith(fontSize: 12, fontWeight: FontWeight.w600, letterSpacing: 0.2),
      labelSmall: base.labelSmall!.copyWith(
          fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.6, color: scheme.onSurfaceVariant),
    );
  }

  /// Tutarlar için eşit genişlikli rakamlar (sütunlar hizalı kalır).
  static const tabular = [FontFeature.tabularFigures()];
}
