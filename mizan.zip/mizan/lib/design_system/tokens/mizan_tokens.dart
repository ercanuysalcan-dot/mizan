import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

import 'colors.dart';

/// Material ColorScheme'in kapsamadığı anlamsal tasarım belirteçleri.
/// Erişim: `context.tokens`.
@immutable
class MizanTokens extends ThemeExtension<MizanTokens> {
  const MizanTokens({
    required this.income,
    required this.expense,
    required this.warning,
    required this.border,
    required this.subtleText,
    required this.mutedSurface,
    required this.heroGradient,
    required this.heroForeground,
    required this.chart,
    required this.cardElevationShadow,
  });

  final Color income;
  final Color expense;
  final Color warning;
  final Color border;
  final Color subtleText;
  final Color mutedSurface;
  final Gradient heroGradient;
  final Color heroForeground;
  final List<Color> chart;
  final double cardElevationShadow;

  static const light = MizanTokens(
    income: MizanPalette.income,
    expense: MizanPalette.expense,
    warning: MizanPalette.warning,
    border: MizanPalette.line,
    subtleText: MizanPalette.slate500,
    mutedSurface: MizanPalette.navy50,
    heroGradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [MizanPalette.navy900, MizanPalette.navy700],
    ),
    heroForeground: MizanPalette.white,
    chart: MizanPalette.chartLight,
    cardElevationShadow: 0.04,
  );

  static const dark = MizanTokens(
    income: MizanPalette.incomeDark,
    expense: MizanPalette.expenseDark,
    warning: MizanPalette.warning,
    border: MizanPalette.lineDark,
    subtleText: MizanPalette.slate400,
    mutedSurface: Color(0xFF0B1830),
    heroGradient: LinearGradient(
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
      colors: [Color(0xFF10294D), Color(0xFF0B4B5A)],
    ),
    heroForeground: MizanPalette.white,
    chart: MizanPalette.chartDark,
    cardElevationShadow: 0,
  );

  @override
  MizanTokens copyWith({Color? income, Color? expense}) => MizanTokens(
        income: income ?? this.income,
        expense: expense ?? this.expense,
        warning: warning,
        border: border,
        subtleText: subtleText,
        mutedSurface: mutedSurface,
        heroGradient: heroGradient,
        heroForeground: heroForeground,
        chart: chart,
        cardElevationShadow: cardElevationShadow,
      );

  @override
  MizanTokens lerp(ThemeExtension<MizanTokens>? other, double t) {
    if (other is! MizanTokens) return this;
    return MizanTokens(
      income: Color.lerp(income, other.income, t)!,
      expense: Color.lerp(expense, other.expense, t)!,
      warning: Color.lerp(warning, other.warning, t)!,
      border: Color.lerp(border, other.border, t)!,
      subtleText: Color.lerp(subtleText, other.subtleText, t)!,
      mutedSurface: Color.lerp(mutedSurface, other.mutedSurface, t)!,
      heroGradient: Gradient.lerp(heroGradient, other.heroGradient, t)!,
      heroForeground: Color.lerp(heroForeground, other.heroForeground, t)!,
      chart: t < 0.5 ? chart : other.chart,
      cardElevationShadow: lerpDouble(cardElevationShadow, other.cardElevationShadow, t)!,
    );
  }
}

extension MizanThemeContext on BuildContext {
  MizanTokens get tokens => Theme.of(this).extension<MizanTokens>()!;
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get text => Theme.of(this).textTheme;
}
