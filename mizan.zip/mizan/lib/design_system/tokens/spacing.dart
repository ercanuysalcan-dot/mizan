import 'package:flutter/widgets.dart';

/// 4 tabanlı boşluk ölçeği.
abstract final class Space {
  static const double xxs = 2;
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double lg = 16;
  static const double xl = 24;
  static const double xxl = 32;
  static const double xxxl = 48;

  static const gapXs = SizedBox(width: xs, height: xs);
  static const gapSm = SizedBox(width: sm, height: sm);
  static const gapMd = SizedBox(width: md, height: md);
  static const gapLg = SizedBox(width: lg, height: lg);
  static const gapXl = SizedBox(width: xl, height: xl);
}

abstract final class Radii {
  static const double sm = 10;
  static const double md = 14;
  static const double lg = 20;
  static const double xl = 28;

  static const card = BorderRadius.all(Radius.circular(lg));
  static const control = BorderRadius.all(Radius.circular(md));
  static const pill = BorderRadius.all(Radius.circular(999));
}

abstract final class Motion {
  static const fast = Duration(milliseconds: 150);
  static const normal = Duration(milliseconds: 260);
  static const slow = Duration(milliseconds: 420);
  static const curve = Curves.easeOutCubic;
}

/// Responsive kırılım noktaları (Material 3 pencere sınıfları).
enum WindowSize { compact, medium, expanded, large }

extension WindowSizeX on BoxConstraints {
  WindowSize get windowSize {
    final w = maxWidth;
    if (w < 600) return WindowSize.compact;
    if (w < 1024) return WindowSize.medium;
    if (w < 1440) return WindowSize.expanded;
    return WindowSize.large;
  }
}

WindowSize windowSizeOf(BuildContext context) {
  final w = MediaQuery.sizeOf(context).width;
  if (w < 600) return WindowSize.compact;
  if (w < 1024) return WindowSize.medium;
  if (w < 1440) return WindowSize.expanded;
  return WindowSize.large;
}
