import 'package:flutter/material.dart';

/// Mizan renk paleti. Ekranlar bu sabitleri doğrudan değil, tema ve
/// [MizanTokens] üzerinden kullanır.
abstract final class MizanPalette {
  // Lacivert ölçeği (marka ana rengi)
  static const navy950 = Color(0xFF050E1F);
  static const navy900 = Color(0xFF0A1A33);
  static const navy850 = Color(0xFF0E2242);
  static const navy800 = Color(0xFF132B52);
  static const navy700 = Color(0xFF1C3A6B);
  static const navy600 = Color(0xFF2A4F8C);
  static const navy300 = Color(0xFF8FA3C4);
  static const navy100 = Color(0xFFDDE5F2);
  static const navy50 = Color(0xFFF2F5FA);

  // Turkuaz vurgu
  static const teal500 = Color(0xFF16B8C4);
  static const teal400 = Color(0xFF3CD0DA);
  static const teal600 = Color(0xFF0E949F);
  static const teal100 = Color(0xFFD3F4F6);

  // Anlamsal
  static const income = Color(0xFF12A66B);
  static const incomeDark = Color(0xFF34D399);
  static const expense = Color(0xFFE0474C);
  static const expenseDark = Color(0xFFFF7A7E);
  static const warning = Color(0xFFE8A317);

  // Nötrler
  static const white = Color(0xFFFFFFFF);
  static const slate500 = Color(0xFF5A6A84);
  static const slate400 = Color(0xFF8A98AF);
  static const line = Color(0xFFE3E8F1);
  static const lineDark = Color(0xFF1D2F4F);

  /// Grafik serileri — açık ve koyu temada okunur, renk körlüğüne duyarlı sıralı.
  static const chartLight = [
    Color(0xFF16B8C4), // turkuaz
    Color(0xFF2A4F8C), // lacivert
    Color(0xFF7C6CF2), // mor
    Color(0xFFE8A317), // amber
    Color(0xFF12A66B), // yeşil
    Color(0xFFE0474C), // kırmızı
    Color(0xFF8A98AF), // gri
  ];

  static const chartDark = [
    Color(0xFF3CD0DA),
    Color(0xFF6F93D6),
    Color(0xFF9D91FF),
    Color(0xFFF2BC4B),
    Color(0xFF34D399),
    Color(0xFFFF7A7E),
    Color(0xFF8FA3C4),
  ];
}
