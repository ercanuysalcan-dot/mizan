{{flutter_js}}
{{flutter_build_config}}

// Flutter'in kendi service worker'i kullanilmiyor; yerine sw.js kayitli.
_flutter.loader.load();
