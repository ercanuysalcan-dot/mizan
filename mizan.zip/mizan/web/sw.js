// Mizan service worker: uygulamanin "yuklenebilir" olmasini ve
// internet yokken acilmasini saglar. Strateji: once ag, yoksa onbellek.
// Boylece internet varken her zaman en yeni surum gelir.
const CACHE = 'mizan-v1';

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) {
      if (key !== CACHE) await caches.delete(key);
    }
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const res = await fetch(req);
      if (res && res.ok && res.type === 'basic') {
        cache.put(req, res.clone());
      }
      return res;
    } catch (err) {
      const hit = await cache.match(req, { ignoreSearch: true });
      if (hit) return hit;
      if (req.mode === 'navigate') {
        const home = await cache.match('./', { ignoreSearch: true })
          || await cache.match('index.html', { ignoreSearch: true });
        if (home) return home;
      }
      throw err;
    }
  })());
});
