# Test raporu

Tarih: 22 Kasım 2026

## Ortam kısıtı

Bu aşamanın geliştirildiği ortamda Flutter/Dart SDK ve Android SDK yoktu ve kurulamadı (internet erişimi kapalı).
Bu yüzden testler iki gruba ayrılır: **burada çalıştırılanlar** ve **yazılmış, senin cihazında çalıştırılacaklar**.
Çalıştırılmamış testler geçmiş gibi gösterilmez.

## A. Burada çalıştırıldı — GEÇTİ

### Şema ve muhasebe tetikleyicileri — `tools/verify_schema.py` (SQLite 3.53.1): **16/16**

| Test | Doğruladığı |
|---|---|
| schema_loads | Şema hatasız yükleniyor, tüm tetikleyiciler var |
| balanced_transfer_keeps_total | Transfer toplam varlığı değiştirmiyor |
| unbalanced_rejected | Dengesiz kayıt reddediliyor ve tamamen geri alınıyor |
| single_line_rejected | Tek satırlı kayıt reddediliyor |
| multi_currency_balanced_per_currency | Her para birimi ayrı dengelenmeli; birimler arası "toplam" kabul edilmiyor |
| line_currency_must_match_account | Hesapla farklı para birimli satır reddediliyor |
| posted_lines_immutable | Kesinleşmiş satır/başlık değiştirilemiyor, silinemiyor; sync_status güncellenebiliyor |
| status_flow | Yalnızca draft→posted→reversed |
| idempotency | Aynı anahtarlı işlem ikinci kez yazılmıyor |
| reversal_once_and_nets_zero | İptal bakiyeyi sıfırlıyor, ikinci iptal reddediliyor |
| credit_card_flow | Harcama kart borcunu artırıyor, ödeme bankadan düşüp borcu azaltıyor |
| cari_collection | Veresiye + kısmi tahsilat sonrası kalan doğru |
| account_rules | Tür/yön tutarlılığı; hareketli hesabın para birimi değişmiyor |
| line_shape | Satırda hem borç hem alacak / negatif tutar reddediliyor |
| audit_append_only | Denetim kaydı değiştirilemiyor/silinemiyor |
| stock_append_only | Stok hareketi değiştirilemiyor/silinemiyor |

### Dart koddaki ham SQL sorguları: **36/36** sözdizimi geçerli

Repository dosyalarındaki tüm `customSelect/Insert/Update` sorguları gerçek şemaya karşı `EXPLAIN` ile derlendi.

### Statik denetim

54 `lib` + 6 `test` dosyasında içe aktarma yolları ve parantez dengesi denetlendi: sorun yok.
(Bu, Dart derleyicisinin yerini tutmaz; tür hataları için `flutter analyze` gerekir.)

## B. Yazıldı — cihazında çalıştırılacak (`flutter test`)

| Dosya | Test | Kapsam |
|---|---|---|
| `test/core/money_test.dart` | 11 | Türkçe tutar çözme, yuvarlamak yerine reddetme, 0,1+0,2=0,3, para birimi karışması, taksit bölme kuruş kaybı, half-even, biçimlendirme |
| `test/accounting/ledger_test.dart` | 17 | Açılış bakiyesi yönleri, gelir/gider, transfer, kart harcama/ödeme, cari tahsilat/ödeme, idempotency, dengesizlik, para birimi uyuşmazlığı, DB değişmezliği, arşiv, iptal (tek sefer, orijinal tarih, denetim kaydı), `asOf`, 200 işlemlik denge |
| `test/dashboard/dashboard_test.dart` | 5 | Varlık/borç/alacak sınıflandırması, aylık dağıtım, kart düzeni, dönem filtresi + dönem sonu bakiyesi, örnek veri yükleme ve ters kayıtla tam kaldırma |
| `test/design_system/components_test.dart` | 3 | KpiCard, MoneyText renk tonu, koyu tema |
| `test/widget_test.dart` | 1 | Uygulamanın tamamı bellek içi DB ile açılıyor, başlangıç ekranı görünüyor |

**Toplam 37 Dart testi.** Lütfen şunları çalıştırıp çıktıyı gönder:

```bash
flutter analyze
flutter test
```

## C. Bu aşamada henüz yok

Android cihaz testi, Web tarayıcı testi, integration testleri, senkronizasyon / internet kesintisi / yetkilendirme testleri
— ilgili özellikler sonraki aşamalarda geldikçe eklenecek.


---

# Aşama 2a — banka kredisi, kart ekstresi, düzeltme, kategoriler

Tarih: 23 Kasım 2026 · Ortam yine Flutter/Dart SDK'sız (internet erişimi kapalı).

## A. Burada çalıştırıldı — GEÇTİ

* `tools/verify_schema.py`: **20/20** (Aşama 1'in 16 testi + 4 yeni):
  * `migration_v1_to_v2_matches_fresh_schema` — v1 veritabanı verilerle kurulur, geçiş çalıştırılır;
    yabancı anahtar ve bütünlük denetimi temiz, hesap sayısı ve bakiyeler aynı, sütunlar ve tablo
    tanımları sıfırdan kurulan v2 ile aynı, tetikleyiciler geçişten sonra da çalışıyor.
  * `loan_flow` — 114.000 / 12 taksit, ödeme borcu ve bankayı düşürüyor; bir ödeme iki taksite bağlanamıyor.
  * `statement_and_attachment` — dönem borcu kart borcuna işleniyor, görüntü BLOB olarak saklanıyor.
  * `edit_is_reverse_plus_new` — düzeltmede bakiye yalnızca yeni tutarı yansıtıyor.
* Dart'taki ham SQL: **93/93** sorgu gerçek şemaya karşı `EXPLAIN` ile derlendi
  (örnek veri yükleyicideki dinamik `IN (...)` sorgusu bu araçla çözülemedi; Aşama 1'de denetlenmişti).
* 84 Dart dosyasında içe aktarma yolları ve parantez dengesi: sorun yok.

## B. Yazıldı — cihazda / GitHub Actions'ta çalışacak

| Dosya | Kapsam |
|---|---|
| `test/stage2/loan_test.dart` | Plan toplamı, ay sonu vadesi, taksit ödeme + idempotency, çift ödeme engeli, ödeme düzeltme (taksit yeni kayda bağlı kalır), geri alma, önceden ödenmiş taksitler, kredi bilgisi düzenleme |
| `test/stage2/edit_and_category_test.dart` | Tutar/kategori/hesap düzeltme + değişiklik geçmişi, düzenleme idempotency, ekin yeni kayda taşınması, alt kategori sırası, aynı ad engeli, tek seviye kuralı, yeniden adlandırma, kayıtları taşıyarak silme, ekstre ekle/düzelt/borçtan çıkar/sil |

GitHub Actions bu testleri her yüklemede çalıştırır (“Testler” adımı).
