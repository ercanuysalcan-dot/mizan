# Mizan — Mimari

Mizan; Android ve Web'de çalışan, çevrimdışı öncelikli, çift kayıtlı bir finans ve
işletme muhasebe platformudur. Bu belge bütün projenin hedef mimarisini ve
Aşama 1'de gerçekten kurulan kısmı anlatır.

## 1. Katmanlar

```
presentation  (Widget'lar, ekranlar)          ← yalnızca application'a bakar
     │
application   (Riverpod Notifier/Provider = ViewModel, uygulama servisleri)
     │
domain        (saf Dart: Money, AccountKind, PostingRules, repository arayüzleri)
     │
data          (Drift/SQLite uygulamaları, ileride Supabase senkron adaptörü)
```

* **Domain saf Dart'tır**; Flutter'a ve veritabanına bağımlı değildir, birim testle doğrulanır.
* **Repository Pattern:** `LedgerRepository` bir arayüzdür; `DriftLedgerRepository` onun SQLite uygulamasıdır.
* **Dependency Injection:** `lib/app/providers.dart` tek köktür. `main.dart` açılmış veritabanını
  ve bootstrap sonucunu `overrideWithValue` ile verir; testler bellek içi veritabanı verir.
* **MVVM:** Ekran durumu Notifier'larda (ör. `DashboardPeriodNotifier`), ekranlar yalnızca `ref.watch` eder.

## 2. Klasör yapısı (özellik tabanlı)

```
lib/
  main.dart                     Giriş: DB aç → bootstrap → ProviderScope
  app/                          Uygulama kabuğu, yönlendirme, DI kökü
    app.dart  router.dart  providers.dart  bootstrap.dart
    shell/app_shell.dart        Telefonda alt çubuk, tablette ray, geniş ekranda menü
  core/
    money/                      Money (tam sayı kuruş), Currency, biçimlendirme
    database/                   AppDatabase, platform bağlantısı, schema/core.drift
    errors/                     AppException, LedgerException (kodlu)
    utils/                      UUID v7, Clock, DateRange, Türkçe tarih biçimi
  design_system/                Renk, tipografi, boşluk, tema, ortak bileşenler
  features/
    accounting/                 ★ Muhasebe motoru (domain + data)
    accounts/                   Hesap oluşturma, liste, kategoriler
    transactions/               Hızlı işlem formu, işlem detayı / iptal
    dashboard/                  Göstergeler, grafikler, kart düzeni
    settings/                   Tema, örnek veri, defter doğrulama
    demo/                       Motor üzerinden örnek veri yükleyici
test/                           Birim, veritabanı ve widget testleri
tools/verify_schema.py          Şemayı gerçek SQLite'ta test eder (Flutter gerekmez)
```

Sonraki aşamalarda her modül aynı kalıpla eklenir: `features/<modül>/{domain,data,application,presentation}`.

## 3. Muhasebe motoru (projenin çekirdeği)

**Her finansal olay tek yoldan geçer:**

```
Form → Uygulama servisi → PostingRules (saf, satırları üretir) → LedgerRepository.post() → SQLite
```

### 3.1 Kurallar ve nasıl zorlandıkları

| Kural | Dart katmanı | Veritabanı katmanı |
|---|---|---|
| Her işlem dengeli (para birimi başına borç = alacak) | `_validateShape` | `journal_entries_balanced_on_post` tetikleyicisi |
| En az iki satır | `_validateShape` | aynı tetikleyici |
| Satır para birimi = hesap para birimi | `post()` kontrolü | `journal_lines_match_account` |
| Kesinleşen kayıt değişmez/silinmez | — | `journal_lines_immutable`, `*_no_delete` |
| Aynı işlem iki kez yazılmaz | anahtar ön kontrolü | `journal_entries_idempotency` benzersiz indeksi |
| Bir kayıt yalnızca bir kez iptal edilir | durum kontrolü | `journal_entries_single_reversal` |
| Durum akışı draft → posted → reversed | — | `journal_entries_status_flow` |
| Hareketi olan hesabın türü/para birimi değişmez | — | `accounts_lock_used` |
| Atomiklik | `db.transaction` | SQLite işlemi |
| Denetim kaydı | her post/reverse/hesap değişikliği | `audit_log` ekleme-yalnız |

### 3.2 Yazma akışı

1. Taslak (`draft`) başlık eklenir.
2. Satırlar eklenir (tetikleyici yalnızca taslağa izin verir).
3. Durum `posted` yapılır → tetikleyici dengeyi doğrular, değilse **tüm işlem geri alınır**.
4. Denetim kaydı yazılır. Hepsi tek veritabanı işlemindedir.

### 3.3 İptal ve düzenleme

Kesinleşmiş kayıt **asla** değiştirilmez. İptal = ters kayıt (storno): satırların yönleri çevrilmiş,
**orijinal tarihli** yeni bir `iptal` kaydı + orijinalin durumu `reversed`. Böylece dönem raporları
iptalden sonra da doğru kalır. Düzenleme (Aşama 2) = iptal + yeni kayıt, aynı işlemde.

### 3.4 Bakiyeler

Bakiye tablosu/önbelleği yoktur. Her bakiye `journal_lines` toplamından hesaplanır; dolayısıyla
"bakiye işlem geçmişinden doğrulanabilir" şartı tanım gereği sağlanır. Ayarlar → *Defter bütünlüğü*
tüm defteri baştan doğrular. Performans gerekirse ileride, satırlardan yeniden üretilebilen
dönem kapanış özetleri eklenecek.

### 3.5 Para

* `Money` = tam sayı minor unit + para birimi. Double hiç kullanılmaz.
* Kullanıcı girdisi `Money.parse` ile çözülür; fazla ondalık **yuvarlanmaz, reddedilir**.
* Oran/kur/yüzde işlemleri BigInt ile, yuvarlama kuralı açıkça seçilerek yapılır (varsayılan half-even).
* Taksit bölme `allocate()` ile — parçaların toplamı her zaman orijinale eşit.
* Web'de güvenli tam sayı sınırı (2^53−1) her işlemde denetlenir.
* Grafikler yalnızca piksel konumu için double kullanır; ekranda görünen her tutar Money'den biçimlenir.

### 3.6 Çoklu para birimi

Her hesabın tek para birimi vardır. Bir işlem birden fazla para birimi içerebilir ama **her para
biriminde ayrı ayrı** dengeli olmalıdır. Döviz çevirme `kur_farki` ara hesabı üzerinden yapılacaktır
(şema hazır, ekran Aşama 4). Dashboard seçili para biriminde gösterir; birimler arası toplam
kur verisi gelince eklenecek — o zamana kadar farklı birimler asla sessizce toplanmaz.

## 4. Çevrimdışı ve senkronizasyon tasarımı (Aşama 5)

* Her kayıtta: `id` (UUID v7), `created_at`, `updated_at`, `device_id`, `sync_status`, `version`.
* **Defter ekleme-yalnız olduğu için çakışmasızdır:** iki cihazın yazdığı farklı kayıtlar birleşir;
  aynı `idempotency_key` sunucuda benzersiz kısıtla reddedilir → tekrarlanan kayıt oluşmaz.
* Değişebilir ana veriler (hesap adı, kategori, cari bilgisi) için `version` ile iyimser kilit:
  çakışmada **üzerine yazılmaz**, kayıt `sync_status = 2 (çakışma)` olur ve kullanıcıya iki sürüm gösterilir.
* İptal çakışması (iki cihaz aynı kaydı iptal etti) `single_reversal` kısıtıyla yakalanır; ikinci ters kayıt
  sunucuda reddedilir ve yerelde geri alınır.
* Silme yok: `deleted_at` (yumuşak silme) + denetim kaydı.

## 5. Bulut (Aşama 5) — Supabase

* Postgres şeması yerel şemanın aynısı + `business_members(business_id, user_id, role)`.
* RLS: her tabloda `business_id IN (SELECT business_id FROM business_members WHERE user_id = auth.uid())`.
  Personel tabloları ek olarak `role IN ('owner','admin','hr')` ister.
* Anahtarlar kaynak koda yazılmaz: `--dart-define=SUPABASE_URL=… --dart-define=SUPABASE_ANON_KEY=…`.
  Uygulamada yalnızca *anon* anahtar bulunur; yetki RLS ile sağlanır. `service_role` anahtarı asla istemciye girmez.
* Bulut isteğe bağlıdır; uygulama hesap açmadan tamamen yerel çalışır.

## 6. Güvenlik planı

| Konu | Aşama |
|---|---|
| Defter değişmezliği, denetim kaydı | ✅ Aşama 1 |
| Yerel PIN / biyometrik kilit (`local_auth`), arka planda otomatik kilit | Aşama 6 |
| Yerel veritabanı şifreleme (SQLCipher, Android) | Aşama 6 |
| Rol bazlı yetki (personel bilgisini yetkisize gizleme) | Aşama 5–6 |
| Veri dışa aktarma, hesap kapatma, yerel veriyi silme | Aşama 6 |
