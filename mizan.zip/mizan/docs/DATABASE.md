# Veritabanı şeması

Kaynak: `lib/core/database/schema/core.drift` (saf SQLite sözdizimi; Drift bu dosyadan Dart kodu üretir).
Doğrulama: `python3 tools/verify_schema.py`.

## Ortak sütunlar

Senkronlanan her tabloda: `id TEXT` (UUID v7) · `created_at`, `updated_at` (UTC epoch ms) ·
`device_id` · `sync_status` (0 bekliyor, 1 senkron, 2 çakışma) · `version`. Ana verilerde `deleted_at`.

Para: `*_minor INTEGER` (kuruş). Miktar: `quantity_micro INTEGER` (1/1.000.000 birim; gram altın, stok).

## Tablolar

| Tablo | Amaç | Aşama |
|---|---|---|
| `businesses` | İşletme (çoklu işletme altyapısı), ana para birimi | 1 ✅ |
| `categories` | Gelir/gider kategorileri (mantıksal) | 1 ✅ |
| `accounts` | Tüm defter hesapları: 7 kullanıcı türü + gelir/gider/özkaynak/kur farkı | 1 ✅ |
| `cari_details` | Müşteri/tedarikçi, kişi/firma, iletişim, vergi bilgileri | şema ✅, ekran 2 |
| `bank_details` | Banka adı, IBAN, şube | şema ✅, ekran 2 |
| `card_details` | Limit, ekstre günü, son ödeme günü, son 4 hane | şema ✅, ekran 2 |
| `employee_details` | Ad soyad, görev, maaş, ödeme günü | şema ✅, ekran 3 |
| `savings_details` | Varlık tipi (gram/çeyrek altın, döviz…) | şema ✅, ekran 4 |
| `journal_entries` | İşlem başlığı (tür, tarih, durum, idempotency) | 1 ✅ |
| `journal_lines` | Çift kayıt satırları (borç/alacak) | 1 ✅ |
| `stock_items`, `stock_movements` | Ürün kartı, ekleme-yalnız stok hareketleri | şema ✅, ekran 3 |
| `card_installments` | Taksit takvimi | şema ✅, ekran 2 |
| `recurring_rules` | Tekrarlanan işlemler | şema ✅, ekran 4 |
| `price_quotes` | Altın/döviz fiyatları (son fiyat + tarihi) | şema ✅, ekran 4 |
| `audit_log` | Ekleme-yalnız denetim kaydı | 1 ✅ |
| `app_settings` | Cihaza özel ayarlar (senkronlanmaz) | 1 ✅ |

## Hesap türleri ve bakiye yönleri

| Tür | Sınıf | Normal yön | Pozitif bakiye | Negatif bakiye |
|---|---|---|---|---|
| `kasa` | Varlık | Borç (D) | Kasadaki nakit | — |
| `banka` | Varlık | D | Hesaptaki para | Ek hesap kullanımı |
| `birikim` | Varlık | D | Maliyet değeri | — |
| `stok` | Varlık | D | Stok değeri | — |
| `cari` | Varlık | D | **Alacak** (bize borçlu) | **Borç** (biz borçluyuz) |
| `kredi_karti` | Borç | Alacak (C) | Kart borcu | Fazla ödeme |
| `personel` | Borç | C | Ödenecek | Verilen avans |
| `gelir` | Gelir | C | Dönem geliri | — |
| `gider` | Gider | D | Dönem gideri | — |
| `ozkaynak` | Özkaynak | C | Açılış bakiyeleri karşılığı | — |
| `kur_farki` | Sistem | D | Döviz çevrim ara hesabı | — |

Bakiye = normal yön D ise `Σborç − Σalacak`, C ise `Σalacak − Σborç`.

## İşlem → kayıt örnekleri

| Olay | Borç (D) | Alacak (C) | Sonuç |
|---|---|---|---|
| Kasaya 1.000 satış geliri | Kasa 1.000 | Satış 1.000 | Kasa ↑, gelir ↑ |
| Bankadan 300 kira | Kira 300 | Banka 300 | Gider ↑, banka ↓ |
| Kartla 750 market | Market 750 | Kart 750 | Gider ↑, **kart borcu ↑**, banka değişmez |
| Bankadan karta 500 ödeme | Kart 500 | Banka 500 | **Kart borcu ↓**, banka ↓, gider değişmez |
| Kasadan bankaya 400 | Banka 400 | Kasa 400 | **Toplam varlık değişmez** |
| Cariye 1.200 veresiye satış | Cari 1.200 | Satış 1.200 | Alacak ↑ |
| Cariden 450 tahsilat | Kasa 450 | Cari 450 | Alacak 750'ye iner |
| Tedarikçiye 2.000 ödeme | Cari 2.000 | Banka 2.000 | Borcumuz ↓ |
| Kasa açılışı 1.000 | Kasa 1.000 | Açılış Bakiyeleri 1.000 | |
| Kart açılış borcu 250 | Açılış Bakiyeleri 250 | Kart 250 | |
| Yukarıdaki kiranın iptali | Banka 300 | Kira 300 | Orijinal tarihle ters kayıt |

## Tetikleyiciler

| Ad | Engellediği |
|---|---|
| `journal_lines_insert_only_draft` | Kesinleşmiş kayda satır eklemek |
| `journal_lines_match_account` | Hesapla farklı para birimi/işletmede satır |
| `journal_lines_immutable`, `journal_lines_no_delete` | Kesinleşmiş satırı değiştirmek/silmek (sync_status serbest) |
| `journal_entries_status_flow` | draft→posted→reversed dışındaki geçişler |
| `journal_entries_balanced_on_post` | Dengesiz veya tek satırlı kaydı kesinleştirmek |
| `journal_entries_immutable`, `journal_entries_no_delete` | Kesinleşmiş başlığın tarih/tür vb. değişimi, silinmesi |
| `accounts_lock_used`, `accounts_no_delete_used` | Hareketi olan hesabın tür/para birimi değişimi, silinmesi |
| `stock_movements_immutable`, `stock_movements_no_delete` | Stok hareketi değişimi/silinmesi |
| `audit_log_immutable`, `audit_log_no_delete` | Denetim kaydını değiştirmek/silmek |

## Şema değişiklikleri

`AppDatabase.schemaVersion` artırılır ve `MigrationStrategy.onUpgrade` adımı yazılır.
Drift'in `drift_dev schema dump` / `schema steps` araçlarıyla geçişler test edilir (Aşama 2'de eklenecek).
