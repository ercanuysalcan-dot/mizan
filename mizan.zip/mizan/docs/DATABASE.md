# Veritabanı şeması

Kaynak: `lib/core/database/schema/core.drift` (saf SQLite sözdizimi; Drift bu dosyadan Dart kodu üretir).
Doğrulama: `python3 tools/verify_schema.py`.

## Ortak sütunlar

Senkronlanan her tabloda: `id TEXT` (UUID v7) · `created_at`, `updated_at` (UTC epoch ms) ·
`device_id` · `sync_status` (0 bekliyor, 1 senkron, 2 çakışma) · `version`. Ana verilerde `deleted_at`.

Para: `*_minor INTEGER` (kuruş). Miktar: `quantity_micro INTEGER` (1/1.000.000 birim; gram altın, stok).

## Tablolar

| Tablo | Amaç | Aşama |
|---|---|---|
| `businesses` | İşletme (çoklu işletme altyapısı), ana para birimi | 1 ✅ |
| `categories` | Gelir/gider kategorileri (mantıksal) | 1 ✅ |
| `accounts` | Tüm defter hesapları: 8 kullanıcı türü (v2: `kredi`) + gelir/gider/özkaynak/kur farkı | 1 ✅ |
| `cari_details` | Müşteri/tedarikçi, kişi/firma, iletişim, vergi bilgileri | şema ✅, ekran 2 |
| `bank_details` | Banka adı, IBAN, şube | şema ✅, ekran 2 |
| `card_details` | Limit, ekstre günü, son ödeme günü, son 4 hane | şema ✅, ekran 2 |
| `employee_details` | Ad soyad, görev, maaş, ödeme günü | şema ✅, ekran 3 |
| `savings_details` | Varlık tipi (gram/çeyrek altın, döviz…) | şema ✅, ekran 4 |
| `journal_entries` | İşlem başlığı (tür, tarih, durum, idempotency) | 1 ✅ |
| `journal_lines` | Çift kayıt satırları (borç/alacak) | 1 ✅ |
| `stock_items`, `stock_movements` | Ürün kartı, ekleme-yalnız stok hareketleri | şema ✅, ekran 3 |
| `card_installments` | Taksit takvimi | şema ✅, ekran 2 |
| `recurring_rules` | Tekrarlanan işlemler | şema ✅, ekran 4 |
| `price_quotes` | Altın/döviz fiyatları (son fiyat + tarihi) | şema ✅, ekran 4 |
| `loan_details` | Banka kredisi: toplam borç, taksit sayısı/tutarı, ilk vade, açılış kaydı | 2 ✅ (v2) |
| `loan_installments` | Kredi ödeme planı; `paid_entry_id` = ödeme kaydı, `prepaid` = takip öncesi ödendi | 2 ✅ (v2) |
| `card_statements` | Kart dönem borcu (ekstre); `entry_id` doluysa tutar kart borcuna işlendi | 2 ✅ (v2) |
| `attachments` | Ekstre / fiş görüntüleri (BLOB, çevrimdışı) | 2 ✅ (v2) |
| `audit_log` | Ekleme-yalnız denetim kaydı | 1 ✅ |
| `app_settings` | Cihaza özel ayarlar (senkronlanmaz) | 1 ✅ |

## Hesap türleri ve bakiye yönleri

| Tür | Sınıf | Normal yön | Pozitif bakiye | Negatif bakiye |
|---|---|---|---|---|
| `kasa` | Varlık | Borç (D) | Kasadaki nakit | — |
| `banka` | Varlık | D | Hesaptaki para | Ek hesap kullanımı |
| `birikim` | Varlık | D | Maliyet değeri | — |
| `stok` | Varlık | D | Stok değeri | — |
| `cari` | Varlık | D | **Alacak** (bize borçlu) | **Borç** (biz borçluyuz) |
| `kredi_karti` | Borç | Alacak (C) | Kart borcu | Fazla ödeme |
| `kredi` | Borç | C | Kalan kredi borcu | Fazla ödeme |
| `personel` | Borç | C | Ödenecek | Verilen avans |
| `gelir` | Gelir | C | Dönem geliri | — |
| `gider` | Gider | D | Dönem gideri | — |
| `ozkaynak` | Özkaynak | C | Açılış bakiyeleri karşılığı | — |
| `kur_farki` | Sistem | D | Döviz çevrim ara hesabı | — |

Bakiye = normal yön D ise `Σborç − Σalacak`, C ise `Σalacak − Σborç`.

## İşlem → kayıt örnekleri

| Olay | Borç (D) | Alacak (C) | Sonuç |
|---|---|---|---|
| Kasaya 1.000 satış geliri | Kasa 1.000 | Satış 1.000 | Kasa ↑, gelir ↑ |
| Bankadan 300 kira | Kira 300 | Banka 300 | Gider ↑, banka ↓ |
| Kartla 750 market | Market 750 | Kart 750 | Gider ↑, **kart borcu ↑**, banka değişmez |
| Bankadan karta 500 ödeme | Kart 500 | Banka 500 | **Kart borcu ↓**, banka ↓, gider değişmez |
| Kasadan bankaya 400 | Banka 400 | Kasa 400 | **Toplam varlık değişmez** |
| Cariye 1.200 veresiye satış | Cari 1.200 | Satış 1.200 | Alacak ↑ |
| Cariden 450 tahsilat | Kasa 450 | Cari 450 | Alacak 750'ye iner |
| Tedarikçiye 2.000 ödeme | Cari 2.000 | Banka 2.000 | Borcumuz ↓ |
| Kasa açılışı 1.000 | Kasa 1.000 | Açılış Bakiyeleri 1.000 | |
| Kart açılış borcu 250 | Açılış Bakiyeleri 250 | Kart 250 | |
| Yukarıdaki kiranın iptali | Banka 300 | Kira 300 | Orijinal tarihle ters kayıt |
| Kredi açılışı 114.000 (toplam geri ödeme) | Açılış Bakiyeleri 114.000 | Kredi 114.000 | Kredi borcu ↑ |
| 1. taksit 9.500 bankadan | Kredi 9.500 | Banka 9.500 | **Kredi borcu ↓**, banka ↓ |
| Kart dönem borcu 8.750 (borca ekle açık) | Kredi Kartı Harcamaları 8.750 | Kart 8.750 | Kart borcu ↑ |
| Düzeltme: 5.900 yerine 9.500 | iptal (ters kayıt) + yeni kayıt | | Eski hal `audit_log`'da |

## Tetikleyiciler

| Ad | Engellediği |
|---|---|
| `journal_lines_insert_only_draft` | Kesinleşmiş kayda satır eklemek |
| `journal_lines_match_account` | Hesapla farklı para birimi/işletmede satır |
| `journal_lines_immutable`, `journal_lines_no_delete` | Kesinleşmiş satırı değiştirmek/silmek (sync_status serbest) |
| `journal_entries_status_flow` | draft→posted→reversed dışındaki geçişler |
| `journal_entries_balanced_on_post` | Dengesiz veya tek satırlı kaydı kesinleştirmek |
| `journal_entries_immutable`, `journal_entries_no_delete` | Kesinleşmiş başlığın tarih/tür vb. değişimi, silinmesi |
| `accounts_lock_used`, `accounts_no_delete_used` | Hareketi olan hesabın tür/para birimi değişimi, silinmesi |
| `stock_movements_immutable`, `stock_movements_no_delete` | Stok hareketi değişimi/silinmesi |
| `audit_log_immutable`, `audit_log_no_delete` | Denetim kaydını değiştirmek/silmek |

## Şema değişiklikleri

`AppDatabase.schemaVersion` artırılır, geçiş SQL'i `lib/core/database/migrations.dart` dosyasına yazılır.

* **v1 → v2:** `accounts` CHECK kısıtına `kredi` eklendi (SQLite'ta CHECK değiştirilemediği için tablo
  yeniden kurulur: yeni tablo → kopyala → eski tabloyu sil → yeniden adlandır → indeks/tetikleyiciler),
  `loan_details`, `loan_installments`, `card_statements`, `attachments` tabloları eklendi.
* `tools/verify_schema.py`, v1 şemasını (`tools/fixtures/schema_v1.sql`) verilerle kurar, geçişi çalıştırır;
  sonucun sıfırdan kurulan v2 şemasıyla aynı olduğunu, bakiyelerin değişmediğini ve tetikleyicilerin
  çalıştığını doğrular.
