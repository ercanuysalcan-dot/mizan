# Tasarım sistemi

Kod: `lib/design_system/` — tek giriş `design_system.dart`.

## Kimlik

* **Ad:** mizan — "terazi, denge"; çift kaydın dengesine gönderme.
* **İşaret:** Lacivert kare üstünde iki dengeli çubuk (beyaz + turkuaz) ve merkez noktası. Kodla çizilir (`BrandMark`).
* **Ton:** Sakin, güven veren, kurumsal ama soğuk değil. Süsleme yerine boşluk ve tipografi.

## Renkler (`tokens/colors.dart`)

| Rol | Açık | Koyu |
|---|---|---|
| Ana (primary) | Lacivert `#0A1A33` | Turkuaz `#3CD0DA` |
| Vurgu (secondary) | Turkuaz `#16B8C4` | Turkuaz `#3CD0DA` |
| Zemin | `#F4F6FA` | `#060F1F` |
| Yüzey (kart) | Beyaz | `#0C1A30` |
| Gelir | `#12A66B` | `#34D399` |
| Gider / borç | `#E0474C` | `#FF7A7E` |
| Uyarı | `#E8A317` | `#E8A317` |
| Çizgi | `#E3E8F1` | `#1D2F4F` |

Ekranlar renkleri doğrudan değil, `Theme.of(context).colorScheme` ve `context.tokens`
(`MizanTokens` tema uzantısı: gelir, gider, kenarlık, soluk metin, kahraman degradesi, grafik paleti) üzerinden kullanır.
Grafik paleti 7 renk, açık/koyu için ayrı ayarlanmıştır.

## Tipografi

Sistem yazı tipi (Android: Roboto). Başlıklarda negatif harf aralığı, tutarlarda **eşit genişlikli rakam**
(`MizanTheme.tabular`) — sütunlar hizalı kalır. Ölçek: display 34 · headline 26/22 · title 19/16/14 · body 15/14 · label 14/12/11.

> Not: Özel bir yazı tipi (ör. Inter) Aşama 2'de `assets/fonts` altına gömülecek; böylece Web çevrimdışıyken de aynı görünür.

## Boşluk, köşe, hareket (`tokens/spacing.dart`)

* Boşluk: 2 · 4 · 8 · 12 · 16 · 24 · 32 · 48
* Köşe: 10 · 14 (kontroller) · 20 (kartlar) · 28 (alt sayfalar)
* Hareket: 150 / 260 / 420 ms, `easeOutCubic`. Tutar değişimleri yumuşak kayarak, kartlar sırayla belirir.

## Responsive

| Pencere | Genişlik | Gezinme | KPI sütunu |
|---|---|---|---|
| compact | < 600 | Alt gezinme çubuğu + FAB (tek el) | 2 |
| medium | 600–1024 | Navigation rail | 3 |
| expanded | 1024–1440 | Açık kenar menüsü | 4 |
| large | ≥ 1440 | Açık kenar menüsü, içerik 1440'ta ortalanır | 5 |

## Bileşenler

| Bileşen | Kullanım |
|---|---|
| `MizanCard` | Tüm kart yüzeyleri; başlık/alt başlık/sağ eylem |
| `KpiCard` | Gösterge kartı: simge, etiket, tutar, dipnot |
| `MoneyText` | Tutar: tonlar (nötr, işaretli, gelir, gider), animasyonlu geçiş |
| `EmptyState` | Boş durum + isteğe bağlı eylem |
| `SectionHeader` | Bölüm başlığı |
| `BrandMark` / `BrandWordmark` | Logo |
