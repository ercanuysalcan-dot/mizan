# Yol haritası

Her aşama çalışan kodla biter ve onayınla bir sonrakine geçilir.

| Aşama | Kapsam | Durum |
|---|---|---|
| **1** | Mimari, klasör yapısı, veritabanı şeması + tetikleyiciler, muhasebe motoru, tasarım sistemi, dashboard, hesap oluşturma, hızlı işlem (gelir/gider/transfer/tahsilat/ödeme), iptal, örnek veri, tema | ✅ Kod hazır — cihazda test bekliyor |
| 2 | Cari, Banka, Kredi Kartı, Kasa modüllerinin tam formları, detay sayfaları, hesap ekstresi, tarih filtresi, işlem düzenleme (iptal + yeni kayıt), taksitli harcama + taksit takvimi, Inter yazı tipi, şema geçiş testleri | Sırada |
| 3 | Stok (ürün, depo, giriş/çıkış, sayım, transfer, değerleme, kritik stok) ve Personel (maaş tahakkuku, avans, prim, kesinti, ödeme geçmişi) | |
| 4 | Birikim (altın/döviz, ortalama maliyet, kâr/zarar, isteğe bağlı fiyat), döviz çevirme, tekrarlanan işlemler, kategori yönetimi, gelişmiş arama/filtre | |
| 5 | Raporlar (PDF, Excel, CSV), Supabase: giriş, RLS, bulut yedek/geri yükleme, senkronizasyon + çakışma çözümü | |
| 6 | Güvenlik: PIN/biyometrik kilit, otomatik kilit, yerel şifreleme, rol/yetki, veri silme/hesap kapatma; bildirimler, hatırlatmalar | |
| 7 | Excel içe aktarma, QR/barkod, çoklu dil (TR/AZ/EN), çoklu işletme arayüzü, integration testleri, yayın imzalama | |
