# Kurulum ve çalıştırma

## 1. Gereksinimler

* Flutter **3.32 veya üstü** (stable) — `flutter --version`
* Android için: Android Studio + Android SDK (bir emülatör veya USB hata ayıklamalı telefon)
* Web için: Chrome
* (İsteğe bağlı) Python 3 — şema testini Flutter olmadan çalıştırmak için

## 2. Platform klasörlerini oluştur (bir kez)

Bu depo `lib/`, `test/` ve yapılandırma dosyalarını içerir. `android/` ve `web/` klasörlerini Flutter üretir;
mevcut dosyaların üzerine yazmaz:

```bash
cd mizan
flutter create . --platforms=android,web --project-name mizan --org com.mizan
```

## 3. Bağımlılıklar ve kod üretimi

```bash
flutter pub get
dart run build_runner build --delete-conflicting-outputs
```

İkinci komut `lib/core/database/app_database.g.dart` dosyasını üretir. Şemayı her değiştirdiğinde yeniden çalıştır.

## 4. Web için SQLite dosyaları (bir kez)

Web'de veritabanı SQLite WASM ile çalışır; iki dosyanın `web/` klasöründe olması gerekir.
Önce çözülen sürümleri öğren:

```bash
flutter pub deps --style=compact | grep -E "^- (drift|sqlite3) "
```

Sonra aynı sürümlü dosyaları indir:

* `sqlite3.wasm` → https://github.com/simolus3/sqlite3.dart/releases (`sqlite3-<sürüm>` sürümünün ekleri)
* `drift_worker.js` → https://github.com/simolus3/drift/releases (`drift-<sürüm>` sürümünün ekleri)

İkisini de `web/sqlite3.wasm` ve `web/drift_worker.js` olarak kaydet.

## 5. Testler

```bash
python3 tools/verify_schema.py   # şema + tetikleyiciler, Flutter gerekmez
flutter analyze
flutter test
```

`flutter test` "libsqlite3 bulunamadı" derse: Linux'ta `sudo apt install libsqlite3-dev`;
Windows'ta sqlite.org'dan `sqlite3.dll` indirip proje köküne veya PATH'e koy; macOS'ta ek işlem gerekmez.

## 6. Çalıştır

```bash
flutter run -d chrome          # Web
flutter devices                # bağlı Android cihazları listele
flutter run -d <cihaz-kimliği> # Android
```

## 7. APK oluştur

```bash
flutter build apk --release
# çıktı: build/app/outputs/flutter-apk/app-release.apk
```

Bu aşamada APK, Flutter'ın hata ayıklama anahtarıyla imzalanır (denemek için yeterli, Play Store için değil).
Gerçek imzalama anahtarı ve `key.properties` kurulumu yayın aşamasında eklenecek; anahtar dosyaları `.gitignore` ile korunur.

## 8. Web yayınla

```bash
flutter build web --release
# çıktı: build/web/  → GitHub Pages, Netlify, Firebase Hosting vb. herhangi bir statik barındırmaya yüklenir
```

`build/web` içinde `sqlite3.wasm` ve `drift_worker.js` bulunduğunu kontrol et. GitHub Pages alt klasörde
yayınlanacaksa: `flutter build web --release --base-href /repo-adi/`.

## Sorun giderme

| Belirti | Çözüm |
|---|---|
| `app_database.g.dart` bulunamadı | 3. adımdaki `build_runner` komutunu çalıştır |
| Web'de beyaz ekran, konsolda `sqlite3.wasm` 404 | 4. adım |
| Android'de NDK uyarısı | Android Studio → SDK Manager → NDK (Side by side) kur |
| Test/çalıştırma hatası | Hata çıktısını olduğu gibi bana gönder |
