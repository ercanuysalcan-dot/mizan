#!/usr/bin/env python3
"""Mizan şema doğrulayıcı.

lib/core/database/schema/core.drift dosyasını gerçek SQLite üzerinde çalıştırır
ve muhasebe defteri kurallarının (tetikleyiciler, CHECK kısıtları, benzersiz
indeksler) veritabanı seviyesinde zorlandığını test eder.

Kullanım:  python3 tools/verify_schema.py
Flutter gerektirmez. Çıkış kodu 0 = tüm testler geçti.
"""
import pathlib
import sqlite3
import sys
import uuid

ROOT = pathlib.Path(__file__).resolve().parent.parent
SCHEMA = ROOT / "lib/core/database/schema/core.drift"

T = 1_700_000_000_000
DEV = "test-device"
results = []


def uid():
    return str(uuid.uuid4())


def fresh():
    db = sqlite3.connect(":memory:", isolation_level=None)
    db.execute("PRAGMA foreign_keys = ON")
    db.executescript(SCHEMA.read_text(encoding="utf-8"))
    biz = uid()
    db.execute(
        "INSERT INTO businesses(id,name,base_currency,created_at,updated_at,device_id)"
        " VALUES (?,?,?,?,?,?)", (biz, "Test", "TRY", T, T, DEV))
    return db, biz


def account(db, biz, kind, side, cur="TRY", name=None, category=None, role=None):
    aid = uid()
    if kind in ("gelir", "gider") and category is None:
        category = uid()
        db.execute(
            "INSERT INTO categories(id,business_id,category_type,name,created_at,updated_at,device_id)"
            " VALUES (?,?,?,?,?,?,?)", (category, biz, kind, name or kind, T, T, DEV))
    db.execute(
        "INSERT INTO accounts(id,business_id,kind,normal_side,name,currency,category_id,system_role,"
        "created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (aid, biz, kind, side, name or kind, cur, category, role, T, T, DEV))
    return aid


def entry(db, biz, lines, etype="transfer", key=None, post=True, reverses=None):
    """lines: [(account_id, currency, debit, credit)]"""
    eid = uid()
    db.execute("BEGIN")
    try:
        db.execute(
            "INSERT INTO journal_entries(id,business_id,entry_type,entry_date,status,idempotency_key,"
            "reverses_entry_id,created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (eid, biz, etype, T, "draft", key or uid(), reverses, T, T, DEV))
        for i, (acc, cur, d, c) in enumerate(lines):
            db.execute(
                "INSERT INTO journal_lines(id,entry_id,business_id,line_no,account_id,currency,"
                "debit_minor,credit_minor,created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (uid(), eid, biz, i + 1, acc, cur, d, c, T, T, DEV))
        if post:
            db.execute("UPDATE journal_entries SET status='posted' WHERE id=?", (eid,))
        db.execute("COMMIT")
    except Exception:
        db.execute("ROLLBACK")
        raise
    return eid


def balance(db, acc):
    side, = db.execute("SELECT normal_side FROM accounts WHERE id=?", (acc,)).fetchone()
    d, c = db.execute(
        "SELECT COALESCE(SUM(l.debit_minor),0), COALESCE(SUM(l.credit_minor),0) FROM journal_lines l"
        " JOIN journal_entries e ON e.id=l.entry_id WHERE l.account_id=? AND e.status<>'draft'",
        (acc,)).fetchone()
    return d - c if side == "D" else c - d


def check(name, fn):
    try:
        fn()
        results.append((True, name, ""))
    except AssertionError as e:
        results.append((False, name, str(e)))
    except Exception as e:  # beklenmeyen hata
        results.append((False, name, f"{type(e).__name__}: {e}"))


def expect_error(code, fn):
    try:
        fn()
    except sqlite3.DatabaseError as e:
        assert code in str(e), f"beklenen {code}, gelen: {e}"
        return
    raise AssertionError(f"{code} bekleniyordu, hata oluşmadı")


# ------------------------------------------------------------------ testler
def t_schema_loads():
    db, _ = fresh()
    n, = db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger'").fetchone()
    assert n >= 14, f"tetikleyici sayısı {n}"


def t_balanced_transfer_keeps_total():
    db, biz = fresh()
    kasa = account(db, biz, "kasa", "D")
    banka = account(db, biz, "banka", "D")
    eq = account(db, biz, "ozkaynak", "C", role="acilis_ozkaynak")
    entry(db, biz, [(kasa, "TRY", 100_000, 0), (eq, "TRY", 0, 100_000)], "acilis")
    before = balance(db, kasa) + balance(db, banka)
    entry(db, biz, [(banka, "TRY", 40_050, 0), (kasa, "TRY", 0, 40_050)])
    assert balance(db, kasa) == 59_950 and balance(db, banka) == 40_050
    assert balance(db, kasa) + balance(db, banka) == before, "transfer toplam varlığı değiştirdi"


def t_unbalanced_rejected():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    expect_error("LEDGER_UNBALANCED", lambda: entry(db, biz, [(a, "TRY", 100, 0), (b, "TRY", 0, 99)]))
    n, = db.execute("SELECT COUNT(*) FROM journal_entries").fetchone()
    assert n == 0, "dengesiz kayıt geri alınmadı"


def t_single_line_rejected():
    db, biz = fresh()
    a = account(db, biz, "kasa", "D")
    expect_error("LEDGER_UNBALANCED", lambda: entry(db, biz, [(a, "TRY", 100, 0)]))


def t_multi_currency_balanced_per_currency():
    db, biz = fresh()
    ktry, kusd = account(db, biz, "kasa", "D", "TRY"), account(db, biz, "kasa", "D", "USD")
    fx_try = account(db, biz, "kur_farki", "D", "TRY", role="kur_farki")
    fx_usd = account(db, biz, "kur_farki", "D", "USD", role="kur_farki")
    # 100 USD = 3.400 TRY döviz bozdurma: her para biriminde ayrı denge
    entry(db, biz, [(ktry, "TRY", 340_000, 0), (fx_try, "TRY", 0, 340_000),
                    (fx_usd, "USD", 10_000, 0), (kusd, "USD", 0, 10_000)])
    # Para birimleri arası "toplam" dengesi kabul edilmemeli
    expect_error("LEDGER_UNBALANCED", lambda: entry(
        db, biz, [(ktry, "TRY", 10_000, 0), (kusd, "USD", 0, 10_000)]))


def t_line_currency_must_match_account():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D", "TRY"), account(db, biz, "banka", "D", "TRY")
    expect_error("LEDGER_ACCOUNT_MISMATCH", lambda: entry(db, biz, [(a, "USD", 100, 0), (b, "USD", 0, 100)]))


def t_posted_lines_immutable():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    eid = entry(db, biz, [(a, "TRY", 500, 0), (b, "TRY", 0, 500)])
    expect_error("LEDGER_IMMUTABLE", lambda: db.execute(
        "UPDATE journal_lines SET debit_minor=999 WHERE entry_id=? AND line_no=1", (eid,)))
    expect_error("LEDGER_IMMUTABLE", lambda: db.execute("DELETE FROM journal_lines WHERE entry_id=?", (eid,)))
    expect_error("LEDGER_IMMUTABLE", lambda: db.execute("DELETE FROM journal_entries WHERE id=?", (eid,)))
    expect_error("LEDGER_IMMUTABLE", lambda: db.execute(
        "UPDATE journal_entries SET entry_date=1 WHERE id=?", (eid,)))
    expect_error("LEDGER_ENTRY_NOT_DRAFT", lambda: db.execute(
        "INSERT INTO journal_lines(id,entry_id,business_id,line_no,account_id,currency,debit_minor,"
        "credit_minor,created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (uid(), eid, biz, 3, a, "TRY", 1, 0, T, T, DEV)))
    # Teknik alan (senkron durumu) güncellenebilir
    db.execute("UPDATE journal_lines SET sync_status=1 WHERE entry_id=?", (eid,))
    db.execute("UPDATE journal_entries SET sync_status=1, description='not' WHERE id=?", (eid,))


def t_status_flow():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    eid = entry(db, biz, [(a, "TRY", 500, 0), (b, "TRY", 0, 500)])
    expect_error("LEDGER_BAD_STATUS", lambda: db.execute(
        "UPDATE journal_entries SET status='draft' WHERE id=?", (eid,)))
    db.execute("UPDATE journal_entries SET status='reversed' WHERE id=?", (eid,))
    expect_error("LEDGER_BAD_STATUS", lambda: db.execute(
        "UPDATE journal_entries SET status='posted' WHERE id=?", (eid,)))


def t_idempotency():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    entry(db, biz, [(a, "TRY", 500, 0), (b, "TRY", 0, 500)], key="form-123")
    try:
        entry(db, biz, [(a, "TRY", 500, 0), (b, "TRY", 0, 500)], key="form-123")
        raise AssertionError("aynı anahtar ikinci kez kaydedildi")
    except sqlite3.IntegrityError:
        pass
    assert balance(db, a) == 500


def t_reversal_once_and_nets_zero():
    db, biz = fresh()
    kasa = account(db, biz, "kasa", "D")
    gider = account(db, biz, "gider", "D", name="Kira")
    eid = entry(db, biz, [(gider, "TRY", 2_500, 0), (kasa, "TRY", 0, 2_500)], "gider")
    db.execute("BEGIN")
    rid = uid()
    db.execute(
        "INSERT INTO journal_entries(id,business_id,entry_type,entry_date,status,idempotency_key,"
        "reverses_entry_id,created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (rid, biz, "iptal", T, "draft", uid(), eid, T, T, DEV))
    for i, (acc, d, c) in enumerate([(kasa, 2_500, 0), (gider, 0, 2_500)]):
        db.execute(
            "INSERT INTO journal_lines(id,entry_id,business_id,line_no,account_id,currency,debit_minor,"
            "credit_minor,created_at,updated_at,device_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (uid(), rid, biz, i + 1, acc, "TRY", d, c, T, T, DEV))
    db.execute("UPDATE journal_entries SET status='posted' WHERE id=?", (rid,))
    db.execute("UPDATE journal_entries SET status='reversed' WHERE id=?", (eid,))
    db.execute("COMMIT")
    assert balance(db, kasa) == 0 and balance(db, gider) == 0
    expect_error("UNIQUE", lambda: entry(db, biz, [(kasa, "TRY", 2_500, 0), (gider, "TRY", 0, 2_500)],
                                         "iptal", reverses=eid))
    # iptal türü reverses_entry_id olmadan olamaz
    expect_error("CHECK", lambda: entry(db, biz, [(kasa, "TRY", 1, 0), (gider, "TRY", 0, 1)], "iptal"))


def t_credit_card_flow():
    db, biz = fresh()
    banka = account(db, biz, "banka", "D")
    kart = account(db, biz, "kredi_karti", "C")
    market = account(db, biz, "gider", "D", name="Market")
    eq = account(db, biz, "ozkaynak", "C", role="acilis_ozkaynak")
    entry(db, biz, [(banka, "TRY", 1_000_000, 0), (eq, "TRY", 0, 1_000_000)], "acilis")
    entry(db, biz, [(market, "TRY", 75_090, 0), (kart, "TRY", 0, 75_090)], "kart_harcama")
    assert balance(db, kart) == 75_090, "harcama kart borcunu artırmadı"
    assert balance(db, banka) == 1_000_000, "harcama bankayı etkilememeli"
    entry(db, biz, [(kart, "TRY", 50_000, 0), (banka, "TRY", 0, 50_000)], "kart_odeme")
    assert balance(db, kart) == 25_090 and balance(db, banka) == 950_000


def t_cari_collection():
    db, biz = fresh()
    kasa = account(db, biz, "kasa", "D")
    cari = account(db, biz, "cari", "D", name="Ahmet")
    satis = account(db, biz, "gelir", "C", name="Satış")
    entry(db, biz, [(cari, "TRY", 120_000, 0), (satis, "TRY", 0, 120_000)], "alacak")
    entry(db, biz, [(kasa, "TRY", 45_000, 0), (cari, "TRY", 0, 45_000)], "tahsilat")
    assert balance(db, cari) == 75_000, "kısmi tahsilat sonrası kalan yanlış"
    assert balance(db, kasa) == 45_000


def t_account_rules():
    db, biz = fresh()
    expect_error("CHECK", lambda: account(db, biz, "kredi_karti", "D"))
    expect_error("CHECK", lambda: account(db, biz, "kasa", "C"))
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    db.execute("UPDATE accounts SET currency='USD' WHERE id=?", (a,))  # kullanılmamış: serbest
    db.execute("UPDATE accounts SET currency='TRY' WHERE id=?", (a,))
    entry(db, biz, [(a, "TRY", 1, 0), (b, "TRY", 0, 1)])
    expect_error("ACCOUNT_IN_USE", lambda: db.execute("UPDATE accounts SET currency='USD' WHERE id=?", (a,)))
    expect_error("ACCOUNT_IN_USE", lambda: db.execute("DELETE FROM accounts WHERE id=?", (a,)))
    db.execute("UPDATE accounts SET name='Ana Kasa', archived=1 WHERE id=?", (a,))


def t_line_shape():
    db, biz = fresh()
    a, b = account(db, biz, "kasa", "D"), account(db, biz, "banka", "D")
    expect_error("CHECK", lambda: entry(db, biz, [(a, "TRY", 100, 100), (b, "TRY", 0, 0)]))
    expect_error("CHECK", lambda: entry(db, biz, [(a, "TRY", -100, 0), (b, "TRY", 0, -100)]))


def t_audit_append_only():
    db, _ = fresh()
    aid = uid()
    db.execute("INSERT INTO audit_log(id,entity_table,record_id,audit_action,occurred_at,created_at,updated_at,device_id)"
               " VALUES (?,?,?,?,?,?,?,?)", (aid, "journal_entries", "x", "post", T, T, T, DEV))
    expect_error("AUDIT_IMMUTABLE", lambda: db.execute("UPDATE audit_log SET audit_action='delete' WHERE id=?", (aid,)))
    expect_error("AUDIT_IMMUTABLE", lambda: db.execute("DELETE FROM audit_log WHERE id=?", (aid,)))
    db.execute("UPDATE audit_log SET sync_status=1 WHERE id=?", (aid,))


def t_stock_append_only():
    db, biz = fresh()
    depo = account(db, biz, "stok", "D", name="Ana Depo")
    item = uid()
    db.execute("INSERT INTO stock_items(id,business_id,name,currency,created_at,updated_at,device_id)"
               " VALUES (?,?,?,?,?,?,?)", (item, biz, "Vida", "TRY", T, T, DEV))
    mid = uid()
    db.execute("INSERT INTO stock_movements(id,business_id,item_id,warehouse_account_id,movement_type,"
               "quantity_micro,movement_date,idempotency_key,created_at,updated_at,device_id)"
               " VALUES (?,?,?,?,?,?,?,?,?,?,?)", (mid, biz, item, depo, "giris", 5_000_000, T, "k1", T, T, DEV))
    expect_error("STOCK_IMMUTABLE", lambda: db.execute(
        "UPDATE stock_movements SET quantity_micro=1 WHERE id=?", (mid,)))
    expect_error("STOCK_IMMUTABLE", lambda: db.execute("DELETE FROM stock_movements WHERE id=?", (mid,)))


for name, fn in list(globals().items()):
    if name.startswith("t_") and callable(fn):
        check(name[2:], fn)

ok = sum(1 for r in results if r[0])
for passed, name, msg in results:
    print(("  GEÇTİ  " if passed else "  KALDI  ") + name + (f"  -> {msg}" if msg else ""))
print(f"\nSQLite {sqlite3.sqlite_version}: {ok}/{len(results)} test geçti")
sys.exit(0 if ok == len(results) else 1)
