// Web'de veritabanını ayrı bir worker'da çalıştıran giriş noktası.
// Derleme: dart compile js -O4 -o web/drift_worker.js tools/drift_worker.dart
import 'package:drift/wasm.dart';

void main() => WasmDatabase.workerMainForOpen();
