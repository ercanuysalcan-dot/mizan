-- =====================================================================
-- MIZAN — Yerel veritabanı şeması (SQLite / Drift)
-- ---------------------------------------------------------------------
-- Kurallar:
--  * Her kayıt: UUID (id), created_at, updated_at (UTC epoch ms),
--    device_id, sync_status (0=bekliyor,1=senkron,2=çakışma), version.
--  * Para tutarları INTEGER "minor unit" (kuruş/qəpik/cent) olarak tutulur.
--    Ondalık (double) asla kullanılmaz.
--  * Miktarlar (gram altın, stok adedi) INTEGER "micro" (1e-6) ölçeğindedir.
--  * Muhasebe defteri (journal_entries + journal_lines) çift kayıtlıdır ve
--    kayıt "posted" olduktan sonra değiştirilemez/silinemez. Düzeltme ve
--    iptal, ters kayıt (storno) ile yapılır. Bu kurallar aşağıdaki
--    tetikleyicilerle veritabanı seviyesinde de zorlanır.
-- Bu dosya saf SQLite sözdizimidir; tools/verify_schema.py ile doğrudan
-- sqlite3 üzerinde test edilir.
-- =====================================================================

CREATE TABLE businesses (
  id TEXT NOT NULL PRIMARY KEY,
  name TEXT NOT NULL,
  base_currency TEXT NOT NULL CHECK (base_currency IN ('TRY','AZN','USD','EUR')),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

-- Gelir / gider kategorileri (mantıksal). Her kategori, kullanıldığı her
-- para birimi için defterde ayrı bir gelir/gider hesabına bağlanır.
CREATE TABLE categories (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  category_type TEXT NOT NULL CHECK (category_type IN ('gelir','gider')),
  name TEXT NOT NULL,
  parent_id TEXT REFERENCES categories(id),
  color INTEGER,
  icon TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0,
  archived INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

CREATE INDEX categories_business ON categories(business_id, category_type);

-- Defter hesapları. Kullanıcının gördüğü 8 hesap türü + sistem hesapları.
-- (v2: 'kredi' = taksitli banka kredisi eklendi.)
-- normal_side: D = borç yönlü (varlık, gider), C = alacak yönlü (borç, gelir, özkaynak)
CREATE TABLE accounts (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  kind TEXT NOT NULL CHECK (kind IN (
    'cari','banka','kredi_karti','kredi','stok','personel','birikim','kasa',
    'gelir','gider','ozkaynak','kur_farki')),
  normal_side TEXT NOT NULL CHECK (normal_side IN ('D','C')),
  name TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (currency IN ('TRY','AZN','USD','EUR')),
  category_id TEXT REFERENCES categories(id),
  system_role TEXT CHECK (system_role IS NULL OR system_role IN ('acilis_ozkaynak','kur_farki')),
  archived INTEGER NOT NULL DEFAULT 0,
  sort_order INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER,
  -- Bakiye yönü hesap türünden türetilir; tutarsız kayıt engellenir.
  CHECK (
    (kind IN ('cari','banka','stok','birikim','kasa','gider','kur_farki') AND normal_side = 'D')
    OR (kind IN ('kredi_karti','kredi','personel','gelir','ozkaynak') AND normal_side = 'C')
  ),
  CHECK ((kind IN ('gelir','gider')) = (category_id IS NOT NULL))
);

CREATE INDEX accounts_business_kind ON accounts(business_id, kind);
CREATE UNIQUE INDEX accounts_category_currency
  ON accounts(business_id, category_id, currency) WHERE category_id IS NOT NULL;
CREATE UNIQUE INDEX accounts_system_role_currency
  ON accounts(business_id, system_role, currency) WHERE system_role IS NOT NULL;

-- Hesap türüne özel detaylar (1-1)
CREATE TABLE cari_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  party_type TEXT NOT NULL DEFAULT 'musteri' CHECK (party_type IN ('musteri','tedarikci','ikisi')),
  entity_type TEXT NOT NULL DEFAULT 'kisi' CHECK (entity_type IN ('kisi','firma')),
  phone TEXT,
  email TEXT,
  address TEXT,
  tax_office TEXT,
  tax_number TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE bank_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  bank_name TEXT NOT NULL,
  iban TEXT,
  branch TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE card_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  bank_name TEXT NOT NULL,
  credit_limit_minor INTEGER NOT NULL DEFAULT 0 CHECK (credit_limit_minor >= 0),
  statement_day INTEGER CHECK (statement_day IS NULL OR statement_day BETWEEN 1 AND 31),
  due_day INTEGER CHECK (due_day IS NULL OR due_day BETWEEN 1 AND 31),
  last_four TEXT CHECK (last_four IS NULL OR length(last_four) = 4),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE employee_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  full_name TEXT NOT NULL,
  phone TEXT,
  position TEXT,
  hire_date INTEGER,
  salary_minor INTEGER CHECK (salary_minor IS NULL OR salary_minor >= 0),
  pay_day INTEGER CHECK (pay_day IS NULL OR pay_day BETWEEN 1 AND 31),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE savings_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  asset_type TEXT NOT NULL CHECK (asset_type IN ('altin','gram_altin','ceyrek_altin','dolar','euro','nakit','diger')),
  unit_label TEXT NOT NULL DEFAULT 'adet',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

-- ---------------------------------------------------------------------
-- ÇİFT KAYITLI DEFTER
-- ---------------------------------------------------------------------
CREATE TABLE journal_entries (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  entry_type TEXT NOT NULL CHECK (entry_type IN (
    'acilis','gelir','gider','transfer','kart_harcama','kart_odeme',
    'tahsilat','odeme','borc','alacak','maas','avans','stok','duzeltme','iptal')),
  entry_date INTEGER NOT NULL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','posted','reversed')),
  idempotency_key TEXT NOT NULL,
  reverses_entry_id TEXT REFERENCES journal_entries(id),
  attachment_path TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  CHECK ((entry_type = 'iptal') = (reverses_entry_id IS NOT NULL))
);

-- Aynı işlem iki kez kaydedilemez (çift tıklama, senkron tekrarı).
CREATE UNIQUE INDEX journal_entries_idempotency ON journal_entries(business_id, idempotency_key);
-- Bir kayıt yalnızca bir kez iptal edilebilir.
CREATE UNIQUE INDEX journal_entries_single_reversal
  ON journal_entries(reverses_entry_id) WHERE reverses_entry_id IS NOT NULL;
CREATE INDEX journal_entries_date ON journal_entries(business_id, entry_date);

CREATE TABLE journal_lines (
  id TEXT NOT NULL PRIMARY KEY,
  entry_id TEXT NOT NULL REFERENCES journal_entries(id),
  business_id TEXT NOT NULL REFERENCES businesses(id),
  line_no INTEGER NOT NULL,
  account_id TEXT NOT NULL REFERENCES accounts(id),
  currency TEXT NOT NULL CHECK (currency IN ('TRY','AZN','USD','EUR')),
  debit_minor INTEGER NOT NULL DEFAULT 0 CHECK (debit_minor >= 0),
  credit_minor INTEGER NOT NULL DEFAULT 0 CHECK (credit_minor >= 0),
  quantity_micro INTEGER,
  memo TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  -- Her satır ya borç ya alacak taşır, ikisini birden ya da sıfır değil.
  CHECK ((debit_minor = 0) <> (credit_minor = 0)),
  UNIQUE (entry_id, line_no)
);

CREATE INDEX journal_lines_account ON journal_lines(account_id);
CREATE INDEX journal_lines_entry ON journal_lines(entry_id);

-- Satır yalnızca taslak kayda eklenebilir.
CREATE TRIGGER journal_lines_insert_only_draft
BEFORE INSERT ON journal_lines
WHEN (SELECT status FROM journal_entries WHERE id = NEW.entry_id) IS NOT 'draft'
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_ENTRY_NOT_DRAFT');
END;

-- Satırın para birimi ve işletmesi hesabınkiyle aynı olmalı.
CREATE TRIGGER journal_lines_match_account
BEFORE INSERT ON journal_lines
WHEN NOT EXISTS (
  SELECT 1 FROM accounts a
  WHERE a.id = NEW.account_id AND a.currency = NEW.currency AND a.business_id = NEW.business_id
)
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_ACCOUNT_MISMATCH');
END;

-- Kesinleşmiş satırların finansal alanları değiştirilemez.
-- (sync_status gibi teknik alanlar güncellenebilir.)
CREATE TRIGGER journal_lines_immutable
BEFORE UPDATE OF entry_id, business_id, line_no, account_id, currency,
  debit_minor, credit_minor, quantity_micro ON journal_lines
WHEN (SELECT status FROM journal_entries WHERE id = OLD.entry_id) IS NOT 'draft'
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_IMMUTABLE');
END;

CREATE TRIGGER journal_lines_no_delete
BEFORE DELETE ON journal_lines
WHEN (SELECT status FROM journal_entries WHERE id = OLD.entry_id) IS NOT 'draft'
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_IMMUTABLE');
END;

-- Durum geçişleri: draft -> posted -> reversed. Başka geçiş yok.
CREATE TRIGGER journal_entries_status_flow
BEFORE UPDATE OF status ON journal_entries
WHEN NOT (
  OLD.status = NEW.status
  OR (OLD.status = 'draft' AND NEW.status = 'posted')
  OR (OLD.status = 'posted' AND NEW.status = 'reversed')
)
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_BAD_STATUS');
END;

-- Kesinleştirme anında çift kayıt dengesi: her para biriminde
-- toplam borç = toplam alacak ve en az iki satır.
CREATE TRIGGER journal_entries_balanced_on_post
BEFORE UPDATE OF status ON journal_entries
WHEN OLD.status = 'draft' AND NEW.status = 'posted' AND (
  (SELECT COUNT(*) FROM journal_lines WHERE entry_id = NEW.id) < 2
  OR EXISTS (
    SELECT 1 FROM journal_lines WHERE entry_id = NEW.id
    GROUP BY currency HAVING SUM(debit_minor) <> SUM(credit_minor)
  )
)
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_UNBALANCED');
END;

-- Kesinleşmiş kaydın finansal başlık alanları değiştirilemez.
CREATE TRIGGER journal_entries_immutable
BEFORE UPDATE OF business_id, entry_type, entry_date, idempotency_key, reverses_entry_id
ON journal_entries
WHEN OLD.status IS NOT 'draft'
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_IMMUTABLE');
END;

CREATE TRIGGER journal_entries_no_delete
BEFORE DELETE ON journal_entries
WHEN OLD.status IS NOT 'draft'
BEGIN
  SELECT RAISE(ABORT, 'LEDGER_IMMUTABLE');
END;

-- Satırı olan hesabın para birimi / türü / işletmesi değiştirilemez.
CREATE TRIGGER accounts_lock_used
BEFORE UPDATE OF currency, kind, normal_side, business_id ON accounts
WHEN EXISTS (SELECT 1 FROM journal_lines WHERE account_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT, 'ACCOUNT_IN_USE');
END;

CREATE TRIGGER accounts_no_delete_used
BEFORE DELETE ON accounts
WHEN EXISTS (SELECT 1 FROM journal_lines WHERE account_id = OLD.id)
BEGIN
  SELECT RAISE(ABORT, 'ACCOUNT_IN_USE');
END;

-- ---------------------------------------------------------------------
-- STOK (Aşama 3'te ekranları gelecek; şema şimdiden hazır)
-- ---------------------------------------------------------------------
CREATE TABLE stock_items (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  name TEXT NOT NULL,
  code TEXT,
  barcode TEXT,
  category TEXT,
  unit TEXT NOT NULL DEFAULT 'adet',
  currency TEXT NOT NULL CHECK (currency IN ('TRY','AZN','USD','EUR')),
  purchase_price_minor INTEGER NOT NULL DEFAULT 0 CHECK (purchase_price_minor >= 0),
  sale_price_minor INTEGER NOT NULL DEFAULT 0 CHECK (sale_price_minor >= 0),
  min_quantity_micro INTEGER NOT NULL DEFAULT 0,
  archived INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

CREATE UNIQUE INDEX stock_items_code ON stock_items(business_id, code) WHERE code IS NOT NULL;

-- Depo = 'stok' türünde hesap. Hareketler ekleme-yalnızdır.
CREATE TABLE stock_movements (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  item_id TEXT NOT NULL REFERENCES stock_items(id),
  warehouse_account_id TEXT NOT NULL REFERENCES accounts(id),
  movement_type TEXT NOT NULL CHECK (movement_type IN ('giris','cikis','sayim','transfer_giris','transfer_cikis')),
  quantity_micro INTEGER NOT NULL CHECK (quantity_micro <> 0),
  unit_cost_minor INTEGER,
  journal_entry_id TEXT REFERENCES journal_entries(id),
  movement_date INTEGER NOT NULL,
  note TEXT,
  idempotency_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE UNIQUE INDEX stock_movements_idempotency ON stock_movements(business_id, idempotency_key);
CREATE INDEX stock_movements_item ON stock_movements(item_id, movement_date);

CREATE TRIGGER stock_movements_immutable
BEFORE UPDATE OF item_id, warehouse_account_id, movement_type, quantity_micro,
  unit_cost_minor, movement_date ON stock_movements
BEGIN
  SELECT RAISE(ABORT, 'STOCK_IMMUTABLE');
END;

CREATE TRIGGER stock_movements_no_delete
BEFORE DELETE ON stock_movements
BEGIN
  SELECT RAISE(ABORT, 'STOCK_IMMUTABLE');
END;

-- ---------------------------------------------------------------------
-- KREDİ KARTI TAKSİT, TEKRARLANAN İŞLEM, FİYAT (sonraki aşamalar)
-- ---------------------------------------------------------------------
CREATE TABLE card_installments (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  card_account_id TEXT NOT NULL REFERENCES accounts(id),
  journal_entry_id TEXT NOT NULL REFERENCES journal_entries(id),
  installment_no INTEGER NOT NULL CHECK (installment_no >= 1),
  installment_count INTEGER NOT NULL CHECK (installment_count >= 1),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  due_date INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  UNIQUE (journal_entry_id, installment_no)
);

CREATE TABLE recurring_rules (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  template_json TEXT NOT NULL,
  frequency TEXT NOT NULL CHECK (frequency IN ('gunluk','haftalik','aylik','yillik')),
  interval_count INTEGER NOT NULL DEFAULT 1 CHECK (interval_count >= 1),
  next_run_date INTEGER NOT NULL,
  end_date INTEGER,
  active INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

-- Piyasa / kur fiyatları. İnternet yokken son kayıtlı fiyat ve tarihi gösterilir.
CREATE TABLE price_quotes (
  id TEXT NOT NULL PRIMARY KEY,
  asset_code TEXT NOT NULL,
  quote_currency TEXT NOT NULL CHECK (quote_currency IN ('TRY','AZN','USD','EUR')),
  price_minor INTEGER NOT NULL CHECK (price_minor > 0),
  quoted_at INTEGER NOT NULL,
  source TEXT NOT NULL DEFAULT 'manuel',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX price_quotes_lookup ON price_quotes(asset_code, quote_currency, quoted_at);

-- ---------------------------------------------------------------------
-- DENETİM KAYDI (ekleme-yalnız)
-- ---------------------------------------------------------------------
CREATE TABLE audit_log (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT,
  entity_table TEXT NOT NULL,
  record_id TEXT NOT NULL,
  audit_action TEXT NOT NULL CHECK (audit_action IN ('insert','update','delete','post','reverse')),
  before_json TEXT,
  after_json TEXT,
  reason TEXT,
  user_id TEXT,
  occurred_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

CREATE INDEX audit_log_record ON audit_log(entity_table, record_id);

CREATE TRIGGER audit_log_immutable
BEFORE UPDATE OF business_id, entity_table, record_id, audit_action, before_json,
  after_json, reason, user_id, occurred_at ON audit_log
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

CREATE TRIGGER audit_log_no_delete
BEFORE DELETE ON audit_log
BEGIN
  SELECT RAISE(ABORT, 'AUDIT_IMMUTABLE');
END;

-- ---------------------------------------------------------------------
-- v2: BANKA KREDİSİ, KART EKSTRELERİ, EKLER
-- Bu tablolar finansal kayıt değil, defterdeki kayıtlara bağlı bilgi
-- kayıtlarıdır. Tutarların bakiyeye etkisi her zaman journal_* üzerinden.
-- ---------------------------------------------------------------------

-- Taksitli banka kredisi (accounts.kind = 'kredi'). Borç = toplam geri
-- ödenecek tutar (basit gösterim, anapara/faiz ayrımı yok).
CREATE TABLE loan_details (
  account_id TEXT NOT NULL PRIMARY KEY REFERENCES accounts(id),
  bank_name TEXT NOT NULL,
  total_minor INTEGER NOT NULL CHECK (total_minor > 0),
  installment_count INTEGER NOT NULL CHECK (installment_count BETWEEN 1 AND 600),
  installment_minor INTEGER NOT NULL CHECK (installment_minor > 0),
  first_due_date INTEGER NOT NULL,
  opening_entry_id TEXT REFERENCES journal_entries(id),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);

-- Ödeme planı. paid_entry_id doluysa taksit ödenmiştir; ödeme yalnızca
-- kullanıcı "Taksit öde" dediğinde yazılır (otomatik düşme yok).
CREATE TABLE loan_installments (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  loan_account_id TEXT NOT NULL REFERENCES accounts(id),
  installment_no INTEGER NOT NULL CHECK (installment_no >= 1),
  due_date INTEGER NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  paid_entry_id TEXT REFERENCES journal_entries(id),
  -- Takibe başlamadan önce ödenmiş taksit (deftere ödeme yazılmaz).
  prepaid INTEGER NOT NULL DEFAULT 0 CHECK (prepaid IN (0, 1)),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  UNIQUE (loan_account_id, installment_no)
);

CREATE INDEX loan_installments_due ON loan_installments(business_id, due_date);
CREATE UNIQUE INDEX loan_installments_paid_entry
  ON loan_installments(paid_entry_id) WHERE paid_entry_id IS NOT NULL;

-- Kredi kartı dönem borcu (ekstre). entry_id doluysa ekstre tutarı kart
-- borcuna da işlenmiştir (D gider / C kart).
CREATE TABLE card_statements (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  card_account_id TEXT NOT NULL REFERENCES accounts(id),
  statement_date INTEGER NOT NULL,
  due_date INTEGER,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  min_payment_minor INTEGER CHECK (min_payment_minor IS NULL OR min_payment_minor >= 0),
  entry_id TEXT REFERENCES journal_entries(id),
  note TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

CREATE INDEX card_statements_card ON card_statements(card_account_id, statement_date);

-- Fotoğraf / ekran görüntüsü ekleri. Veritabanında saklanır; böylece
-- Android ve Web'de aynı şekilde çevrimdışı çalışır ve yedeğe dahil olur.
CREATE TABLE attachments (
  id TEXT NOT NULL PRIMARY KEY,
  business_id TEXT NOT NULL REFERENCES businesses(id),
  owner_table TEXT NOT NULL CHECK (owner_table IN ('card_statements','journal_entries')),
  owner_id TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_name TEXT,
  size_bytes INTEGER NOT NULL CHECK (size_bytes > 0),
  content BLOB NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  device_id TEXT NOT NULL,
  sync_status INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1,
  deleted_at INTEGER
);

CREATE INDEX attachments_owner ON attachments(owner_table, owner_id);

-- ---------------------------------------------------------------------
-- YEREL AYARLAR VE SENKRON DURUMU (yalnızca bu cihaz, senkronlanmaz)
-- ---------------------------------------------------------------------
CREATE TABLE app_settings (
  setting_key TEXT NOT NULL PRIMARY KEY,
  setting_value TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
