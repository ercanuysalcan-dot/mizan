# mizan

Android ve Web için çevrimdışı öncelikli, çift kayıtlı finans ve işletme muhasebe platformu.
Flutter · Riverpod · GoRouter · Drift (SQLite / SQLite WASM).

## Hızlı başlangıç

```bash
flutter create . --platforms=android,web --project-name mizan --org com.mizan
flutter pub get
dart run build_runner build --delete-conflicting-outputs
python3 tools/verify_schema.py
flutter test
flutter run -d chrome
```

Web için `web/sqlite3.wasm` ve `web/drift_worker.js` gerekir → [docs/SETUP.md](docs/SETUP.md#4-web-için-sqlite-dosyaları-bir-kez).

## Aşama 1'de çalışan özellikler

* **Muhasebe motoru:** çift kayıt, atomik yazma, para birimi başına denge, idempotency, ters kayıtla iptal,
  denetim kaydı, defter bütünlüğü doğrulama. Kurallar hem Dart'ta hem SQLite tetikleyicilerinde zorlanır.
* **Para:** tam sayı kuruş, yuvarlama hatası yok; TRY, AZN, USD, EUR.
* **Hesap oluşturma:** 8 tür (Cari, Banka, Kredi Kartı, Banka Kredisi, Stok, Personel, Birikim, Nakit), açılış bakiyesi ve yönü.
* **Hızlı işlem:** gelir, gider (kasa/banka/kart), transfer (karta transfer = kart ödemesi), tahsilat, ödeme.
* **Dashboard:** net varlık, toplam varlık/borç/alacak, kasa, banka, kart borcu, dönem gelir/gider/net;
  gelir-gider, nakit akışı, varlık dağılımı, borç-alacak grafikleri; son işlemler/tahsilatlar/ödemeler;
  Bugün/Hafta/Ay/Yıl/Özel aralık filtresi; para birimi seçimi; kartları göster-gizle-sırala.
* **Ayarlar:** açık/koyu/sistem tema, örnek veri yükle/kaldır, defter doğrulama.
* **Responsive:** telefon (alt çubuk + FAB), tablet (ray), geniş ekran (kenar menüsü, çok sütun).

## Aşama 2a'da eklenenler

* **Banka kredisi:** toplam borç + taksit sayısı/tutarı + ilk vade → ödeme planı. Taksit yalnızca “Taksit öde”
  ile düşer; ödeme hesabı seçilir. Yanlış ödeme geri alınabilir/düzeltilebilir. Önceden ödenmiş taksitler girilebilir.
  Hesaplar listesinde sıradaki taksit ve kaç gün kaldığı görünür (3 gün kala / gecikince kırmızı).
* **Kredi kartı:** Harcama, Dönem borcu (ekstre), Ödeme. Ekstreye ekran görüntüsü eklenir; geçmiş ekstreler
  ay ay saklanır. “Kart borcuna ekle” kapatılırsa ekstre yalnızca arşivlenir.
* **Düzeltme:** her kayıtta tutar, tarih, hesap, kategori, açıklama düzeltilir (iptal + yeni kayıt); bakiyeler
  kendiliğinden düzelir; eski hal “Değişiklik geçmişi”nde görünür. Fiş/fotoğraf eklenebilir.
* **Kategoriler:** Ayarlar → Kategoriler. Kendi kategorini aç (Telefon, İnternet…), alt kategori, ikon, renk;
  kullanılmış kategori silinirken kayıtlar seçilen kategoriye taşınır. Bu ayın kategori toplamları görünür.

## Belgeler

[Mimari](docs/ARCHITECTURE.md) · [Veritabanı](docs/DATABASE.md) · [Tasarım sistemi](docs/DESIGN_SYSTEM.md) ·
[Kurulum, APK, Web yayını](docs/SETUP.md) · [Test raporu](docs/TEST_REPORT.md) · [Yol haritası](docs/ROADMAP.md)
